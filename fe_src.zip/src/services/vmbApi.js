/**
 * Thin wrappers cho tất cả endpoint /api/tools/vmb/**.
 *
 * Import trong components:
 *   import * as vmb from '../services/vmbApi'
 *   vmb.listBookings({ q, page })
 *
 * Reuse axios instance `api` từ services/api.js — nó đã có Bearer interceptor,
 * baseURL cấu hình bằng VITE_API_BASE, và auto-401-redirect. Các endpoint VMB
 * là public nên interceptor không thêm token, nhưng nếu người dùng đang đăng
 * nhập ở tab Tools, token vẫn được gửi kèm — vô hại.
 *
 * Cách gọi endpoint admin (/vmb/admin/**) chỉ khác ở chỗ user phải có admin
 * token — nếu không, interceptor sẽ redirect tới /login. Không có xử lý đặc
 * biệt trong file này.
 */
import api from './api'

// ── BOOKINGS & TICKETS & INVOICES ─────────────────────────────

export const listBookings = (params = {}) =>
  api.get('/api/tools/vmb/bookings', { params })

/** Trả list BookingTotals (mỗi currency 1 dòng — VND + USD). */
export const totalsBookings = (params = {}) =>
  api.get('/api/tools/vmb/bookings/totals', { params })

export const getBooking = (id) =>
  api.get(`/api/tools/vmb/bookings/${id}`)

export const createBooking = (body) =>
  api.post('/api/tools/vmb/bookings', body)

export const updateBooking = (id, body) =>
  api.put(`/api/tools/vmb/bookings/${id}`, body)

export const deleteBooking = (id) =>
  api.delete(`/api/tools/vmb/bookings/${id}`)

export const uploadTicketFile = (ticketId, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.post(`/api/tools/vmb/tickets/${ticketId}/files`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteTicketFile = (fileId) =>
  api.delete(`/api/tools/vmb/ticket-files/${fileId}`)

/** Thay file mặt vé — server xóa file cũ, save file mới, giữ nguyên fileId. */
export const replaceTicketFile = (fileId, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.put(`/api/tools/vmb/ticket-files/${fileId}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

/** slot ∈ 'draft' | 'issued' | 'adjustment' | 'record' */
export const replaceInvoiceFile = (invoiceId, slot, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.put(`/api/tools/vmb/invoices/${invoiceId}/files/${slot}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteInvoiceFile = (invoiceId, slot) =>
  api.delete(`/api/tools/vmb/invoices/${invoiceId}/files/${slot}`)

export const setTicketPaid = (ticketId, status) =>
  api.patch(`/api/tools/vmb/tickets/${ticketId}/paid`, { status })

/**
 * Tạo hóa đơn mới — status kèm theo file phù hợp:
 *   DRAFT    → draftFile
 *   ISSUED   → issuedFile
 *   ADJUSTED → issuedFile + adjustmentFile + adjustmentRecordFile
 *
 * `files` là object { draftFile?, issuedFile?, adjustmentFile?, adjustmentRecordFile? }
 *
 * ── G2 ──────────────────────────────────────────────────
 * Endpoint đổi từ /tickets/{ticketId}/invoices sang /bookings/{bookingId}/invoices.
 * `ticketId` optional: null = hóa đơn chung cả booking, set = riêng cho vé.
 */
export const createInvoice = (bookingId, { status, note, ticketId, ...files }) => {
  const fd = new FormData()
  fd.append('status', status)
  if (note) fd.append('note', note)
  if (ticketId) fd.append('ticketId', String(ticketId))
  for (const [k, v] of Object.entries(files)) {
    if (v instanceof File) fd.append(k, v)
  }
  return api.post(`/api/tools/vmb/bookings/${bookingId}/invoices`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const updateInvoice = (invoiceId, { status, note, ...files }) => {
  const fd = new FormData()
  if (status) fd.append('status', status)
  if (note != null) fd.append('note', note)
  for (const [k, v] of Object.entries(files)) {
    if (v instanceof File) fd.append(k, v)
  }
  return api.put(`/api/tools/vmb/invoices/${invoiceId}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteInvoice = (invoiceId) =>
  api.delete(`/api/tools/vmb/invoices/${invoiceId}`)

// ── COMPANIES & PASSENGERS & MEMBERSHIP ──────────────────────

export const listCompanies = () =>
  api.get('/api/tools/vmb/companies')

/**
 * Body: { name, shortName?, address?, taxId?, phone?, email? }
 * Tạo công ty GỐC (parentId = null).
 */
export const createCompany = (body) =>
  api.post('/api/tools/vmb/companies', body)

/**
 * Tạo CHI NHÁNH cho 1 công ty gốc. Body cùng shape với createCompany.
 * BE tự set parentId = parent id trong URL.
 */
export const createCompanyBranch = (parentId, body) =>
  api.post(`/api/tools/vmb/companies/${parentId}/branches`, body)

export const updateCompany = (id, body) =>
  api.put(`/api/tools/vmb/companies/${id}`, body)

export const deleteCompany = (id) =>
  api.delete(`/api/tools/vmb/companies/${id}`)

export const listPassengers = (params = {}) =>
  api.get('/api/tools/vmb/passengers', { params })

export const getPassenger = (id) =>
  api.get(`/api/tools/vmb/passengers/${id}`)

export const createPassenger = (body) =>
  api.post('/api/tools/vmb/passengers', body)

export const updatePassenger = (id, body) =>
  api.put(`/api/tools/vmb/passengers/${id}`, body)

export const deletePassenger = (id) =>
  api.delete(`/api/tools/vmb/passengers/${id}`)

export const uploadCccdFile = (id, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.post(`/api/tools/vmb/passengers/${id}/cccd-file`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const uploadPassportFile = (id, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.post(`/api/tools/vmb/passengers/${id}/passport-file`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const removeCccdFile = (id) =>
  api.delete(`/api/tools/vmb/passengers/${id}/cccd-file`)

export const removePassportFile = (id) =>
  api.delete(`/api/tools/vmb/passengers/${id}/passport-file`)

export const listMembershipCards = (passengerId) =>
  api.get(`/api/tools/vmb/passengers/${passengerId}/membership-cards`)

export const createMembershipCard = (passengerId, body) =>
  api.post(`/api/tools/vmb/passengers/${passengerId}/membership-cards`, body)

export const updateMembershipCard = (cardId, body) =>
  api.put(`/api/tools/vmb/membership-cards/${cardId}`, body)

export const deleteMembershipCard = (cardId) =>
  api.delete(`/api/tools/vmb/membership-cards/${cardId}`)

// ── LOOKUP + 2FA ─────────────────────────────────────────────

export const listLookup = (params = {}) =>
  api.get('/api/tools/vmb/lookup', { params })

export const createLookup = (body) =>
  api.post('/api/tools/vmb/lookup', body)

export const updateLookup = (id, body) =>
  api.put(`/api/tools/vmb/lookup/${id}`, body)

export const deleteLookup = (id) =>
  api.delete(`/api/tools/vmb/lookup/${id}`)

export const revealLookupPassword = (id, code) =>
  api.post(`/api/tools/vmb/lookup/${id}/reveal`, { code })

export const lookupStatus = () =>
  api.get('/api/tools/vmb/lookup/status')

/** Admin only — cần token admin */
export const adminUnlockLookup = () =>
  api.post('/api/tools/vmb/admin/lookup/unlock')

// ══════════════════════════════════════════════════════════════
// PAYMENTS (G3)
// ══════════════════════════════════════════════════════════════

/**
 * Thu tiền 1 lần cho 1 booking. Cho phép thu 1 phần (số < tổng) hoặc thu đủ.
 * file (ảnh biên nhận) optional — chuyển khoản không có ảnh vẫn OK.
 */
export const recordPayment = (bookingId, { amount, note, file } = {}) => {
  const fd = new FormData()
  fd.append('amount', amount)
  if (note) fd.append('note', note)
  if (file instanceof File) fd.append('file', file)
  return api.post(`/api/tools/vmb/bookings/${bookingId}/payments`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

/**
 * Thu batch nhiều booking, dùng chung 1 ảnh chứng từ. BE tự tính số còn lại
 * của mỗi booking và ghi đủ số đó (không thu 1 phần khi làm batch).
 */
export const batchPay = ({ bookingIds, note, file } = {}) => {
  const fd = new FormData()
  for (const id of bookingIds) fd.append('bookingIds', String(id))
  if (note) fd.append('note', note)
  if (file instanceof File) fd.append('file', file)
  return api.post('/api/tools/vmb/bookings/pay-batch', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const listPayments = (bookingId) =>
  api.get(`/api/tools/vmb/bookings/${bookingId}/payments`)

export const deletePayment = (paymentId) =>
  api.delete(`/api/tools/vmb/payments/${paymentId}`)
