/**
 * Thin wrappers cho tất cả endpoint /api/tools/vmb/**.
 *
 * ── 2026-09-19 refactor ────────────────────────────────────────
 * - THÊM: listFeeTypes  (dropdown loại phí VN)
 * - THÊM: uploadBookingProof / deleteBookingProof  (file bằng chứng)
 * - SỬA:  createInvoice / updateInvoice — thay {ticketId single} bằng
 *         {ticketIds: []}. Empty array = chung cả booking.
 *   Trên FE truyền {ticketIds: [1,2,3]}; hoặc omit hẳn cho create/update
 *   nghĩa là không đổi. updateInvoice để chuyển sang "chung" thì gửi
 *   {clearTicketIds: true}.
 *
 * ── 2026-11-15 ────────────────────────────────────────────────
 * - THÊM: listInvoices — list phẳng cho trang "Quản lý hóa đơn".
 */
import api from './api'

// ── FEE TYPES (dropdown) ─────────────────────────────────────

export const listFeeTypes = () =>
  api.get('/api/tools/vmb/fee-types')

// ── BOOKINGS ─────────────────────────────────────────────────

export const listBookings = (params = {}) =>
  api.get('/api/tools/vmb/bookings', { params })

export const totalsBookings = (params = {}) =>
  api.get('/api/tools/vmb/bookings/totals', { params })

export const getBooking = (id) =>
  api.get(`/api/tools/vmb/bookings/${id}`)

export const createBooking = (body) =>
  api.post('/api/tools/vmb/bookings', body)

export const updateBooking = (id, body) =>
  api.put(`/api/tools/vmb/bookings/${id}`, body)

export const deleteBooking = (id) =>
  api.delete(`/api/tools/vmb/bookings/${id}`)

export const setRefundedPaid = (id, refundedPaid) =>
  api.patch(`/api/tools/vmb/bookings/${id}/refunded-paid`, { refundedPaid })

// ── MẶT VÉ (Ticket face — 2 scope) ─────────────────────────

export const uploadBookingFace = (bookingId, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.post(`/api/tools/vmb/bookings/${bookingId}/face`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteBookingFace = (bookingId) =>
  api.delete(`/api/tools/vmb/bookings/${bookingId}/face`)

export const uploadTicketFace = (ticketId, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.post(`/api/tools/vmb/tickets/${ticketId}/face`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteTicketFace = (ticketId) =>
  api.delete(`/api/tools/vmb/tickets/${ticketId}/face`)

// ── BOOKING PROOFS (file bằng chứng) ─────────────────────────
//
// Independent of sharedTicketFace. ticketId null = chung; not null = riêng khách.

export const uploadBookingProof = (bookingId, file, ticketId = null) => {
  const fd = new FormData()
  fd.append('file', file)
  if (ticketId != null) fd.append('ticketId', String(ticketId))
  return api.post(`/api/tools/vmb/bookings/${bookingId}/proofs`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteBookingProof = (proofId) =>
  api.delete(`/api/tools/vmb/proofs/${proofId}`)

// ── INVOICES ─────────────────────────────────────────────────

export const replaceInvoiceFile = (invoiceId, slot, file) => {
  const fd = new FormData()
  fd.append('file', file)
  return api.put(`/api/tools/vmb/invoices/${invoiceId}/files/${slot}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteInvoiceFile = (invoiceId, slot) =>
  api.delete(`/api/tools/vmb/invoices/${invoiceId}/files/${slot}`)

export const setTicketPaid = (ticketId, status) =>
  api.patch(`/api/tools/vmb/tickets/${ticketId}/paid`, { status })

/**
 * Tạo hóa đơn.
 * @param bookingId
 * @param opts.status       'DRAFT' | 'ISSUED' | 'ADJUSTED'
 * @param opts.note         string
 * @param opts.ticketIds    number[]  — empty [] = chung cả booking
 * @param opts.draftFile / issuedFile / adjustmentFile / adjustmentRecordFile : File
 */
export const createInvoice = (bookingId, { status, note, invoiceNumbers, ticketIds = [], issuedDate, ...files } = {}) => {
  const fd = new FormData()
  fd.append('status', status)
  if (note) fd.append('note', note)
  if (invoiceNumbers) fd.append('invoiceNumbers', invoiceNumbers)
  if (issuedDate != null) fd.append('issuedDate', String(issuedDate))

  for (const tid of ticketIds) fd.append('ticketIds', String(tid))
  for (const [k, v] of Object.entries(files)) {
    if (v instanceof File) fd.append(k, v)
  }
  return api.post(`/api/tools/vmb/bookings/${bookingId}/invoices`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

/**
 * Update hóa đơn.
 *   - Truyền {ticketIds: [1,2]} để đổi sang subset đó.
 *   - Truyền {clearTicketIds: true} để đổi thành "chung cả booking" (empty).
 *   - Không truyền cả hai → giữ nguyên ticket scope hiện tại.
 */
export const updateInvoice = (invoiceId, { status, note, invoiceNumbers, ticketIds, clearTicketIds, issuedDate, ...files } = {}) => {
  const fd = new FormData()
  if (status) fd.append('status', status)
  if (note != null) fd.append('note', note)
  if (invoiceNumbers != null) fd.append('invoiceNumbers', invoiceNumbers)
  if (issuedDate != null) fd.append('issuedDate', String(issuedDate))
  if (clearTicketIds) fd.append('clearTicketIds', '1')
  else if (Array.isArray(ticketIds)) {
    for (const tid of ticketIds) fd.append('ticketIds', String(tid))
  }
  for (const [k, v] of Object.entries(files)) {
    if (v instanceof File) fd.append(k, v)
  }
  return api.put(`/api/tools/vmb/invoices/${invoiceId}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deleteInvoice = (invoiceId) =>
  api.delete(`/api/tools/vmb/invoices/${invoiceId}`)

// ── 2026-11-15: trang "Quản lý hóa đơn" (list phẳng, phân trang) ──
//   params: { page, size, q, status, fromDate, toDate }
//     status   : 'DRAFT' | 'ISSUED' | 'ADJUSTED' | '' (tất cả)
//     fromDate / toDate : epoch ms (lọc theo ngày tạo)
export const listInvoices = (params = {}) =>
  api.get('/api/tools/vmb/invoices', { params })

// 2026-11-15: Bản thể hiện hóa đơn NHÁP (xem tạm) của 1 đơn vị hóa đơn.
//   kind = 'GROUP' (hóa đơn group) | 'BOOKING' (vé chưa link của booking)
export const getInvoiceDraft = (bookingId, kind = 'BOOKING', anchorTicketId = null) =>
  api.get('/api/tools/vmb/invoices/draft', { params: { bookingId, kind, anchorTicketId } })

// Đẩy hóa đơn lên tab "Hóa đơn chưa phát hành" trên vinvoice.viettel.vn.
// KHÔNG cần USB token — kế toán ký + phát hành thủ công hoặc xóa trên web vinvoice.
export const createPendingInvoice = (bookingId, kind = 'BOOKING', anchorTicketId = null) =>
  api.post('/api/tools/vmb/invoices/create-pending', null, { params: { bookingId, kind, anchorTicketId } })

export const checkPendingInvoice = (bookingId, kind = 'BOOKING', anchorTicketId = null) =>
  api.post('/api/tools/vmb/invoices/check-pending', null, { params: { bookingId, kind, anchorTicketId } })

export const getReportDraftInvoices = (bookingIds) =>
  api.post('/api/tools/vmb/invoices/report-drafts', { bookingIds })

export const getInvoiceDetail = (bookingId, kind, anchorTicketId = null) =>
  api.get('/api/tools/vmb/invoices/detail', { params: { bookingId, kind, anchorTicketId } })

// ── COMPANIES & PASSENGERS & MEMBERSHIP ──────────────────────

export const listCompanies = () =>
  api.get('/api/tools/vmb/companies')

export const createCompany = (body) =>
  api.post('/api/tools/vmb/companies', body)

export const createCompanyBranch = (parentId, body) =>
  api.post(`/api/tools/vmb/companies/${parentId}/branches`, body)

export const updateCompany = (id, body) =>
  api.put(`/api/tools/vmb/companies/${id}`, body)

export const deleteCompany = (id) =>
  api.delete(`/api/tools/vmb/companies/${id}`)

export const listPassengers = (params = {}) =>
  api.get('/api/tools/vmb/passengers', { params })

export const getPassenger = (id) =>
  api.get(`/api/tools/vmb/passengers/${id}`)

export const createPassenger = (body) =>
  api.post('/api/tools/vmb/passengers', body)

export const updatePassenger = (id, body) =>
  api.put(`/api/tools/vmb/passengers/${id}`, body)

// 2026-11-08: PATCH riêng field referrerName — không cần gửi lại cả form.
export const updatePassengerReferrer = (id, referrerName) =>
  api.patch(`/api/tools/vmb/passengers/${id}/referrer`, { referrerName })

export const deletePassenger = (id) =>
  api.delete(`/api/tools/vmb/passengers/${id}`)

export const upsertPassengerDocument = (passengerId, type, fields = {}, file = null) => {
  const fd = new FormData()
  if (fields.docNumber != null) fd.append('docNumber', fields.docNumber)
  if (fields.nationality != null) fd.append('nationality', fields.nationality)
  if (fields.issueDate != null) fd.append('issueDate', fields.issueDate)
  if (fields.expiryDate != null) fd.append('expiryDate', fields.expiryDate)
  if (file instanceof File) fd.append('file', file)
  return api.put(`/api/tools/vmb/passengers/${passengerId}/documents/${type}`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const deletePassengerDocument = (passengerId, type) =>
  api.delete(`/api/tools/vmb/passengers/${passengerId}/documents/${type}`)

export const listMembershipCards = (passengerId) =>
  api.get(`/api/tools/vmb/passengers/${passengerId}/membership-cards`)

export const createMembershipCard = (passengerId, body) =>
  api.post(`/api/tools/vmb/passengers/${passengerId}/membership-cards`, body)

export const updateMembershipCard = (cardId, body) =>
  api.put(`/api/tools/vmb/membership-cards/${cardId}`, body)

export const deleteMembershipCard = (cardId) =>
  api.delete(`/api/tools/vmb/membership-cards/${cardId}`)

// ── LOOKUP + 2FA ─────────────────────────────────────────────

export const listLookup = (params = {}) =>
  api.get('/api/tools/vmb/lookup', { params })

export const createLookup = (body) =>
  api.post('/api/tools/vmb/lookup', body)

export const updateLookup = (id, body) =>
  api.put(`/api/tools/vmb/lookup/${id}`, body)

export const deleteLookup = (id) =>
  api.delete(`/api/tools/vmb/lookup/${id}`)

// 2026-10-10: Lưu thứ tự sau drag-and-drop ở tab Tra cứu.
export const reorderLookup = (ids) =>
  api.post('/api/tools/vmb/lookup/reorder', { ids })

export const revealLookupPassword = (id, code) =>
  api.post(`/api/tools/vmb/lookup/${id}/reveal`, { code })

export const lookupStatus = () =>
  api.get('/api/tools/vmb/lookup/status')

export const adminUnlockLookup = () =>
  api.post('/api/tools/vmb/admin/lookup/unlock')

// ══════════════════════════════════════════════════════════════
// PAYMENTS
// ══════════════════════════════════════════════════════════════

// ── 2026-10-12 rework: Payment theo HÓA ĐƠN ──

/**
 * Thu tiền cho 1 HÓA ĐƠN. Thay cho recordPayment(bookingId) cũ.
 */
export const recordInvoicePayment = (invoiceId, { amount, note, file, accountCode } = {}) => {
  const fd = new FormData()
  fd.append('amount', amount)
  if (note) fd.append('note', note)
  if (accountCode) fd.append('accountCode', accountCode)   // 2026-11-16: tài khoản nhận tiền
  if (file instanceof File) fd.append('file', file)
  return api.post(`/api/tools/vmb/invoices/${invoiceId}/payments`, fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const ensureBookingInvoice = (bookingId) =>
  api.post(`/api/tools/vmb/bookings/${bookingId}/ensure-invoice`)

export const batchPay = ({ bookingIds, note, file } = {}) => {
  const fd = new FormData()
  for (const id of bookingIds) fd.append('bookingIds', String(id))
  if (note) fd.append('note', note)
  if (file instanceof File) fd.append('file', file)
  return api.post('/api/tools/vmb/bookings/pay-batch', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

// 2026-11-20: Thu tiền hàng loạt THEO TỪNG BOOKING — mỗi booking trả phần riêng
//   của mình (kể cả khi dùng chung 1 hóa đơn nhóm với booking chủ).
export const collectPreview = (bookingIds = []) => {
  const fd = new FormData()
  for (const id of bookingIds) fd.append('bookingIds', String(id))
  return api.post('/api/tools/vmb/bookings/collect-preview', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

export const collectBatch = ({ rows = [], note, file, accountCode } = {}) => {
  const fd = new FormData()
  for (const r of rows) {
    fd.append('bookingIds', String(r.bookingId))
    fd.append('invoiceIds', String(r.invoiceId))
  }
  if (note) fd.append('note', note)
  if (accountCode) fd.append('accountCode', accountCode)
  if (file instanceof File) fd.append('file', file)
  return api.post('/api/tools/vmb/bookings/collect-batch', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
}

/** Lịch sử thu của 1 BOOKING (gộp mọi invoice). */
export const listPayments = (bookingId) =>
  api.get(`/api/tools/vmb/bookings/${bookingId}/payments`)

/** 2026-10-12: Lịch sử thu của 1 HÓA ĐƠN. */
export const listInvoicePayments = (invoiceId) =>
  api.get(`/api/tools/vmb/invoices/${invoiceId}/payments`)

export const deletePayment = (paymentId) =>
  api.delete(`/api/tools/vmb/payments/${paymentId}`)

// ══════════════════════════════════════════════════════════════
// FINANCE (Tài chính) — 2026-11-16
// ══════════════════════════════════════════════════════════════

/** Danh sách 5 tài khoản (Cash, HD, VCB, HNH_DEBT, VJ_DEPOSIT) kèm số dư. */
export const listFinanceAccounts = () =>
  api.get('/api/tools/vmb/finance/accounts')

/** Set số dư đầu kỳ cho 1 tài khoản. */
export const setAccountInitial = (accountId, amount) =>
  api.put(`/api/tools/vmb/finance/accounts/${accountId}/initial`, { amount })

/** Lịch sử giao dịch của 1 tài khoản, mới nhất trước. */
export const listAccountHistory = (accountId) =>
  api.get(`/api/tools/vmb/finance/accounts/${accountId}/transactions`)

/**
 * Tạo phiếu chi.
 *   body = { sourceCode, amount, beneficiary, beneficiaryCode?, note? }
 *     sourceCode      : 'CASH' | 'HD' | 'VCB'
 *     beneficiaryCode : null | 'HNH_DEBT' | 'VJ_DEPOSIT'
 */
export const createFinanceExpense = (body) =>
  api.post('/api/tools/vmb/finance/expense', body)

// ── 2026-11-19: Đồng bộ sổ cái ──────────────────────────────
/** body = { CASH, VCB, HD, HNH_DEBT, VJ_DEPOSIT } (số VND nguyên). */
export const syncFinanceLedger = (balancesByCode) =>
  api.post('/api/tools/vmb/finance/sync', balancesByCode)

// ── 2026-11-19: Tỷ giá ──────────────────────────────────────
/** { date, currencies:[...], today:{cur:rate}, latest:{cur:rate} } */
export const getExchangeRates = () =>
  api.get('/api/tools/vmb/finance/rates')

/** body = { date?, rates: { USD:"25930", ... } } */
export const saveExchangeRates = (body) =>
  api.post('/api/tools/vmb/finance/rates', body)

/** [{ date, rates:{cur:rate} }] mới nhất trước. */
export const getExchangeRateHistory = () =>
  api.get('/api/tools/vmb/finance/rates/history')

/** Tỷ giá mới nhất 1 tiền tệ → { currency, rate }. */
export const getLatestRate = (currency) =>
  api.get(`/api/tools/vmb/finance/rates/latest/${encodeURIComponent(currency)}`)