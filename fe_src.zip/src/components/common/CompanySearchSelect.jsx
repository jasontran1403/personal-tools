import { useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'

/**
 * CompanySearchSelect — combobox typeahead cho công ty, dùng chung cho:
 *   - Form booking (BookingFormModal)
 *   - Form hành khách (PassengerFormModal)
 *   - Bộ lọc Thông tin khách (PassengersTab)
 *
 * ── 2026-10-08 refactor ─────────────────────────────────────
 * Trước đây logic này nằm chôn trong BookingFormModal. Nay tách ra common để
 * tất cả nơi chọn công ty đều có input search (yêu cầu: thay `<select>` thuần
 * ở bộ lọc Thông tin khách).
 *
 * Props:
 *   value       — id công ty (number | null), null = "— Khách lẻ —"
 *   options     — mảng { id, label, isBranch? } đã flatten từ company tree
 *   onChange    — (id | null) => void
 *   placeholder — chữ hiện khi chưa chọn gì
 *   allowNone   — có cho chọn "— Khách lẻ / Tất cả —" không. Default: true.
 *   noneLabel   — nhãn cho option none, default "— Khách lẻ —"
 *   size        — 'sm' | 'md'
 *   className   — thêm class vào wrapper
 */
export default function CompanySearchSelect({
  value,
  options,
  onChange,
  placeholder = '— Khách lẻ —',
  // 2026-11-11: mặc định KHÔNG hiện mục none ảo nữa vì công ty
  // 'Khách lẻ' thật đã nằm trong options.
  allowNone = false,
  noneLabel = '— Khách lẻ —',
  size = 'md',
  className = '',
  // ── 2026-11-07: render dropdown qua portal để không bị cắt bởi overflow:hidden
  //   của modal cha. Dropdown position tính theo bounding rect của nút trigger.
  portal = false,
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [activeIdx, setActiveIdx] = useState(0)
  const [portalRect, setPortalRect] = useState(null)   // {left, top, width}
  const wrapRef = useRef(null)
  const inputRef = useRef(null)
  const listRef = useRef(null)
  const dropdownRef = useRef(null)   // 2026-11-07: trỏ tới panel (portal hoặc inline)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return options
    return options.filter(o => o.label.toLowerCase().includes(q))
  }, [query, options])

  useEffect(() => { setActiveIdx(0) }, [open, query])

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 0)
  }, [open])

  useEffect(() => {
    if (!open) return
    const onDown = (e) => {
      const inTrigger = wrapRef.current && wrapRef.current.contains(e.target)
      // 2026-11-07: Dropdown portal nằm NGOÀI wrapRef → check thêm dropdownRef
      const inDropdown = dropdownRef.current && dropdownRef.current.contains(e.target)
      if (!inTrigger && !inDropdown) {
        setOpen(false)
        setQuery('')
      }
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [open])

  useEffect(() => {
    if (!open || !listRef.current) return
    const el = listRef.current.querySelector(`[data-idx="${activeIdx}"]`)
    if (el) el.scrollIntoView({ block: 'nearest' })
  }, [activeIdx, open])

  // ── 2026-11-07: Tính lại vị trí dropdown khi mở hoặc scroll/resize ──
  useEffect(() => {
    if (!open || !portal) return
    const recompute = () => {
      const el = wrapRef.current
      if (!el) return
      const r = el.getBoundingClientRect()
      setPortalRect({ left: r.left, top: r.bottom, width: r.width })
    }
    recompute()
    window.addEventListener('scroll', recompute, true)
    window.addEventListener('resize', recompute)
    return () => {
      window.removeEventListener('scroll', recompute, true)
      window.removeEventListener('resize', recompute)
    }
  }, [open, portal])

  const selected = useMemo(
    () => options.find(o => String(o.id) === String(value)) || null,
    [options, value]
  )

  const pick = (opt) => {
    onChange(opt ? opt.id : null)
    setOpen(false)
    setQuery('')
  }

  // Index 0 = none (nếu allowNone), các option khác bắt đầu từ index 1
  const noneOffset = allowNone ? 1 : 0
  const totalCount = noneOffset + filtered.length

  const onKeyDown = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActiveIdx(i => Math.min(totalCount - 1, i + 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActiveIdx(i => Math.max(0, i - 1)) }
    else if (e.key === 'Enter') {
      e.preventDefault()
      if (allowNone && activeIdx === 0) pick(null)
      else pick(filtered[activeIdx - noneOffset])
    }
    else if (e.key === 'Escape') { e.preventDefault(); setOpen(false); setQuery('') }
  }

  const btnPad = size === 'sm' ? 'px-2 py-1.5 text-xs' : 'px-3 py-2 text-sm'

  return (
    <div ref={wrapRef} className={`relative ${className}`}>
      <button type="button"
        onClick={() => setOpen(o => !o)}
        className={`${btnPad} w-full inline-flex items-center justify-between gap-2 rounded-lg
          border border-gray-300 bg-white text-left transition
          hover:border-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none`}
        aria-haspopup="listbox" aria-expanded={open}>
        <span className={`truncate ${selected ? 'text-gray-900' : 'text-gray-400 italic'}`}>
          {selected ? selected.label.replace(/^\s+↳\s/, '↳ ') : placeholder}
        </span>
        <span className="text-gray-400 text-xs shrink-0">▾</span>
      </button>

      {open && !portal && (
        <DropdownPanel
          panelRef={dropdownRef}
          inputRef={inputRef} listRef={listRef}
          query={query} setQuery={setQuery} onKeyDown={onKeyDown}
          allowNone={allowNone} activeIdx={activeIdx} setActiveIdx={setActiveIdx}
          value={value} noneLabel={noneLabel} filtered={filtered}
          noneOffset={noneOffset} pick={pick}
          className="absolute z-50 left-0 right-0 mt-1"
        />
      )}
      {open && portal && portalRect && createPortal(
        <DropdownPanel
          panelRef={dropdownRef}
          inputRef={inputRef} listRef={listRef}
          query={query} setQuery={setQuery} onKeyDown={onKeyDown}
          allowNone={allowNone} activeIdx={activeIdx} setActiveIdx={setActiveIdx}
          value={value} noneLabel={noneLabel} filtered={filtered}
          noneOffset={noneOffset} pick={pick}
          style={{
            position: 'fixed',
            left: portalRect.left,
            top: portalRect.top + 4,
            width: portalRect.width,
            zIndex: 2000,
          }}
        />,
        document.body
      )}
    </div>
  )
}

function DropdownPanel({
  panelRef,
  inputRef, listRef, query, setQuery, onKeyDown,
  allowNone, activeIdx, setActiveIdx, value, noneLabel, filtered,
  noneOffset, pick, className = '', style,
}) {
  return (
    <div ref={panelRef}
      className={`${className} rounded-lg bg-white shadow-lg border border-gray-200 overflow-hidden`}
      style={style}
      // Chặn modal "click outside" đóng theo (modal nghe mousedown ngoài panel)
      onMouseDown={e => e.stopPropagation()}>
      <div className="p-1.5 border-b border-gray-100 bg-gray-50">
        <input ref={inputRef}
          type="text" value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="Tìm công ty…"
          className="w-full px-2 py-1.5 rounded-md border border-gray-200 bg-white text-sm
            focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none" />
      </div>
      <div ref={listRef} className="max-h-56 overflow-y-auto py-0.5">
        {allowNone && (
          <OptionRow
            idx={0} activeIdx={activeIdx} setActiveIdx={setActiveIdx}
            onPick={() => pick(null)}
            isSelected={value == null || value === ''}
            label={noneLabel} italic
          />
        )}
        {filtered.length === 0 ? (
          <div className="px-3 py-3 text-xs text-gray-400 italic text-center">
            Không tìm thấy công ty phù hợp
          </div>
        ) : filtered.map((o, i) => (
          <OptionRow
            key={o.id}
            idx={i + noneOffset} activeIdx={activeIdx} setActiveIdx={setActiveIdx}
            onPick={() => pick(o)}
            isSelected={String(o.id) === String(value)}
            label={o.label}
          />
        ))}
      </div>
    </div>
  )
}

function OptionRow({ idx, activeIdx, setActiveIdx, onPick, isSelected, label, italic }) {
  const isActive = idx === activeIdx
  return (
    <button type="button"
      data-idx={idx}
      onMouseEnter={() => setActiveIdx(idx)}
      onClick={onPick}
      className={`w-full text-left px-3 py-1.5 text-sm flex items-center gap-2 transition
        ${isActive ? 'bg-blue-50 text-blue-900' : 'text-gray-800 hover:bg-gray-50'}
        ${italic ? 'italic text-gray-500' : ''}`}>
      <span className="flex-1 truncate whitespace-pre">{label}</span>
      {isSelected && <span className="text-blue-600 text-xs">✓</span>}
    </button>
  )
}

/**
 * Flatten company tree (có parent/branch) thành list phẳng với branch được
 * indent "  ↳ ". Dùng cho options của CompanySearchSelect.
 */
/**
 * Nhận biết công ty "Khách lẻ" seed sẵn trong DB (thường id = 1). Trước đây
 * dropdown có hai mục "Khách lẻ": một ảo (companyId = null) do allowNone và
 * một thật (id = 1), nhưng BE lại tự ghép null → id 1 lúc lưu. Giờ chỉ trả
 * về đúng công ty thật và luôn đặt nó lên đầu danh sách.
 */
export function isWalkInCompany(c) {
  if (!c) return false
  if (c.id === 1 && !c.parentId) return true
  const name = (c.name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[đĐ]/g, 'd').trim().toLowerCase()
  return !c.parentId && (name === 'khach le' || name === 'khach le (mac dinh)')
}

/**
 * Trả về id của công ty "Khách lẻ" trong danh sách (hoặc 1 nếu không tìm thấy
 * — id seed mặc định của VmbSeedRunner).
 */
export function walkInCompanyId(companies) {
  const found = (companies || []).find(isWalkInCompany)
  return found ? found.id : 1
}

export function companyOptions(companies) {
  const walkIn = (companies || []).find(isWalkInCompany) || null
  const roots = (companies || []).filter(c => !c.parentId && !isWalkInCompany(c))
    .sort((a, b) => a.name.localeCompare(b.name, 'vi'))
  const byParent = new Map()
  for (const c of companies) {
    if (c.parentId) {
      if (!byParent.has(c.parentId)) byParent.set(c.parentId, [])
      byParent.get(c.parentId).push(c)
    }
  }
  const out = []
  // 2026-11-11: Mục Khách lẻ luôn đứng đầu, nhãn thống nhất với placeholder cũ.
  if (walkIn) out.push({ id: walkIn.id, label: '— Khách lẻ —', isBranch: false, isWalkIn: true })
  for (const r of roots) {
    out.push({ id: r.id, label: r.name, isBranch: false })
    const branches = (byParent.get(r.id) || []).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
    for (const b of branches) {
      out.push({ id: b.id, label: `  ↳ ${b.name}`, isBranch: true })
    }
  }
  return out
}