import { useEffect, useRef, useState } from 'react'
import toast from 'react-hot-toast'
import Modal from '../common/Modal'
import RouteInput from './RouteInput'
import PriceInput from './PriceInput'
import ZoomablePreview from './ZoomablePreview'
import { getBooking, createBooking, updateBooking, listCompanies, uploadTicketFile, deleteTicketFile } from '../../services/vmbApi'

/**
 * Form thêm/sửa BOOKING (kèm segments + N tickets).
 *
 * Bố cục:
 *   1. Thông tin chung: loại, hãng, mã booking, hành trình (RouteInput lo giờ), ghi chú, currency + tỷ giá
 *   2. Danh sách vé (tickets): thêm/xóa động, mỗi vé có 4 ô giá + tên + số vé + ghi chú
 *
 * Không thao tác file / hóa đơn trong form này — làm ở TicketDetailModal /
 * InvoiceManagerModal sau khi lưu.
 *
 * Chú ý: 4 ô giá lưu dạng String (BE cũng lưu String) để giữ đúng định dạng.
 * PriceInput handle format-on-blur.
 */
export default function BookingFormModal({ mode = 'create', bookingId, onClose, onSaved }) {
  const isEdit = mode === 'edit'
  const [loading, setLoading] = useState(isEdit)
  const [busy, setBusy] = useState(false)
  const [companies, setCompanies] = useState([])
  const [preview, setPreview] = useState(null)   // { path, name } cho ZoomablePreview

  // Load danh sách công ty (gồm cả chi nhánh) — 1 lần khi mở
  useEffect(() => {
    listCompanies()
      .then(res => setCompanies(res.data?.data || []))
      .catch(() => {})  // silent — chỉ ảnh hưởng dropdown, không critical
  }, [])

  const [form, setForm] = useState(() => ({
    kind: 'NEW',
    airlineCode: '',
    bookingCode: '',
    routeStr: '',
    currency: 'VND',
    exchangeRate: '',
    note: '',
    segments: [],
    tickets: [newTicket()],
  }))

  // Load booking cho mode edit
  useEffect(() => {
    if (!isEdit) return
    ;(async () => {
      try {
        const res = await getBooking(bookingId)
        const b = res.data?.data
        if (!b) throw new Error('Không tìm thấy')
        setForm({
          kind: b.kind || 'NEW',
          airlineCode: b.airlineCode || '',
          bookingCode: b.bookingCode || '',
          routeStr: b.routeStr || '',
          currency: b.currency || 'VND',
          exchangeRate: b.exchangeRate || '',
          note: b.note || '',
          segments: (b.segments || []).map(s => ({
            fromCode: s.fromCode, toCode: s.toCode,
            departLocalMs: s.departLocalMs, segOrder: s.segOrder,
          })),
          tickets: (b.tickets || []).map(t => ({
            id: t.id,
            passengerName: t.passengerName || '',
            companyId:     t.companyId     || null,
            ticketNumber:  t.ticketNumber  || '',
            basePrice:     t.basePrice     || '',
            collectionFee: t.collectionFee || '',
            serviceFee:    t.serviceFee    || '',
            issuanceFee:   t.issuanceFee   || '',
            paidStatus:    t.paidStatus    || 'PENDING',
            note:          t.note          || '',
            _existingFiles: t.files || [],   // load lên để hiển thị + cho xóa
            _pendingFiles: [],
          })),
        })
      } catch (e) {
        toast.error(e?.response?.data?.message || 'Không tải được booking')
        onClose()
      } finally {
        setLoading(false)
      }
    })()
  }, [isEdit, bookingId, onClose])

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const setTicket = (i, patch) => setForm(f => ({
    ...f, tickets: f.tickets.map((t, idx) => idx === i ? { ...t, ...patch } : t),
  }))
  const addTicket = () => setForm(f => ({ ...f, tickets: [...f.tickets, newTicket()] }))
  const removeTicket = (i) => setForm(f => ({
    ...f, tickets: f.tickets.length <= 1 ? f.tickets : f.tickets.filter((_, idx) => idx !== i),
  }))

  const submit = async (e) => {
    e.preventDefault()
    if (!form.tickets[0]?.passengerName?.trim()) {
      return toast.error('Vé đầu tiên cần có tên khách hàng')
    }
    if (form.currency === 'USD' && !form.exchangeRate) {
      return toast.error('Vé USD cần nhập tỷ giá')
    }
    setBusy(true)
    try {
      // Body chỉ gồm dữ liệu vé — bỏ file state khỏi payload JSON
      const body = {
        ...form,
        segments: (form.segments || []).map((s, i) => ({ ...s, segOrder: i })),
        tickets: form.tickets.map(({ _existingFiles, _pendingFiles, ...rest }) => rest),
      }
      const res = isEdit
        ? await updateBooking(bookingId, body)
        : await createBooking(body)

      // Response trả về BookingIO có tickets với ID mới. Upload pending files.
      // Match theo INDEX vì BE trả về tickets đúng thứ tự client gửi.
      const savedTickets = res.data?.data?.tickets || []
      let uploadedCount = 0
      let uploadErrors = 0

      for (let i = 0; i < form.tickets.length; i++) {
        const pending = form.tickets[i]._pendingFiles || []
        const savedId = savedTickets[i]?.id
        if (!savedId || pending.length === 0) continue

        for (const file of pending) {
          try {
            await uploadTicketFile(savedId, file)
            uploadedCount++
          } catch (err) {
            uploadErrors++
            console.error('Upload mặt vé thất bại:', file.name, err)
          }
        }
      }

      // Toast tổng hợp
      const base = isEdit ? 'Đã cập nhật' : 'Đã tạo booking'
      if (uploadedCount > 0 && uploadErrors === 0) {
        toast.success(`${base} · đã upload ${uploadedCount} mặt vé`)
      } else if (uploadErrors > 0) {
        toast.error(`${base} nhưng ${uploadErrors}/${uploadedCount + uploadErrors} mặt vé upload thất bại`)
      } else {
        toast.success(base)
      }
      onSaved()
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Lưu thất bại')
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
    <Modal
      open
      onClose={busy ? undefined : onClose}
      title={isEdit ? 'Sửa booking' : 'Thêm booking mới'}
      size="xl"
      closeOnBackdrop={!busy}
      footer={
        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose} disabled={busy}
            className="px-4 py-2 text-sm rounded-lg text-gray-600 hover:bg-gray-200 disabled:opacity-50">
            Hủy
          </button>
          <button type="submit" form="bf-form" disabled={busy || loading}
            className="px-4 py-2 text-sm font-semibold rounded-lg bg-blue-600 text-white
                       hover:bg-blue-700 disabled:opacity-50">
            {busy ? 'Đang lưu…' : (isEdit ? 'Lưu thay đổi' : 'Tạo booking')}
          </button>
        </div>
      }
    >
      {loading ? (
        <div className="py-10 text-center text-gray-400 text-sm">Đang tải…</div>
      ) : (
        <form id="bf-form" onSubmit={submit} className="space-y-4">
          {/* ── SECTION 1: Chung ───────────────────────── */}
          <Section title="Thông tin chung">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Field label="Loại giao dịch" span={2}>
                <select value={form.kind} onChange={e => setField('kind', e.target.value)}
                  className="input">
                  <option value="NEW">Mua mới</option>
                  <option value="EXCHANGE">Đổi vé</option>
                  <option value="REFUND">Hoàn vé</option>
                  <option value="SERVICE">Dịch vụ</option>
                </select>
              </Field>
              <Field label="Hãng bay">
                <input type="text" value={form.airlineCode}
                  onChange={e => setField('airlineCode', e.target.value.toUpperCase().slice(0, 3))}
                  placeholder="VJ, VN…" className="input font-mono uppercase" />
              </Field>
              <Field label="Mã booking">
                <input type="text" value={form.bookingCode}
                  onChange={e => setField('bookingCode', e.target.value.toUpperCase())}
                  placeholder="ABC123" className="input font-mono uppercase" />
              </Field>
            </div>

            <div className="mt-3">
              <RouteInput
                routeStr={form.routeStr}
                segments={form.segments}
                onChange={({ routeStr, segments }) => setForm(f => ({ ...f, routeStr, segments }))}
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
              <Field label="Đồng tiền">
                <select value={form.currency}
                  onChange={e => setField('currency', e.target.value)}
                  className="input">
                  <option value="VND">VND</option>
                  <option value="USD">USD</option>
                </select>
              </Field>
              {form.currency === 'USD' && (
                <Field label="Tỷ giá (1 USD = ? VND)" span={3}>
                  <input type="text" value={form.exchangeRate}
                    onChange={e => setField('exchangeRate', e.target.value)}
                    placeholder="24500" className="input tabular-nums font-mono" />
                </Field>
              )}
</div>

            <Field label="Ghi chú chung (booking)">
              <textarea rows={2} value={form.note}
                onChange={e => setField('note', e.target.value)}
                className="input resize-none" placeholder="Ghi chú tùy chọn cho cả booking" />
            </Field>
          </Section>

          {/* ── SECTION 2: Tickets ─────────────────────── */}
          <Section title={`Vé (${form.tickets.length})`}
            action={<button type="button" onClick={addTicket}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800">+ Thêm vé</button>}
          >
            <div className="space-y-3">
              {form.tickets.map((t, i) => {
                // Label phí dịch vụ theo kind — để người dùng biết đang nhập gì
                const feeLabel = form.kind === 'REFUND'   ? 'Phí hoàn'
                              : form.kind === 'EXCHANGE'  ? 'Phí đổi'
                              : form.kind === 'SERVICE'   ? 'Phí dịch vụ'
                              : 'Phí dịch vụ / cộng thêm'
                return (
                  <div key={i} className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-xs font-bold text-gray-700">Vé #{i + 1}</div>
                      {form.tickets.length > 1 && (
                        <button type="button" onClick={() => removeTicket(i)}
                          className="text-xs text-rose-600 hover:text-rose-800 font-semibold">
                          × Bỏ vé này
                        </button>
                      )}
                    </div>

                    <Field label="Công ty">
                      <select value={t.companyId || ''}
                        onChange={e => setTicket(i, { companyId: e.target.value ? Number(e.target.value) : null })}
                        className="input">
                        <option value="">— Khách lẻ —</option>
                        {companyOptions(companies).map(opt => (
                          <option key={opt.id} value={opt.id}>{opt.label}</option>
                        ))}
                      </select>
                    </Field>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Field label="Tên khách hàng">
                        <input type="text" value={t.passengerName}
                          onChange={e => setTicket(i, { passengerName: e.target.value })}
                          className="input" placeholder="NGUYEN VAN A" />
                      </Field>
                      <Field label="Số vé">
                        <input type="text" value={t.ticketNumber}
                          onChange={e => setTicket(i, { ticketNumber: e.target.value })}
                          className="input font-mono" placeholder="738-1234567890 (có thể để trống)" />
                      </Field>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                      <Field label="Giá gốc (chưa thu hộ)">
                        <PriceInput value={t.basePrice} currency={form.currency}
                          onChange={v => setTicket(i, { basePrice: v })} />
                      </Field>
                      <Field label="Phí thu hộ">
                        <PriceInput value={t.collectionFee} currency={form.currency}
                          onChange={v => setTicket(i, { collectionFee: v })} />
                      </Field>
                      <Field label={feeLabel}>
                        <PriceInput value={t.serviceFee} currency={form.currency}
                          onChange={v => setTicket(i, { serviceFee: v })} />
                      </Field>
                      <Field label="Phí xuất vé">
                        <PriceInput value={t.issuanceFee} currency={form.currency}
                          onChange={v => setTicket(i, { issuanceFee: v })} />
                      </Field>
                    </div>

                    <Field label="Ghi chú vé">
                      <input type="text" value={t.note}
                        onChange={e => setTicket(i, { note: e.target.value })}
                        className="input" placeholder="Ghi chú tùy chọn" />
                    </Field>

                    <TicketFilesField
                      ticket={t}
                      onAddFiles={(files) => setTicket(i, {
                        _pendingFiles: [...(t._pendingFiles || []), ...files],
                      })}
                      onRemovePending={(idx) => setTicket(i, {
                        _pendingFiles: (t._pendingFiles || []).filter((_, k) => k !== idx),
                      })}
                      onDeleteExisting={async (file) => {
                        if (!window.confirm(`Xóa mặt vé "${file.originalName}"?`)) return
                        try {
                          await deleteTicketFile(file.id)
                          toast.success('Đã xóa mặt vé')
                          setTicket(i, {
                            _existingFiles: (t._existingFiles || []).filter(f => f.id !== file.id),
                          })
                        } catch (err) {
                          toast.error(err?.response?.data?.message || 'Xóa thất bại')
                        }
                      }}
                      onPreview={(file) => setPreview({
                        path: file.url, name: file.originalName,
                      })}
                    />
                  </div>
                )
              })}
            </div>
          </Section>

          <style>{`
            .input {
              width: 100%;
              padding: 0.5rem 0.75rem;
              border-radius: 0.5rem;
              border: 1px solid #d1d5db;
              background: #fff;
              font-size: 0.875rem;
              outline: none;
              transition: border-color .15s, box-shadow .15s;
            }
            .input:focus {
              border-color: #3b82f6;
              box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
            }
          `}</style>
        </form>
      )}
    </Modal>

    {preview && (
      <ZoomablePreview
        filePath={preview.path}
        fileName={preview.name}
        title={preview.name}
        onClose={() => setPreview(null)}
      />
    )}
    </>
  )
}

function newTicket() {
  return {
    passengerName: '', companyId: null, ticketNumber: '',
    basePrice: '', collectionFee: '', serviceFee: '', issuanceFee: '',
    paidStatus: 'PENDING', note: '',
    _existingFiles: [],    // files đã upload (chỉ có khi edit); [{id, url, originalName, contentType, sizeBytes}]
    _pendingFiles: [],     // File[] chưa upload — sẽ upload sau khi save booking
  }
}

function Section({ title, action, children }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide">{title}</h3>
        {action}
      </div>
      {children}
    </div>
  )
}

function Field({ label, span, children }) {
  const spanClass = span === 2 ? 'sm:col-span-2' : span === 3 ? 'sm:col-span-3' : span === 4 ? 'sm:col-span-4' : ''
  return (
    <label className={`block ${spanClass}`}>
      <div className="text-[11px] font-semibold text-gray-600 mb-1">{label}</div>
      {children}
    </label>
  )
}


/**
 * Chuyển list phẳng company (có parentId) thành options cho <select>. Thứ tự:
 *   Công ty gốc A
 *     ↳ Chi nhánh A1
 *     ↳ Chi nhánh A2
 *   Công ty gốc B
 *     ↳ Chi nhánh B1
 *
 * Chi nhánh có prefix "↳ " để user nhìn ra ngay đó là chi nhánh.
 */
function companyOptions(companies) {
  const roots    = companies.filter(c => !c.parentId).sort((a, b) => a.name.localeCompare(b.name, 'vi'))
  const byParent = new Map()
  for (const c of companies) {
    if (c.parentId) {
      if (!byParent.has(c.parentId)) byParent.set(c.parentId, [])
      byParent.get(c.parentId).push(c)
    }
  }
  const out = []
  for (const r of roots) {
    out.push({ id: r.id, label: r.name })
    const branches = (byParent.get(r.id) || []).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
    for (const b of branches) {
      out.push({ id: b.id, label: `  ↳ ${b.name}` })
    }
  }
  return out
}

/**
 * Chỗ upload / quản lý mặt vé cho 1 ticket trong BookingFormModal.
 *
 * ── Behavior ──────────────────────────────────────────
 *   - Files đã có (chỉ khi EDIT): chip màu xanh, click mở preview, có nút ×
 *     gọi deleteTicketFile ngay (không chờ save booking)
 *   - Files pending (chưa upload): chip màu xám với icon ⏳; user có thể
 *     bấm × để bỏ. Upload sẽ xảy ra AFTER khi save booking (submit)
 *   - Nút "+ Thêm mặt vé" mở file picker (multiple, image/pdf)
 *
 * Vì tạo booking mới thì ticket CHƯA có id → không upload được ngay. Vẫn
 * cho user chọn nhiều file, giữ trong state; sau `createBooking` thành công
 * thì lần lượt gọi `uploadTicketFile(newTicketId, file)`.
 */
function TicketFilesField({ ticket, onAddFiles, onRemovePending, onDeleteExisting, onPreview }) {
  const existing = ticket._existingFiles || []
  const pending  = ticket._pendingFiles || []
  const inputRef = useRef(null)

  return (
    <div>
      <div className="text-[11px] font-semibold text-gray-600 mb-1 flex items-center gap-2">
        <span>Mặt vé</span>
        {(existing.length + pending.length) > 0 && (
          <span className="text-[10px] font-normal text-gray-400">
            {existing.length + pending.length} file
            {pending.length > 0 && ` (${pending.length} chờ upload)`}
          </span>
        )}
      </div>
      <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-lg border border-dashed border-gray-300 bg-gray-50/50 min-h-[44px]">
        {existing.map(f => (
          <FileChip key={`e-${f.id}`}
            name={f.originalName || 'file'}
            icon="📎"
            variant="existing"
            onClick={() => onPreview(f)}
            onDelete={() => onDeleteExisting(f)}
          />
        ))}
        {pending.map((f, k) => (
          <FileChip key={`p-${k}`}
            name={f.name}
            icon="⏳"
            variant="pending"
            title="Sẽ upload khi bấm Lưu"
            onDelete={() => onRemovePending(k)}
          />
        ))}

        <input ref={inputRef} type="file" multiple hidden
          accept="image/*,application/pdf"
          onChange={e => {
            const files = Array.from(e.target.files || [])
            if (files.length) onAddFiles(files)
            e.target.value = ''
          }} />
        <button type="button"
          onClick={() => inputRef.current?.click()}
          className="text-[11px] px-2 py-1 rounded-md bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 font-semibold">
          + Thêm mặt vé
        </button>
      </div>
    </div>
  )
}

function FileChip({ name, icon, variant, onClick, onDelete, title }) {
  const cls = variant === 'existing'
    ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
    : 'bg-gray-200 text-gray-700'
  return (
    <span className={`inline-flex items-center gap-1 pl-1.5 pr-0.5 py-0.5 rounded-md text-[11px] max-w-[220px] ${cls}`}
          title={title || name}>
      <button type="button" onClick={onClick} disabled={!onClick}
        className={`inline-flex items-center gap-1 min-w-0 ${onClick ? 'hover:underline' : ''}`}>
        <span>{icon}</span>
        <span className="truncate">{name}</span>
      </button>
      <button type="button" onClick={onDelete}
        className="w-5 h-5 rounded-md hover:bg-black/10 shrink-0 text-current">×</button>
    </span>
  )
}