import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import toast from 'react-hot-toast'
import ConfirmModal from '../common/ConfirmModal'
import Modal from '../common/Modal'
import BookingFormModal from './BookingFormModal'
import TicketFaceModal from './TicketFaceModal'
import InvoiceManagerModal from './InvoiceManagerModal'
import PresentationModal from './PresentationModal'
import UploadOptionsModal from './UploadOptionsModal'
import TicketNoteModal from './TicketNoteModal'
import BookingTotalsCard from './BookingTotalsCard'
import PaymentModal from './PaymentModal'
import InvoicePickerModal from './InvoicePickerModal'
import BatchPaymentModal from './BatchPaymentModal'
import DateRangePicker from '../common/DateRangePicker'
import CompanySearchSelect, { companyOptions } from '../common/CompanySearchSelect'
import { listBookings, deleteBooking, totalsBookings, listCompanies } from '../../services/vmbApi'
import { parseAmount, formatMoney, sumAmounts, toVnd } from '../../lib/money'
import { primaryDeparture } from '../../lib/countdown'
import { formatDepart } from '../../lib/airportTz'

/**
 * ── 2026-09-15 ──────────────────────────────────────────────
 * - Click MÃ BOOKING → mở mặt vé chung (shared) hoặc chọn khách (per-ticket).
 * - Click SỐ VÉ → mở mặt vé riêng (per-ticket) hoặc face chung (shared).
 * - Nút action 📄 = "Xem chi tiết mặt vé".
 *
 * ── Cải tiến hiển thị (2026-09-15 chiều) ────────────────────
 * 1. Group tickets THEO CÔNG TY trong 1 booking. Vé cùng công ty đứng liền
 *    nhau; ô công ty MERGE (rowspan) qua các vé cùng công ty.
 *    Ví dụ booking có 4 vé Cty A/B/A/A → sắp lại A-A-A-B, ô Cty A rowspan=3.
 *    Thứ tự công ty giữ theo thứ tự xuất hiện đầu tiên trong booking gốc
 *    (không sort alphabet — để user thấy "cty đầu tiên đặt" ở trên).
 *
 * 2. Cột "Booking / số vé" → chỉ còn "Booking" (mã booking, rowspan cả booking).
 *    Số vé chuyển sang cột "Khách hàng":
 *        Dòng trên: tên khách
 *        Dòng dưới: số vé (font mono, click được để mở face)
 */
export default function TicketsTab() {
  const [rows, setRows]           = useState([])
  const [totals, setTotals]       = useState([])
  const [loading, setLoading]     = useState(true)
  const [totalsLoading, setTotalsLoading] = useState(false)

  const [q, setQ]                 = useState('')
  const [fromSale, setFromSale]   = useState('')
  const [toSale, setToSale]       = useState('')
  // 2026-10-10: Filter trạng thái thanh toán. '' = tất cả, 'PAID' = đã thanh toán,
  // 'UNPAID' = chưa thanh toán (gồm cả PARTIAL).
  const [paymentStatus, setPaymentStatus] = useState('')
  // ── 2026-10-09: Filter theo công ty ──
  // null = Tất cả (mặc định). Số = id công ty.
  // List công ty lấy từ listCompanies (dùng chung với tab Thông tin khách).
  // Filter áp dụng client-side: giữ booking nếu có ÍT NHẤT 1 vé có companyId
  // trùng; các số liệu ở card tổng sẽ tính lại từ các vé khớp filter.
  const [companyId, setCompanyId]   = useState(null)
  const [companies, setCompanies]   = useState([])
  const [page, setPage]           = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal]         = useState(0)

  const [selectedIds, setSelectedIds] = useState(() => new Set())

  const [form, setForm]           = useState(null)
  const [face, setFace]           = useState(null)   // { booking, ticketId }
  const [invMgr, setInvMgr]       = useState(null)
  // 2026-10-12: payFor giờ chứa { booking, invoice } — invoice BẮT BUỘC.
  const [payFor, setPayFor]       = useState(null)
  // Picker modal khi booking có >1 invoice.
  const [invoicePicker, setInvoicePicker] = useState(null) // booking | null
  const [batchPay, setBatchPay]   = useState(null)
  const [noteView, setNoteView]   = useState(null)
  const [confirmDel, setConfirmDel] = useState(null)
  // ── 2026-09-19: Xuất trình + Upload ──
  const [presentation, setPresentation] = useState(null) // booking
  const [uploadFor, setUploadFor]       = useState(null) // booking
  const [exporting, setExporting]       = useState(false)

  const [nowTick, setNowTick] = useState(Date.now())
  useEffect(() => {
    const id = setInterval(() => setNowTick(Date.now()), 30_000)
    return () => clearInterval(id)
  }, [])

  const filterParams = useMemo(() => {
    const p = {}
    if (q)             p.q = q
    if (fromSale)      p.fromSale = new Date(fromSale + 'T00:00:00').getTime()
    if (toSale)        p.toSale   = new Date(toSale + 'T23:59:59').getTime()
    if (paymentStatus) p.paymentStatus = paymentStatus
    return p
  }, [q, fromSale, toSale, paymentStatus])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await listBookings({ ...filterParams, page, size: 50 })
      const d = res.data?.data
      setRows(d?.content || [])
      setTotalPages(d?.totalPages || 1)
      setTotal(d?.totalElements || 0)
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Không tải được danh sách vé')
    } finally {
      setLoading(false)
    }
  }, [filterParams, page])

  const loadTotals = useCallback(async () => {
    setTotalsLoading(true)
    try {
      const res = await totalsBookings(filterParams)
      setTotals(res.data?.data || [])
    } catch { /* silent */ }
    finally { setTotalsLoading(false) }
  }, [filterParams])

  useEffect(() => { load() }, [load])
  useEffect(() => { loadTotals() }, [loadTotals])

  // Load danh sách công ty 1 lần cho dropdown filter
  useEffect(() => {
    let cancel = false
    listCompanies()
      .then(res => { if (!cancel) setCompanies(res.data?.data || []) })
      .catch(() => { /* silent — filter vẫn work với 0 công ty */ })
    return () => { cancel = true }
  }, [])

  const flatCompanies = useMemo(() => companyOptions(companies || []), [companies])

  // ── Filter client-side theo companyId ─────────────────────
  // Booking match nếu có ≥1 vé có companyId trùng với filter.
  const filteredRows = useMemo(() => {
    if (companyId == null) return rows
    return rows.filter(b => (b.tickets || []).some(t => t.companyId === companyId))
  }, [rows, companyId])

  // ── Totals: khi có filter công ty thì tính lại từ các vé khớp filter.
  //    Khi không có filter thì dùng totals từ BE (tổng toàn hệ thống theo
  //    q + date range).
  const displayTotals = useMemo(() => {
    if (companyId == null) return totals
    // 2026-10-12: Split theo fee.currency, không chỉ booking.currency.
    const agg = {
      VND: { subTotal: 0, issuanceFee: 0, grandTotal: 0, ticketCount: 0 },
      USD: { subTotal: 0, issuanceFee: 0, grandTotal: 0, ticketCount: 0 },
    }
    for (const b of filteredRows) {
      const cur = b.currency === 'USD' ? 'USD' : 'VND'
      for (const t of (b.tickets || [])) {
        if (t.companyId !== companyId) continue
        const baseColl = sumAmounts(t.basePrice, t.collectionFee)
        const issuanceFee = parseAmount(t.issuanceFee) || 0
        // basePrice/collection/issuance luôn vào bucket booking.currency
        agg[cur].subTotal    += baseColl
        agg[cur].issuanceFee += issuanceFee
        agg[cur].grandTotal  += baseColl + issuanceFee
        agg[cur].ticketCount += 1
        // Fees: cộng theo currency riêng
        const fByCur = sumFeesByCurrency(t.fees, cur)
        agg.VND.subTotal   += fByCur.VND
        agg.VND.grandTotal += fByCur.VND
        agg.USD.subTotal   += fByCur.USD
        agg.USD.grandTotal += fByCur.USD
      }
    }
    return ['VND', 'USD'].map(c => ({
      currency: c,
      subTotal:    formatMoney(agg[c].subTotal,    c, { withUnit: false }),
      issuanceFee: formatMoney(agg[c].issuanceFee, c, { withUnit: false }),
      grandTotal:  formatMoney(agg[c].grandTotal,  c, { withUnit: false }),
      ticketCount: agg[c].ticketCount,
    }))
  }, [companyId, filteredRows, totals])

  useEffect(() => {
    setSelectedIds(prev => {
      const valid = new Set(filteredRows.map(r => r.id))
      const next = new Set()
      for (const id of prev) if (valid.has(id)) next.add(id)
      return next
    })
  }, [filteredRows])

  const qTimer = useRef(null)
  const onSearch = (v) => {
    if (qTimer.current) clearTimeout(qTimer.current)
    qTimer.current = setTimeout(() => { setPage(0); setQ(v) }, 300)
  }

  // 2026-10-10: Chặn chọn booking đã PAID (không có gì để thu nữa).
  const isPaidBooking = (b) => (b?.paymentStatus === 'PAID')

  const toggleSelect = (id) => {
    const b = filteredRows.find(r => r.id === id)
    if (b && isPaidBooking(b)) return // bỏ qua — booking đã thanh toán xong
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }
  const toggleAllOnPage = () => {
    // Chỉ áp lên các booking CHƯA PAID (bỏ qua đã thanh toán).
    const selectable = filteredRows.filter(r => !isPaidBooking(r))
    setSelectedIds(prev => {
      const allSelected = selectable.length > 0 && selectable.every(r => prev.has(r.id))
      const next = new Set(prev)
      if (allSelected) selectable.forEach(r => next.delete(r.id))
      else             selectable.forEach(r => next.add(r.id))
      return next
    })
  }
  const clearSelection = () => setSelectedIds(new Set())

  // 2026-10-10: Lọc bỏ booking PAID khỏi danh sách batch (phòng khi state cũ còn id của booking vừa đổi).
  const selectedBookings = useMemo(
    () => filteredRows.filter(r => selectedIds.has(r.id) && r.paymentStatus !== 'PAID'),
    [filteredRows, selectedIds]
  )

  const onBatchPay = () => {
    if (selectedBookings.length < 2) return toast.error('Chọn ít nhất 2 booking để thu batch.')
    setBatchPay(selectedBookings)
  }

  const onSavedRefresh = () => { load(); loadTotals() }

  // ── 2026-09-20: Xuất báo cáo PDF theo filter ──────────────
  // ── 2026-09-25: sau khi xuất xong, nếu có hóa đơn nháp → hỏi tải luôn ──
  // ── 2026-09-25 (guard) ────────────────────────────────────
  // Chỉ mời tải hóa đơn nháp khi:
  //   G1: date range của báo cáo NẰM TRONG NGÀY HÔM NAY (fromMs & toMs đều
  //       là hôm nay). Nếu chọn khoảng khác → không mời.
  //   G2: MỌI VÉ trong các booking đã có hóa đơn nháp bao phủ. Nếu còn vé
  //       chưa có → warning và không tải.
  const [confirmDraftDl,   setConfirmDraftDl]   = useState(null) // { bookings, count }
  const [warnMissingDraft, setWarnMissingDraft] = useState(null) // { missing: [...] }

  const handleExportPdf = async () => {
    setExporting(true)
    const tid = toast.loading('Đang tải dữ liệu và tạo PDF…')
    try {
      const mod = await import('../../lib/bookingsPdfExport')
      const { bookings, fromMs, toMs } = await mod.exportBookingsReport(filterParams, {
        onProgress: (loaded, total) => {
          toast.loading(`Đã tải ${loaded}/${total || '?'} booking…`, { id: tid })
        },
      })
      toast.success('Đã tạo PDF', { id: tid })

      // ── Guard 1: date range phải nằm trong hôm nay ──
      if (!mod.isRangeWithinToday(fromMs, toMs)) return

      // Không có hóa đơn nháp nào → không cần hỏi
      const count = mod.countDraftInvoices(bookings)
      if (count === 0) return

      // ── Guard 2: mọi vé phải có hóa đơn nháp bao phủ ──
      const missing = mod.findTicketsMissingDraftInvoice(bookings)
      if (missing.length > 0) {
        setWarnMissingDraft({ missing })
        return
      }

      setConfirmDraftDl({ bookings, count })
    } catch (e) {
      console.error('[PDF export]', e)
      toast.error(e?.message || 'Xuất PDF thất bại', { id: tid })
    } finally {
      setExporting(false)
    }
  }

  const handleDownloadDraftInvoices = async () => {
    if (!confirmDraftDl) return
    const { bookings, count } = confirmDraftDl
    setConfirmDraftDl(null)
    const tid = toast.loading(`Chuẩn bị tải ${count} hóa đơn nháp…`)
    try {
      const mod = await import('../../lib/bookingsPdfExport')
      const { total, done, errors } = await mod.downloadDraftInvoices(bookings, {
        onProgress: (d, t) => toast.loading(`Đã tải ${d}/${t} hóa đơn nháp…`, { id: tid }),
      })
      if (done === total) {
        toast.success(`Đã tải ${done} hóa đơn nháp`, { id: tid })
      } else {
        toast.error(`Tải ${done}/${total} hóa đơn nháp — ${errors?.length || 0} file lỗi`, { id: tid })
      }
    } catch (e) {
      console.error('[Draft invoice download]', e)
      toast.error(e?.message || 'Tải hóa đơn nháp thất bại', { id: tid })
    }
  }

  // ── 2026-09-19: click Mã booking → Xuất trình modal. Upload nằm ở cột thao tác. ──
  const openBookingFace = (b) => setPresentation(b)
  const openTicketFace  = (b, ticketId) => setFace({ booking: b, ticketId })
  const openUpload      = (b) => setUploadFor(b)

  /**
   * 2026-10-12: Thu tiền giờ ở cấp HÓA ĐƠN.
   *   - Booking không có invoice → warning (user phải upload hóa đơn trước)
   *   - Booking có 1 invoice → mở PaymentModal thẳng
   *   - Booking có >1 invoice → mở picker để user chọn hóa đơn nào
   */
  const openPay = (b) => {
    // 2026-10-13: Booking tổng = 0 → đã PAID auto, không cần thu/tạo invoice.
    const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
      sumAmounts(t.basePrice, t.collectionFee,
        sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
    if (bookingTotal <= 0.5) {
      toast.success('Booking miễn phí (tổng = 0) — đã tự đánh dấu Đã thanh toán.')
      return
    }
    const invs = b.invoices || []
    if (invs.length === 0) {
      toast.error('Booking này chưa có hóa đơn (nháp/đã phát hành). Vui lòng tạo hóa đơn trước khi thu tiền.', { duration: 4500 })
      return
    }
    const unpaid = invs.filter(i => i.paymentStatus !== 'PAID')
    if (unpaid.length === 0) {
      toast.success('Tất cả hóa đơn của booking này đã thu đủ.')
      return
    }
    if (invs.length === 1) {
      setPayFor({ booking: b, invoice: invs[0] })
    } else {
      setInvoicePicker(b)
    }
  }

  return (
    // 2026-10-10: Layout flex column — toolbar + totals shrink-0, bảng flex-1 overflow-auto.
    // VmbPage container đã `overflow-hidden`, tab này tự quản lý scroll để các ô
    // search/filter/nút chức năng + card tổng tiền NẰM YÊN, chỉ các dòng cuộn.
    <div className="w-full h-full flex flex-col">
      <div className="shrink-0 flex flex-col lg:flex-row gap-2 mb-3">
        <input
          defaultValue={q}
          onChange={e => onSearch(e.target.value)}
          placeholder="Tìm theo mã booking, số vé, tên khách, hành trình, số hóa đơn…"
          className="flex-1 min-w-0 px-3.5 py-2 rounded-lg border border-gray-300 bg-white text-sm
            focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none" />

        {/* 2026-10-09: Filter theo công ty — mặc định "Tất cả" (null) */}
        <div className="w-full lg:w-64 shrink-0">
          <CompanySearchSelect
            value={companyId}
            options={flatCompanies}
            onChange={(id) => setCompanyId(id)}
            placeholder="— Tất cả công ty —"
            noneLabel="— Tất cả công ty —"
          />
        </div>

        <div className="flex gap-2 items-center shrink-0">
          <div className="w-72">
            <DateRangePicker
              value={{ from: fromSale, to: toSale }}
              onChange={({ from, to }) => {
                setPage(0)
                setFromSale(from)
                setToSale(to)
              }}
              placeholder="Chọn khoảng ngày bán"
            />
          </div>
        </div>

        {/* 2026-10-10: Filter trạng thái thanh toán */}
        <div className="flex gap-1 shrink-0 p-0.5 rounded-lg bg-gray-100">
          {[
            { k: '',       lbl: 'Tất cả' },
            { k: 'UNPAID', lbl: 'Chưa thanh toán' },
            { k: 'PAID',   lbl: 'Đã thanh toán' },
          ].map(t => (
            <button key={t.k} type="button"
              onClick={() => { setPage(0); setPaymentStatus(t.k) }}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap ${
                paymentStatus === t.k ? 'bg-white shadow text-blue-700' : 'text-gray-600 hover:text-gray-900'
              }`}>{t.lbl}</button>
          ))}
        </div>

        <button type="button" onClick={handleExportPdf} disabled={exporting}
          title="Xuất báo cáo PDF (landscape) — theo filter hiện tại; nếu chưa filter thì lấy toàn bộ"
          className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white
            text-sm font-semibold shadow-md shadow-emerald-500/20 shrink-0 disabled:opacity-50">
          {exporting ? '⏳ Đang xuất…' : '📄 Xuất PDF'}
        </button>

        <button type="button" onClick={() => setForm({ mode: 'create' })}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white
            text-sm font-semibold shadow-md shadow-blue-500/20 hover:from-blue-700 hover:to-indigo-700 shrink-0">
          + Thêm booking
        </button>
      </div>

      {selectedIds.size > 0 && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40
                        p-3 rounded-xl bg-amber-50 border border-amber-300 shadow-lg
                        flex items-center gap-3 flex-wrap min-w-[320px]">
          <span className="text-sm font-semibold text-amber-900">
            Đã chọn {selectedIds.size} booking
          </span>
          <div className="flex-1" />
          <button onClick={onBatchPay}
            className="px-3 py-1.5 rounded-md bg-blue-600 text-white text-xs font-bold hover:bg-blue-700">
            💰 Thu tiền hàng loạt
          </button>
          <button onClick={clearSelection}
            className="px-2 py-1.5 rounded-md text-xs text-gray-600 hover:bg-white/60">
            Bỏ chọn
          </button>
        </div>
      )}

      <div className="shrink-0">
        <BookingTotalsCard totals={displayTotals} loading={totalsLoading && companyId == null} />
      </div>

      {/* Desktop table — chiếm phần còn lại, cuộn trong khung bảng */}
      <div className="hidden lg:flex flex-1 min-h-0 bg-white rounded-2xl shadow border border-gray-100 overflow-hidden flex-col">
        <div className="flex-1 overflow-auto">
          <table className="w-full text-xs border-collapse table-fixed">
            <colgroup>
              <col style={{ width: 32 }} />
              <col style={{ width: 130 }} />  {/* Loại/Hãng */}
              <col style={{ width: 130 }} />  {/* Công ty — tăng từ 80 → 130 */}
              <col style={{ width: 210 }} />  {/* Khách hàng (name + số vé) */}
              <col style={{ width: 100 }} />  {/* Booking */}
              <col style={{ width: 130 }} />  {/* Hành trình */}
              <col style={{ width: 110 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 90 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 120 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
            </colgroup>
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px] sticky top-0 z-10">
              <tr>
                <Th center>
                  {(() => {
                    const selectable = filteredRows.filter(r => !isPaidBooking(r))
                    const allSel = selectable.length > 0 && selectable.every(r => selectedIds.has(r.id))
                    return <input type="checkbox"
                      checked={allSel}
                      onChange={toggleAllOnPage}
                      disabled={selectable.length === 0}
                      className="rounded disabled:opacity-30" />
                  })()}
                </Th>
                <Th>Loại / hãng</Th>
                <Th>Công ty</Th>
                <Th>Khách hàng</Th>
                <Th>Booking</Th>
                <Th>Hành trình / giờ đi</Th>
                <Th>Giá gốc</Th>
                <Th>Giá trên vé / phí</Th>
                <Th>Thành tiền</Th>
                <Th>Phí xuất vé</Th>
                <Th>Giá bán</Th>
                <Th>Tổng booking</Th>
                <Th>Quy đổi VND</Th>
                <Th center>Thanh toán</Th>
                <ThR>Thao tác</ThR>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={15} className="text-center py-10 text-gray-400">Đang tải…</td></tr>
              ) : filteredRows.length === 0 ? (
                <tr><td colSpan={15} className="text-center py-14 text-gray-400">
                  {q || fromSale || toSale || companyId != null ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào. Bấm "Thêm booking" để tạo.'}
                </td></tr>
              ) : (
                filteredRows.map((b, bIdx) => renderBookingRows(b, bIdx, {
                  page, nowTick,
                  isSelected: selectedIds.has(b.id),
                  onToggleSelect: toggleSelect,
                  onOpenBookingFace: openBookingFace,
                  onOpenTicketFace: openTicketFace,
                  onPresent: setPresentation,
                  onUpload: openUpload,
                  onInvoice: (bookingId) => setInvMgr(bookingId),
                  onNote: setNoteView,
                  onPay: openPay,
                  onEdit: () => setForm({ mode: 'edit', bookingId: b.id }),
                  onDelete: () => setConfirmDel(b),
                }))
              )}
            </tbody>
          </table>
        </div>
        <Pagination page={page} totalPages={totalPages} total={total} onPage={setPage} />
      </div>

      {/* Mobile cards — flex-1 overflow-auto */}
      <div className="lg:hidden flex-1 min-h-0 overflow-auto space-y-2">
        {loading ? (
          <div className="text-center py-10 text-gray-400 text-sm">Đang tải…</div>
        ) : filteredRows.length === 0 ? (
          <div className="text-center py-14 text-gray-400 text-sm">
            {q || fromSale || toSale || companyId != null ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào.'}
          </div>
        ) : (
          filteredRows.map(b => (
            <MobileBookingCard key={b.id} booking={b} nowTick={nowTick}
              isSelected={selectedIds.has(b.id)}
              onToggleSelect={toggleSelect}
              onOpenBookingFace={openBookingFace}
              onOpenTicketFace={openTicketFace}
              onPresent={setPresentation}
              onUpload={openUpload}
              onInvoice={(id) => setInvMgr(id)}
              onNote={setNoteView}
              onPay={openPay}
              onEdit={() => setForm({ mode: 'edit', bookingId: b.id })}
              onDelete={() => setConfirmDel(b)} />
          ))
        )}
        <Pagination page={page} totalPages={totalPages} total={total} onPage={setPage} />
      </div>

      {/* Modals */}
      {form && (
        <BookingFormModal
          mode={form.mode} bookingId={form.bookingId}
          onClose={() => setForm(null)}
          onSaved={() => { setForm(null); onSavedRefresh() }}
        />
      )}
      {face && (
        <TicketFaceModal
          booking={{
            ...face.booking,
            _onPickTicket: (tid) => setFace({ booking: face.booking, ticketId: tid })
          }}
          ticketId={face.ticketId}
          onClose={() => setFace(null)}
          onDirty={onSavedRefresh}
        />
      )}
      {invMgr && (
        <InvoiceManagerModal bookingId={invMgr} onClose={() => setInvMgr(null)} onDirty={load} />
      )}
      {presentation && (
        <PresentationModal open={true} booking={presentation} onClose={() => setPresentation(null)} />
      )}
      {uploadFor && (
        <UploadOptionsModal
          open={true}
          booking={uploadFor}
          onClose={() => setUploadFor(null)}
          onChanged={async () => {
            // Sau upload, reload booking để lấy state mới nhất (dùng cho grouping/hiện file
            // trong modal con nếu vẫn mở).
            try {
              const res = await import('../../services/vmbApi').then(m => m.getBooking(uploadFor.id))
              const b = res.data?.data
              if (b) setUploadFor(b)
              onSavedRefresh()
            } catch { /* silent */ }
          }}
        />
      )}
      {payFor && (
        <PaymentModal booking={payFor.booking} invoice={payFor.invoice}
          onClose={() => setPayFor(null)}
          onSaved={() => { setPayFor(null); onSavedRefresh() }} />
      )}
      {invoicePicker && (
        <InvoicePickerModal booking={invoicePicker}
          onClose={() => setInvoicePicker(null)}
          onPick={(inv) => {
            setPayFor({ booking: invoicePicker, invoice: inv })
            setInvoicePicker(null)
          }} />
      )}
      {batchPay && (
        <BatchPaymentModal bookings={batchPay}
          onClose={() => setBatchPay(null)}
          onSaved={() => { setBatchPay(null); clearSelection(); onSavedRefresh() }} />
      )}
      {noteView && (
        <TicketNoteModal passengerName={noteView.passengerName} note={noteView.note}
          onClose={() => setNoteView(null)} />
      )}
      {warnMissingDraft && (
        <Modal
          open
          onClose={() => setWarnMissingDraft(null)}
          title="⚠️ Thiếu hóa đơn nháp"
          size="md"
          footer={
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setWarnMissingDraft(null)}
                className="px-4 py-2 text-sm font-semibold rounded-lg
                           bg-amber-600 text-white hover:bg-amber-700">
                Đã hiểu
              </button>
            </div>
          }
        >
          <div className="text-sm text-gray-700 space-y-2">
            <p>
              Không tải hóa đơn nháp vì có <b>{warnMissingDraft.missing.length} vé</b> chưa
              có hóa đơn nháp bao phủ. Vui lòng bổ sung trước khi tải:
            </p>
            <ul className="list-disc pl-5 space-y-1 max-h-72 overflow-y-auto">
              {warnMissingDraft.missing.slice(0, 30).map((m) => (
                <li key={`${m.bookingId}-${m.ticketId}`}>
                  <span className="font-mono text-gray-500">{m.bookingCode}</span>
                  {' — '}
                  <b>{m.passengerName}</b>
                </li>
              ))}
            </ul>
            {warnMissingDraft.missing.length > 30 && (
              <p className="text-xs text-gray-500 italic">
                … và {warnMissingDraft.missing.length - 30} vé khác
              </p>
            )}
          </div>
        </Modal>
      )}
      {confirmDraftDl && (
        <ConfirmModal
          open
          title="Tải hóa đơn nháp?"
          message={`Có ${confirmDraftDl.count} hóa đơn nháp trong các booking vừa xuất báo cáo. Tải tất cả?`}
          confirmLabel="Tải tất cả"
          cancelLabel="Bỏ qua"
          onConfirm={handleDownloadDraftInvoices}
          onCancel={() => setConfirmDraftDl(null)}
        />
      )}
      {confirmDel && (
        <ConfirmModal
          open title="Xóa booking"
          message={`Xóa booking "${confirmDel.bookingCode || '(chưa có mã)'}" cùng ${confirmDel.tickets?.length || 0} vé, tất cả mặt vé và hóa đơn đính kèm?`}
          confirmLabel="Xóa" danger
          onConfirm={async () => {
            try {
              await deleteBooking(confirmDel.id)
              toast.success('Đã xóa'); setConfirmDel(null); onSavedRefresh()
            } catch (e) {
              toast.error(e?.response?.data?.message || 'Xóa thất bại')
            }
          }}
          onCancel={() => setConfirmDel(null)}
        />
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
//  HEADER CELLS
// ═══════════════════════════════════════════════════════════════

function Th({ children, center }) {
  return (
    <th className={`px-2 py-2 font-semibold align-middle ${center ? 'text-center' : 'text-left'}`}>
      {children}
    </th>
  )
}
function ThR({ children }) {
  return (
    <th className="px-2 py-2 font-semibold text-right align-middle">
      {children}
    </th>
  )
}

// ═══════════════════════════════════════════════════════════════
//  GROUP TICKETS THEO CÔNG TY
// ═══════════════════════════════════════════════════════════════

/**
 * Sắp xếp lại tickets: gom các vé cùng công ty lại với nhau. Thứ tự công ty
 * giữ theo thứ tự xuất hiện đầu tiên trong booking gốc (stable — không sort
 * alphabet, để user vẫn thấy công ty họ nhập đầu tiên ở trên đầu).
 *
 * Ví dụ input:  [Cty A khách1, Cty B khách2, Cty A khách3, Cty A khách4]
 * Output tickets: [khách1, khách3, khách4, khách2]
 * Output groups: [{key:A, size:3, tickets:[k1,k3,k4]}, {key:B, size:1, tickets:[k2]}]
 *
 * Key dùng cho công ty = companyId (null nếu khách lẻ) → 2 vé cùng "khách lẻ"
 * (null companyId) cũng merge.
 */
function groupTicketsByCompany(tickets) {
  const buckets = new Map()   // key → { key, origIdx (first appearance), tickets: [{t, origIdx}] }
  const list = tickets || []
  for (let i = 0; i < list.length; i++) {
    const t = list[i]
    const key = t.companyId == null ? 'none' : `c${t.companyId}`
    if (!buckets.has(key)) buckets.set(key, { key, tickets: [] })
    buckets.get(key).tickets.push({ t, origIdx: i })
  }

  // ── 2026-10-10: sort trong mỗi group theo ticketNumber ASC. ──
  // Vé không có số vé → đẩy xuống cuối, giữ thứ tự add (origIdx).
  // Hiển thị theo yêu cầu user:
  //   BUI HONG PHAT (…740) đứng trước KUWABATA (…741), …
  //   nếu không có số thì giữ thứ tự khi tạo.
  for (const b of buckets.values()) {
    b.tickets.sort((a, bb) => {
      const an = (a.t.ticketNumber || '').trim()
      const bn = (bb.t.ticketNumber || '').trim()
      const aEmpty = an === ''
      const bEmpty = bn === ''
      if (aEmpty && bEmpty) return a.origIdx - bb.origIdx
      if (aEmpty) return 1
      if (bEmpty) return -1
      // Số vé thường toàn số/chữ — so sánh dạng chuỗi là đủ (cùng độ dài).
      // Nếu có khác độ dài, so numeric cho ổn định.
      if (an.length === bn.length) return an < bn ? -1 : an > bn ? 1 : 0
      const na = Number(an), nb = Number(bn)
      if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb
      return an < bn ? -1 : an > bn ? 1 : 0
    })
  }

  const groups = []
  const sortedTickets = []
  for (const b of buckets.values()) {
    groups.push({
      key: b.key,
      size: b.tickets.length,
      firstIdxInSorted: sortedTickets.length,
      ticketIds: b.tickets.map(x => x.t.id),
    })
    for (const x of b.tickets) sortedTickets.push(x.t)
  }
  return { sortedTickets, groups }
}

/**
 * ── 2026-10-10 ──────────────────────────────────────────────
 * Hiển thị số hóa đơn ISSUED/ADJUSTED áp cho ticketIds trong group hiện tại.
 *
 * Logic:
 *   - Lấy các invoice ISSUED/ADJUSTED của booking.
 *   - Mỗi invoice.ticketIds (nếu empty = chung cả booking → coi như áp cho MỌI vé).
 *   - Lọc những invoice có giao với ticketIds của group.
 *   - Nếu tất cả vé trong group dùng CHUNG 1 hóa đơn → hiển thị 1 số.
 *   - Nếu nhiều invoice khác nhau áp lên các cặp vé → hiển thị tất cả, phân cách dấu phẩy.
 */
function InvoiceNumbersForGroup({ booking, ticketIds }) {
  const invs = (booking.invoices || []).filter(i => i.status === 'ISSUED' || i.status === 'ADJUSTED')
  if (invs.length === 0) return null
  const idSet = new Set(ticketIds || [])
  const bookingTicketIds = new Set((booking.tickets || []).map(t => t.id))
  const numbersSet = new Set()
  for (const inv of invs) {
    if (!inv.invoiceNumbers) continue
    const invIds = (inv.ticketIds && inv.ticketIds.length > 0)
      ? inv.ticketIds
      : [...bookingTicketIds] // empty = chung cả booking
    const overlap = invIds.some(id => idSet.has(id))
    if (!overlap) continue
    // Tách & trim
    inv.invoiceNumbers.split(',').forEach(n => {
      const t = n.trim()
      if (t) numbersSet.add(t)
    })
  }
  if (numbersSet.size === 0) return null
  const sorted = [...numbersSet].sort((a, b) => {
    const na = Number(a), nb = Number(b)
    if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb
    return a.localeCompare(b)
  })
  return (
    <div className="mt-1 text-[10px] text-gray-600 font-mono tabular-nums leading-tight break-words"
      title="Số hóa đơn đã phát hành">
      🧾 {sorted.join(', ')}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — DESKTOP TABLE
// ═══════════════════════════════════════════════════════════════

function renderBookingRows(b, bIdx, {
  page, nowTick, isSelected, onToggleSelect,
  onOpenBookingFace, onOpenTicketFace, onPresent, onUpload, onInvoice, onNote, onPay, onEdit, onDelete,
}) {
  // 2026-10-12: Tổng QUY về booking.currency — fees khác currency được convert
  // qua exchangeRate (xem sumTicketFees).
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee,
      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
  const totalVnd = toVnd(bookingTotal, b.currency, b.exchangeRate)
  const N = b.tickets?.length || 1
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
      primary?.band === 'warn' ? 'bg-amber-500 text-white'
    : primary?.band === 'future' ? 'bg-blue-600 text-white'
    : ''

  // Sắp xếp tickets theo company (giữ order xuất hiện đầu tiên)
  const { sortedTickets, groups } = groupTicketsByCompany(b.tickets || [])
  // Map: sortedIdx → group info (chỉ render company cell ở dòng đầu của group)
  const groupStartAt = new Map()
  for (const g of groups) groupStartAt.set(g.firstIdxInSorted, g)

  return sortedTickets.map((t, tIdx) => {
    // ── 2026-10-09: BỎ tint theo currency ──
    //   Trước đây USD tint sky-50, nhưng mỗi dòng vẫn in rõ đơn vị
    //   (VND/USD) ở cột giá nên tint thừa + nhiễu khi nhiều booking USD
    //   liền nhau. Giờ tất cả cùng nền trắng; chỉ selected mới đổi màu.
    const rowBg = isSelected ? 'bg-amber-50/60' : 'bg-white'
    const firstRow = tIdx === 0
    const lastRow  = tIdx === N - 1
    const cardBorder = `${firstRow ? 'border-t-2 border-t-gray-100' : ''} ${lastRow ? 'border-b-4 border-b-gray-100' : ''}`
    const withCollection = sumAmounts(t.basePrice, t.collectionFee)
    // 2026-10-12: fees quy về booking.currency để cộng cùng basePrice/collection.
    const feesTotal      = sumTicketFees(t.fees, b.currency, b.exchangeRate)
    const subTotal       = sumAmounts(withCollection, feesTotal)
    const sellPrice      = sumAmounts(subTotal, t.issuanceFee)
    const hasFace = faceStatus(b, t.id)
    const groupInfo = groupStartAt.get(tIdx)

    return (
      <tr key={t.id}
          className={`${rowBg} ${cardBorder} hover:bg-blue-50/40 transition-colors align-middle`}>
        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            {/* 2026-10-10: Booking đã PAID không được chọn để thu batch. */}
            <input type="checkbox"
              checked={isSelected}
              disabled={b.paymentStatus === 'PAID'}
              onChange={() => onToggleSelect(b.id)}
              title={b.paymentStatus === 'PAID' ? 'Booking đã thanh toán xong — không cần thu' : undefined}
              className="rounded cursor-pointer disabled:cursor-not-allowed disabled:opacity-30" />
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle relative" rowSpan={N}>
            {primary && badgeCls && (
              <span className={`inline-block mb-1 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold ${badgeCls}`}
                title={`Còn ${primary.text} đến chuyến bay`}>
                ⏱ {primary.text}
              </span>
            )}
            <div className="text-xs font-semibold text-gray-900 leading-tight">
              {kindLabel(b.kind)} · <span className="text-gray-600">{b.airlineCode || '—'}</span>
            </div>
            <div className="text-[10px] text-gray-500 tabular-nums mt-0.5">
              {formatDateTimeShort(b.saleDate)}
            </div>
          </td>
        )}

        {/* Công ty — chỉ render ở dòng đầu group, rowspan = group size */}
        {groupInfo && (
          <td className="px-2 py-2 align-middle border-l border-gray-100"
              rowSpan={groupInfo.size}>
            <CompanyLabel short={t.companyShortName} full={t.companyName} />
            <InvoiceNumbersForGroup booking={b} ticketIds={groupInfo.ticketIds || sortedTickets.slice(tIdx, tIdx + groupInfo.size).map(x => x.id)} />
          </td>
        )}

        {/* Khách hàng — 2 dòng: tên + số vé */}
        <td className="px-2 py-2 align-middle">
          <div className="font-medium text-gray-900 truncate leading-tight">
            {t.passengerName || '—'}
          </div>
          {/* ── 2026-10-10: click-to-copy — "{route} - {ticketNumber}{kindSuffix}" ── */}
          <button type="button"
            onClick={() => {
              if (!t.ticketNumber) return
              const text = buildIdCopyString(b.segments, t.ticketNumber, b.kind)
              navigator.clipboard.writeText(text)
                .then(() => toast.success(`Đã copy: ${text}`))
                .catch(() => toast.error('Không copy được'))
            }}
            disabled={!t.ticketNumber}
            title={t.ticketNumber
              ? `Click để copy: ${buildIdCopyString(b.segments, t.ticketNumber, b.kind)}`
              : 'Vé chưa có số'}
            className="font-mono text-[10px] text-gray-500 truncate leading-tight mt-0.5 block text-left w-full hover:text-blue-700 hover:underline cursor-copy disabled:cursor-default disabled:hover:no-underline">
            {t.ticketNumber || ''}
            {hasFace && t.ticketNumber && <span className="ml-1 text-emerald-600">📎</span>}
          </button>
        </td>

        {/* Booking — 2026-10-10 click copy "{route} - {bookingCode}{kindSuffix}" */}
        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            <button type="button"
              onClick={() => {
                if (!b.bookingCode) return
                const text = buildIdCopyString(b.segments, b.bookingCode, b.kind)
                navigator.clipboard.writeText(text)
                  .then(() => toast.success(`Đã copy: ${text}`))
                  .catch(() => toast.error('Không copy được'))
              }}
              disabled={!b.bookingCode}
              title={b.bookingCode
                ? `Click để copy: ${buildIdCopyString(b.segments, b.bookingCode, b.kind)}`
                : 'Chưa có mã'}
              className="block w-full text-left font-mono text-[11px] font-bold text-gray-900 hover:text-blue-700 hover:underline truncate cursor-copy disabled:cursor-default">
              {b.bookingCode || '—'}
              {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
            </button>
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            {(b.segments || []).length === 0 ? <span className="text-gray-400">—</span> : (() => {
              const concat = routeConcat(b.segments)
              const copyRoute = () => {
                if (!concat) return
                navigator.clipboard.writeText(concat)
                  .then(() => toast.success(`Đã copy: ${concat}`))
                  .catch(() => toast.error('Không copy được'))
              }
              return (
                <button type="button" onClick={copyRoute}
                  title={`Click để copy: ${concat}`}
                  className="block w-full text-left cursor-copy hover:bg-blue-50 rounded px-1 -mx-1">
                  {(b.segments || []).map((s, i) => (
                    <div key={i} className={`${i > 0 ? 'mt-1.5 pt-1.5 border-t border-dashed border-gray-200' : ''}`}>
                      <div className="text-xs font-bold text-gray-900 leading-tight">
                        {s.fromCode} <span className="text-gray-400">→</span> {s.toCode}
                      </div>
                      <div className="text-[11px] tabular-nums text-gray-500 leading-tight">
                        {formatDepart(s.departLocalMs, s.fromCode) || '—'}
                      </div>
                    </div>
                  ))}
                </button>
              )
            })()}
          </td>
        )}

        <TdMoneyPair
          value1={t.basePrice}
          value2={t.collectionFee}
          currency={b.currency}
          exchangeRate={b.exchangeRate}
          bold1
          // 2026-10-10: Vé đầu tiên trong booking → click phí thu hộ sẽ copy
          // TỔNG phí thu hộ của mọi vé trong booking (user tiện gộp vào 1 bút toán).
          value2OverrideSum={
            // Vé đầu tiên hiển thị trong booking (sau sort theo số vé) → gộp tổng
            // phí thu hộ của mọi vé cùng booking vào ô này.
            tIdx === 0
              ? sumAmounts(...(b.tickets || []).map(x => x.collectionFee || 0))
              : null
          }
        />
        <TdInvoiceAndFees
          withCollection={withCollection} fees={t.fees}
          currency={b.currency} exchangeRate={b.exchangeRate}
          segments={b.segments}
          ticketNumber={t.ticketNumber}
          bookingCode={b.bookingCode}
        />
        <TdMoney value={subTotal} currency={b.currency} exchangeRate={b.exchangeRate} bold />
        <TdMoney value={t.issuanceFee} currency={b.currency} exchangeRate={b.exchangeRate} muted />
        <TdMoney value={sellPrice} currency={b.currency} exchangeRate={b.exchangeRate} bold />

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle border-l border-r border-gray-200"
              rowSpan={N}>
            <div className="font-mono tabular-nums text-sm font-bold text-blue-700">
              {formatMoney(bookingTotal, b.currency)}
            </div>
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle" rowSpan={N}>
            {b.currency === 'VND' ? (
              <span className="text-gray-400 text-[11px]">—</span>
            ) : (
              <>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900">
                  {formatMoney(totalVnd, 'VND')}
                </div>
                <div className="text-[10px] text-gray-500 tabular-nums">
                  1 USD = {b.exchangeRate ? formatMoney(b.exchangeRate, 'VND', { withUnit: false }) : '—'}
                </div>
              </>
            )}
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            <PaymentCell booking={b} bookingTotal={bookingTotal} onPay={onPay} />
          </td>
        )}

        {/* Thao tác — 2026-09-19: rút gọn còn 5 nút. Note ở mỗi ticket, các nút khác ở firstRow. */}
        {/* 2026-09-20: canh phải theo yêu cầu — icons dồn về bên phải */}
        <td className="px-2 py-2 align-middle">
          <div className="flex flex-wrap items-center justify-end gap-1">
            {t.note && (
              <button type="button"
                onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                title={'Ghi chú: ' + (t.note.length > 60 ? t.note.slice(0, 60) + '…' : t.note)}
                className="w-7 h-7 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-700 inline-flex items-center justify-center">
                📝
              </button>
            )}
            {firstRow && (
              <>
                <button type="button" onClick={() => onPresent(b)}
                  title="Xuất trình (Thông tin booking / Mặt vé / Hóa đơn)"
                  className="w-7 h-7 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-700 flex items-center justify-center">
                  {/* 👁 — xem/trình bày ra ngoài, phân biệt rõ với upload */}
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                </button>
                <button type="button" onClick={() => onUpload(b)}
                  title="Upload (Thông tin booking / Mặt vé / Hóa đơn)"
                  className="w-7 h-7 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  {/* ⬆ cloud-upload — khác hẳn con mắt ở trên */}
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17 8 12 3 7 8"/>
                    <line x1="12" y1="3" x2="12" y2="15"/>
                  </svg>
                </button>
                <button type="button" onClick={onEdit}
                  title="Sửa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-gray-200 flex items-center justify-center">✎</button>
                <button type="button" onClick={onDelete}
                  title="Xóa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-rose-100 hover:text-rose-700 flex items-center justify-center">🗑</button>
              </>
            )}
          </div>
        </td>
      </tr>
    )
  })
}

// ── Sub-components ─────────────────────────────────────

function CompanyLabel({ short, full }) {
  if (!full && !short) {
    return <span className="text-[10px] text-gray-400 italic">Khách lẻ</span>
  }
  const label = short || autoShort(full)
  return (
    <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800"
      title={full}>
      {label}
    </span>
  )
}

function autoShort(name) {
  if (!name) return '—'
  const parts = name.split(/\s+/).filter(x => x && !/^(và|-|của)$/i.test(x))
  if (parts.length === 1) return parts[0].slice(0, 6).toUpperCase()
  return parts.slice(0, 3).map(p => p[0]?.toUpperCase() || '').join('')
}

function PaymentCell({ booking, bookingTotal, onPay }) {
  const stRaw = booking.paymentStatus || 'UNPAID'
  const paid = parseAmount(booking.paidAmount) || 0
  const remain = Math.max(0, bookingTotal - paid)

  // 2026-10-13:
  //   - total ≈ 0 → PAID (booking miễn phí/không có giá).
  //   - đã thu đủ (remain ≤ 0) & total > 0 → PAID (safeguard nếu BE
  //     trả PARTIAL do stale cache / nhiều invoice).
  //   - còn lại → bám theo stRaw của BE.
  let st
  if (bookingTotal <= 0.5) st = 'PAID'
  else if (remain <= 0.5)  st = 'PAID'
  else                     st = stRaw

  const paidStr = formatMoney(paid, booking.currency, { withUnit: false })
  const badge =
      st === 'PAID'    ? { cls: 'bg-green-100 text-green-700', label: 'Đã thanh toán' }
    : st === 'PARTIAL' ? { cls: 'bg-amber-100 text-amber-700', label: `Đã thu: ${paidStr}` }
    :                    { cls: 'bg-rose-100 text-rose-700',   label: 'Chưa thanh toán' }

  return (
    <button type="button" onClick={() => onPay(booking)}
      className={`px-2 py-1 rounded-md ${badge.cls} hover:brightness-95 transition text-left w-full`}>
      <div className="text-[10px] font-bold">{badge.label}</div>
      {st === 'PARTIAL' && (
        <div className="text-[10px] font-mono tabular-nums mt-0.5 opacity-80">
          còn {formatMoney(remain, booking.currency, { withUnit: false })}
        </div>
      )}
    </button>
  )
}

/**
 * ── 2026-09-20: click-to-copy ─────────────────────────────────
 * Cell tiền là 1 button. Click → copy vào clipboard số nguyên (không format,
 * không unit). Nếu currency=USD → nhân với exchangeRate của booking để ra
 * VND rồi copy (đơn vị: đồng, làm tròn).
 *
 * Trường hợp cần chỉ copy raw (không đổi sang VND), truyền {@code rawCopy}.
 */
async function copyMoneyAsClipboard(numericValue, currency, exchangeRate, rawCopy) {
  if (!Number.isFinite(numericValue)) return
  let vnd = numericValue
  if (!rawCopy && currency === 'USD') {
    const rate = parseAmount(exchangeRate)
    if (Number.isFinite(rate) && rate > 0) {
      vnd = numericValue * rate
    }
  }
  const intVnd = Math.round(vnd)
  const text = String(intVnd)
  try {
    await navigator.clipboard.writeText(text)
    // Hiển thị theo format có dấu chấm cho user dễ đọc trong toast
    toast.success(`Đã copy: ${intVnd.toLocaleString('vi-VN')}`)
  } catch (e) {
    toast.error('Không copy được vào clipboard')
  }
}

function TdMoney({ value, currency, exchangeRate, bold, muted }) {
  const n = typeof value === 'number' ? value : parseAmount(value)
  const cls =
      !Number.isFinite(n) ? 'text-gray-300'
    : muted ? 'text-gray-500'
    : bold  ? 'text-gray-900 font-semibold'
    : 'text-gray-700'
  const isClickable = Number.isFinite(n) && n !== 0
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={isClickable ? () => copyMoneyAsClipboard(n, currency, exchangeRate) : undefined}
        disabled={!isClickable}
        title={isClickable ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`${cls} text-left ${isClickable ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n, currency, { withUnit: false })}
      </button>
    </td>
  )
}

function TdMoneyPair({ value1, value2, currency, exchangeRate, bold1, value2OverrideSum }) {
  const n1 = typeof value1 === 'number' ? value1 : parseAmount(value1)
  const n2 = typeof value2 === 'number' ? value2 : parseAmount(value2)
  const cls1 =
      !Number.isFinite(n1) ? 'text-gray-300'
    : bold1 ? 'text-gray-900 font-semibold'
    : 'text-gray-700'
  const clickable1 = Number.isFinite(n1) && n1 !== 0
  const clickable2 = Number.isFinite(n2) && n2 !== 0
  // 2026-10-10: Nếu có override (vé đầu tiên) → click vào collection fee copy tổng
  // của cả booking thay vì chỉ số của riêng vé.
  const hasSumOverride = value2OverrideSum != null && Number.isFinite(value2OverrideSum) && value2OverrideSum !== 0
  const copyValueForSecond = hasSumOverride ? value2OverrideSum : n2
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={clickable1 ? () => copyMoneyAsClipboard(n1, currency, exchangeRate) : undefined}
        disabled={!clickable1}
        title={clickable1 ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`${cls1} text-left block ${clickable1 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n1, currency, { withUnit: false })}
      </button>
      <button type="button"
        onClick={clickable2 ? () => copyMoneyAsClipboard(copyValueForSecond, currency, exchangeRate) : undefined}
        disabled={!clickable2}
        title={clickable2
          ? (hasSumOverride
              ? `Click để copy TỔNG phí thu hộ cả booking: ${formatMoney(value2OverrideSum, currency, { withUnit: false })}`
              : (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy'))
          : undefined}
        className={`text-[10px] text-left block ${hasSumOverride ? 'text-blue-600 font-semibold' : 'text-gray-400'} ${clickable2 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {Number.isFinite(n2) && n2 !== 0 ? formatMoney(n2, currency, { withUnit: false }) : '—'}
      </button>
    </td>
  )
}


/**
 * Cột "Giá trên vé / phí" — hiển thị withCollection ở trên, list phí phát sinh
 * bên dưới. Mỗi phí = label bên trái + số tiền bên phải (canh phải).
 * Click số tiền → copy (quy đổi VND nếu USD).
 *
 * ── 2026-09-20 rework ────────────────────────────────
 * Trước dùng TdMoneyPair value2={feesTotal} → chỉ hiển thị TỔNG phí ở dòng
 * phụ nhỏ xíu, user không biết vé đã có phí gì. Nay list chi tiết mỗi loại
 * phí trên 1 dòng, canh phải giá tiền để cột nhìn gọn.
 */
/**
 * "Phí trợ giúp đặc biệt" → "Phí Trợ Giúp Đặc Biệt".
 * Viết hoa chữ cái đầu MỖI từ. Unicode-aware (nhận đúng chữ tiếng Việt có
 * dấu như "đ", "ơ", "ư", các nguyên âm có dấu…).
 *
 * Không dùng String.prototype.toUpperCase() cho toàn bộ vì user chỉ muốn hoa
 * chữ đầu, giữ các chữ sau nguyên vẹn.
 */
function titleCaseVi(str) {
  if (!str) return ''
  return String(str)
    .split(/(\s+)/)                    // tách nhưng giữ khoảng trắng
    .map(part => {
      if (/^\s+$/.test(part)) return part
      // Lấy ký tự đầu (Unicode-aware qua Array.from để không tách bậy chữ có dấu)
      const chars = Array.from(part)
      if (chars.length === 0) return part
      chars[0] = chars[0].toLocaleUpperCase('vi-VN')
      return chars.join('')
    })
    .join('')
}

function TdInvoiceAndFees({ withCollection, fees, currency, exchangeRate, segments, ticketNumber, bookingCode }) {
  const n1 = typeof withCollection === 'number' ? withCollection : parseAmount(withCollection)
  const clickable1 = Number.isFinite(n1) && n1 !== 0
  const feesList = Array.isArray(fees) ? fees : []
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={clickable1 ? () => copyMoneyAsClipboard(n1, currency, exchangeRate) : undefined}
        disabled={!clickable1}
        title={clickable1 ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`text-gray-900 font-semibold text-left block ${clickable1 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n1, currency, { withUnit: false })}
      </button>
      {feesList.length === 0 ? (
        <div className="text-[10px] text-gray-400">—</div>
      ) : (
        <div className="mt-0.5 space-y-0.5">
          {feesList.map((f, i) => {
            const amt = parseAmount(f.amount)
            const canCopy = Number.isFinite(amt) && amt !== 0
            const label = f.feeTypeLabel || f.feeType
            const labelTitleCase = titleCaseVi(label)
            // 2026-10-12: fee có currency riêng — display + copy đúng theo nó.
            const feeCur = (f.currency || currency || 'VND').toUpperCase()
            const copyText = buildFeeCopyString(segments, ticketNumber, bookingCode, labelTitleCase)
            const copyLabel = () => {
              navigator.clipboard.writeText(copyText)
                .then(() => toast.success(`Đã copy: ${copyText}`))
                .catch(() => toast.error('Không copy được'))
            }
            return (
              <div key={i} className="flex items-center gap-2 text-[10px]">
                <button type="button"
                  onClick={copyLabel}
                  title={`Click để copy: "${copyText}"`}
                  className="text-gray-600 truncate text-left hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy">
                  {label}
                </button>
                <button type="button"
                  onClick={canCopy ? () => copyMoneyAsClipboard(amt, feeCur, exchangeRate) : undefined}
                  disabled={!canCopy}
                  title={canCopy
                    ? (feeCur === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy')
                    : undefined}
                  className={`font-mono tabular-nums text-left ${
                    feeCur !== currency ? 'text-amber-700 font-semibold' : 'text-gray-700'
                  } ${canCopy ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
                  {formatMoney(amt, feeCur, { withUnit: false })}
                  {feeCur !== currency && (
                    <span className="ml-0.5 text-[9px] opacity-70">{feeCur}</span>
                  )}
                </button>
              </div>
            )
          })}
        </div>
      )}
    </td>
  )
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — MOBILE CARD
// ═══════════════════════════════════════════════════════════════

function MobileBookingCard({ booking: b, nowTick, isSelected, onToggleSelect,
                             onOpenBookingFace, onOpenTicketFace,
                             onPresent, onUpload,
                             onInvoice, onNote, onPay, onEdit, onDelete }) {
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee,
      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
      primary?.band === 'warn' ? 'bg-amber-500 text-white'
    : primary?.band === 'future' ? 'bg-blue-600 text-white'
    : ''
  // 2026-10-13: Same safeguard như desktop PaymentCell.
  const paidNum = parseAmount(b.paidAmount) || 0
  const remainBk = Math.max(0, bookingTotal - paidNum)
  const stRaw = b.paymentStatus || 'UNPAID'
  const st = (bookingTotal <= 0.5 || remainBk <= 0.5) ? 'PAID' : stRaw
  const stCls =
      st === 'PAID'    ? 'bg-green-100 text-green-700'
    : st === 'PARTIAL' ? 'bg-amber-100 text-amber-700'
    :                    'bg-rose-100 text-rose-700'
  const stLabel =
      st === 'PAID'    ? 'Đã thanh toán'
    : st === 'PARTIAL' ? `Đã thu: ${formatMoney(paidNum, b.currency, { withUnit: false })}`
    :                    'Chưa thanh toán'

  // Mobile cũng group theo company cho nhất quán
  const { sortedTickets } = groupTicketsByCompany(b.tickets || [])

  return (
    <div className={`rounded-xl border shadow-sm p-3 relative ${
      isSelected
        ? 'bg-amber-50 border-amber-300'
        : 'bg-white border-gray-200'
    }`}>
      <div className="flex items-start gap-2 mb-2">
        <input type="checkbox" checked={isSelected}
          onChange={() => onToggleSelect(b.id)}
          className="mt-1.5 rounded cursor-pointer" />
        <div className="flex-1">
          {primary && badgeCls && (
            <span className={`inline-block px-2 py-0.5 mb-1 rounded-md font-mono text-[10px] font-bold ${badgeCls}`}>
              ⏱ {primary.text}
            </span>
          )}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-bold">
              {kindLabel(b.kind)} · {b.airlineCode || '?'}
            </span>
            <button type="button"
              onClick={() => {
                if (!b.bookingCode) return
                const text = buildIdCopyString(b.segments, b.bookingCode, b.kind)
                navigator.clipboard.writeText(text)
                  .then(() => toast.success(`Đã copy: ${text}`))
                  .catch(() => toast.error('Không copy được'))
              }}
              disabled={!b.bookingCode}
              title={b.bookingCode
                ? `Click để copy: ${buildIdCopyString(b.segments, b.bookingCode, b.kind)}`
                : 'Chưa có mã'}
              className="font-mono text-xs font-bold text-gray-900 hover:text-blue-700 hover:underline cursor-copy disabled:cursor-default">
              {b.bookingCode || '—'}
              {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
            </button>
          </div>
        </div>
        <button onClick={onEdit} className="text-gray-500 hover:text-gray-800 w-7 h-7 rounded-md hover:bg-gray-100">✎</button>
        <button onClick={onDelete} className="text-gray-500 hover:text-rose-600 w-7 h-7 rounded-md hover:bg-rose-50">🗑</button>
      </div>

      <div className="text-[10px] text-gray-400 tabular-nums mb-2">
        Bán: {formatDateTimeShort(b.saleDate)}
      </div>

      <div className="text-[11px] text-gray-700 mb-2 space-y-0.5">
        {(b.segments || []).map((s, i) => (
          <div key={i} className="px-1.5 py-0.5">
            <span className="font-bold">{s.fromCode} → {s.toCode}</span>
            <span className="text-gray-500 mx-1">·</span>
            <span className="tabular-nums">{formatDepart(s.departLocalMs, s.fromCode)}</span>
          </div>
        ))}
      </div>

      <div className="divide-y divide-gray-100 -mx-3">
        {sortedTickets.map(t => {
          const hasFace = faceStatus(b, t.id)
          return (
            <div key={t.id} className="px-3 py-2">
              <div className="flex items-center gap-2 mb-1">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <CompanyLabel short={t.companyShortName} full={t.companyName} />
                    <span className="text-sm font-semibold text-gray-900 truncate">{t.passengerName || '—'}</span>
                  </div>
                  <InvoiceNumbersForGroup booking={b} ticketIds={[t.id]} />
                  <div className="font-mono text-[10px] text-gray-500 truncate"
                    title={hasFace ? 'Vé này đã có mặt vé' : 'Vé chưa có mặt vé'}>
                    {t.ticketNumber || 'chưa có số vé'}
                    {hasFace && <span className="ml-1 text-emerald-600">📎</span>}
                  </div>
                </div>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900">
                  {formatMoney(
                    sumAmounts(t.basePrice, t.collectionFee,
                      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee),
                    b.currency
                  )}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1">
                {t.note && (
                  <button type="button"
                    onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                    className="h-7 w-7 rounded-md text-[11px] font-semibold bg-amber-100 text-amber-700 flex items-center justify-center">
                    📝
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-2 pt-2 border-t border-gray-100 flex items-center justify-between gap-2 flex-wrap">
        <button type="button" onClick={() => onPay(b)}
          className={`px-2 py-1 rounded-md ${stCls} text-[11px] font-bold`}>
          {stLabel}
        </button>
        <button type="button" onClick={() => onPresent(b)}
          className="text-[11px] px-2 py-1 rounded-md bg-blue-100 text-blue-700 font-semibold inline-flex items-center gap-1">
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
          </svg>
          Xuất trình
        </button>
        <button type="button" onClick={() => onUpload(b)}
          className="text-[11px] px-2 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold inline-flex items-center gap-1">
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
          Upload
        </button>
        <div className="flex-1" />
        <span className="font-mono tabular-nums font-bold text-blue-700 text-sm">
          {formatMoney(bookingTotal, b.currency)}
        </span>
      </div>
    </div>
  )
}

function Pagination({ page, totalPages, total, onPage }) {
  if (totalPages <= 1) return null
  return (
    <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-t border-gray-100 text-xs">
      <span className="text-gray-500">{total} vé · trang {page + 1}/{totalPages}</span>
      <div className="flex gap-1">
        <button onClick={() => onPage(Math.max(0, page - 1))} disabled={page === 0}
          className="px-2.5 py-1 rounded-md bg-white border border-gray-200 disabled:opacity-40 hover:bg-gray-100">←</button>
        <button onClick={() => onPage(Math.min(totalPages - 1, page + 1))} disabled={page >= totalPages - 1}
          className="px-2.5 py-1 rounded-md bg-white border border-gray-200 disabled:opacity-40 hover:bg-gray-100">→</button>
      </div>
    </div>
  )
}

// ── Utility ─────────────────────────────────────────────

function faceStatus(b, ticketId) {
  if (b.sharedTicketFace) return !!b.bookingFace
  const t = (b.tickets || []).find(x => x.id === ticketId)
  return !!t?.ticketFace
}

function kindLabel(k) {
  return { NEW: 'Mua mới', EXCHANGE: 'Đổi', REFUND: 'Hoàn', SERVICE: 'Dịch vụ' }[k] || k
}

/**
 * Tính tổng số tiền của list TicketFee của 1 vé, QUY về {@code targetCurrency}.
 *
 * ── 2026-10-12 multi-currency ────────────────────────────────
 * Mỗi fee có thể có currency riêng (VND/USD/null=inherit booking). Khi gộp
 * về booking.currency:
 *   - fee cùng currency → cộng thẳng
 *   - fee VND vào booking USD → chia cho exchangeRate
 *   - fee USD vào booking VND → nhân với exchangeRate
 *   - rate thiếu → bỏ qua (coi như 0) để không ra NaN
 */
function sumTicketFees(fees, targetCurrency = 'VND', exchangeRate = null) {
  if (!fees || fees.length === 0) return 0
  const rate = parseAmount(exchangeRate)
  let total = 0
  for (const f of fees) {
    const amt = parseAmount(f.amount)
    if (!Number.isFinite(amt)) continue
    const fc = (f.currency || targetCurrency || 'VND').toUpperCase()
    if (fc === targetCurrency) {
      total += amt
    } else if (targetCurrency === 'USD' && fc === 'VND') {
      if (Number.isFinite(rate) && rate > 0) total += amt / rate
    } else if (targetCurrency === 'VND' && fc === 'USD') {
      if (Number.isFinite(rate) && rate > 0) total += amt * rate
    }
  }
  return total
}

/**
 * Sum fees theo RIÊNG từng currency, trả { VND, USD }. Phục vụ TotalsCard
 * để bucket chính xác (fee VND trong booking USD vẫn vào VND).
 */
function sumFeesByCurrency(fees, fallbackCurrency = 'VND') {
  const out = { VND: 0, USD: 0 }
  if (!fees) return out
  for (const f of fees) {
    const amt = parseAmount(f.amount)
    if (!Number.isFinite(amt)) continue
    const fc = (f.currency || fallbackCurrency || 'VND').toUpperCase()
    if (fc === 'VND' || fc === 'USD') out[fc] += amt
  }
  return out
}

function formatDateTimeShort(ms) {
  if (!ms) return '—'
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(new Date(ms))
    const p = (t) => parts.find(x => x.type === t)?.value || ''
    return `${p('hour')}:${p('minute')} ${p('day')}/${p('month')}/${p('year')}`
  } catch { return '' }
}

/**
 * Ghép các mã sân bay trong segments thành 1 chuỗi liền, bỏ trùng lặp liền kề.
 * Dùng cho click-to-copy ô Hành trình.
 * VD: [{HAN,NRT}, {NRT,HAN}] → "HANNRTHAN"
 *     [{HAN,NRT}, {HKG,HAN}] → "HANNRTHKGHAN"  (route gãy — vẫn concat đủ mã)
 */
function routeCodes(segments) {
  if (!segments || segments.length === 0) return ''
  const codes = []
  for (const s of segments) {
    if (codes[codes.length - 1] !== s.fromCode) codes.push(s.fromCode)
    if (codes[codes.length - 1] !== s.toCode) codes.push(s.toCode)
  }
  return codes.join('')
}

/**
 * 2026-10-10: click hành trình → copy "SGNCGKSGN - " (có hậu tố - để user
 * paste tiếp). Giữ cho ô Hành trình.
 */
function routeConcat(segments) {
  const r = routeCodes(segments)
  return r ? r + ' - ' : ''
}

/**
 * 2026-10-10: Hậu tố loại giao dịch cho string copy từ booking.
 *   EXCHANGE → " (Phí Đổi Vé)"
 *   REFUND   → " (Phí Hoàn Vé)"
 *   NEW / SERVICE → ""
 */
function kindCopySuffix(kind) {
  if (kind === 'EXCHANGE') return ' (Phí Đổi Vé)'
  if (kind === 'REFUND')   return ' (Phí Hoàn Vé)'
  return ''
}

/**
 * 2026-10-10: Build chuỗi copy chuẩn cho mã booking / số vé.
 *   "{route} - {id}{kindSuffix}"
 * Route trống → "{id}{kindSuffix}" (fallback khi booking chưa có segment).
 */
function buildIdCopyString(segments, id, kind) {
  const r = routeCodes(segments)
  const suffix = kindCopySuffix(kind)
  if (!r) return `${id}${suffix}`
  return `${r} - ${id}${suffix}`
}

/**
 * 2026-10-10: Build chuỗi copy cho dòng phí dịch vụ.
 *   "{route} - {ticketNumber || bookingCode} ({feeLabelTitleCase})"
 * KHÔNG áp dụng kindSuffix (fee label đã là identifier riêng).
 */
function buildFeeCopyString(segments, ticketNumber, bookingCode, feeLabelTitleCase) {
  const r = routeCodes(segments)
  const id = (ticketNumber && ticketNumber.trim()) || bookingCode || ''
  const feePart = `(${feeLabelTitleCase})`
  if (!r) return id ? `${id} ${feePart}` : feePart
  return id ? `${r} - ${id} ${feePart}` : `${r} - ${feePart}`
}