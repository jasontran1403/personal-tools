import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import toast from 'react-hot-toast'
import ConfirmModal from '../common/ConfirmModal'
import Modal from '../common/Modal'
import BookingFormModal from './BookingFormModal'
import TicketFaceModal from './TicketFaceModal'
import InvoiceManagerModal from './InvoiceManagerModal'
import PresentationModal from './PresentationModal'
import UploadOptionsModal from './UploadOptionsModal'
import TicketNoteModal from './TicketNoteModal'
import BookingTotalsCard from './BookingTotalsCard'
import PaymentModal from './PaymentModal'
import InvoicePickerModal from './InvoicePickerModal'
import { unpaidTicketsOf, narrowBooking } from '../../lib/ticketDebt'
import BatchPaymentModal from './BatchPaymentModal'
import DateRangePicker from '../common/DateRangePicker'
import MobileFabCluster, { Fab } from '../common/MobileFabCluster'
import CompanySearchSelect, { companyOptions } from '../common/CompanySearchSelect'
import {
  listBookings, deleteBooking, totalsBookings, listCompanies,
  listInvoicePayments, deletePayment, ensureBookingInvoice
} from '../../services/vmbApi'
// 2026-11-07: dùng cho PaidReceiptsModal (xem/xoá biên nhận khi đã thanh toán)
import ZoomablePreview from './ZoomablePreview'
import { parseAmount, formatMoney, sumAmounts, toVnd } from '../../lib/money'
import { primaryDeparture } from '../../lib/countdown'
import { formatDepart, formatDepartFull } from '../../lib/airportTz'

/**
 * ── 2026-09-15 ──────────────────────────────────────────────
 * - Click MÃ BOOKING → mở mặt vé chung (shared) hoặc chọn khách (per-ticket).
 * - Click SỐ VÉ → mở mặt vé riêng (per-ticket) hoặc face chung (shared).
 * - Nút action 📄 = "Xem chi tiết mặt vé".
 *
 * ── Cải tiến hiển thị (2026-09-15 chiều) ────────────────────
 * 1. Group tickets THEO CÔNG TY trong 1 booking. Vé cùng công ty đứng liền
 *    nhau; ô công ty MERGE (rowspan) qua các vé cùng công ty.
 *    Ví dụ booking có 4 vé Cty A/B/A/A → sắp lại A-A-A-B, ô Cty A rowspan=3.
 *    Thứ tự công ty giữ theo thứ tự xuất hiện đầu tiên trong booking gốc
 *    (không sort alphabet — để user thấy "cty đầu tiên đặt" ở trên).
 *
 * 2. Cột "Booking / số vé" → chỉ còn "Booking" (mã booking, rowspan cả booking).
 *    Số vé chuyển sang cột "Khách hàng":
 *        Dòng trên: tên khách
 *        Dòng dưới: số vé (font mono, click được để mở face)
 */
/** YYYY-MM-DD theo giờ local — khởi tạo filter mặc định (hôm nay). */
function todayISO() {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

export default function TicketsTab({ onOpenInvoices, fabHidden, refreshSignal } = {}) {
  const [rows, setRows] = useState([])
  const [totals, setTotals] = useState([])
  const [loading, setLoading] = useState(true)
  const [totalsLoading, setTotalsLoading] = useState(false)

  const [q, setQ] = useState('')
  // 2026-11-11: Mặc định khoảng ngày bán = HÔM NAY. User vẫn đổi được bằng
  //   DateRangePicker; nếu xóa sạch range thì về "tất cả".
  const [fromSale, setFromSale] = useState('')
  const [toSale, setToSale] = useState('')
  // 2026-10-10: Filter trạng thái thanh toán. '' = tất cả, 'PAID' = đã thanh toán,
  // 'UNPAID' = chưa thanh toán (gồm cả PARTIAL).
  const [paymentStatus, setPaymentStatus] = useState('')
  // ── 2026-11-07: Sort booking theo thời gian bay gần nhất ──
  //   'default' = thứ tự của BE (createdAt/saleDate desc).
  //   'nearestDeparture' = booking có chặng bay gần nhất (chưa qua) lên đầu;
  //       booking đã bay hết / không có segment xuống cuối, giữ thứ tự mặc định
  //       giữa các booking cùng band.
  const [sortMode, setSortMode] = useState('default')
  // ── 2026-10-09: Filter theo công ty ──
  // null = Tất cả (mặc định). Số = id công ty.
  // List công ty lấy từ listCompanies (dùng chung với tab Thông tin khách).
  // Filter áp dụng client-side: giữ booking nếu có ÍT NHẤT 1 vé có companyId
  // trùng; các số liệu ở card tổng sẽ tính lại từ các vé khớp filter.
  const [companyId, setCompanyId] = useState(null)
  const [companies, setCompanies] = useState([])
  // 2026-10-28: Bỏ phân trang → gộp các trang vào CÙNG 1 danh sách (load more).
  //   - `page` = chỉ số trang CAO NHẤT đã load (0-based). Khi filter đổi reset về 0.
  //   - `rows` tích lũy content của mọi trang 0..page.
  //   - `loadingMore` cho nút "Tải thêm" (không chớp bảng).
  //   - `refresh()` fetch lại pages 0..page và GIỮ scroll (dùng sau khi sửa/xóa
  //     booking/hóa đơn/mặt vé → tránh bị kéo về top).
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [loadingMore, setLoadingMore] = useState(false)
  const desktopScrollRef = useRef(null)
  const mobileScrollRef = useRef(null)

  const [selectedIds, setSelectedIds] = useState(() => new Set())

  const [form, setForm] = useState(null)
  // 2026-11-12: Panel mobile — 'filter' | 'sum' | null. Gom toolbar + Σ tổng
  //   vào modal, mở bằng FAB; desktop không dùng (toolbar/summary vẫn inline).
  const [mobilePanel, setMobilePanel] = useState(null)
  const [face, setFace] = useState(null)   // { booking, ticketId }
  const [invMgr, setInvMgr] = useState(null)
  // 2026-10-12: payFor giờ chứa { booking, invoice } — invoice BẮT BUỘC.
  const [payFor, setPayFor] = useState(null)
  // Picker modal khi booking có >1 invoice.
  const [invoicePicker, setInvoicePicker] = useState(null) // booking | null
  // 2026-11-07: modal xem/xoá biên nhận cho booking đã thanh toán.
  const [paidReceiptsFor, setPaidReceiptsFor] = useState(null)
  const [batchPay, setBatchPay] = useState(null)
  const [noteView, setNoteView] = useState(null)
  const [confirmDel, setConfirmDel] = useState(null)
  // ── 2026-09-19: Xuất trình + Upload ──
  const [presentation, setPresentation] = useState(null) // booking
  const [uploadFor, setUploadFor] = useState(null) // booking
  const [exporting, setExporting] = useState(false)

  const [nowTick, setNowTick] = useState(Date.now())
  useEffect(() => {
    const id = setInterval(() => setNowTick(Date.now()), 30_000)
    return () => clearInterval(id)
  }, [])

  const filterParams = useMemo(() => {
    const p = {}
    if (q) p.q = q
    if (fromSale) p.fromSale = new Date(fromSale + 'T00:00:00').getTime()
    if (toSale) p.toSale = new Date(toSale + 'T23:59:59').getTime()
    if (paymentStatus) p.paymentStatus = paymentStatus
    return p
  }, [q, fromSale, toSale, paymentStatus])

  // Load lần đầu / khi filter đổi: lấy page 0, THAY rows.
  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await listBookings({ ...filterParams, page: 0, size: 50 })
      const d = res.data?.data
      setRows(d?.content || [])
      setTotalPages(d?.totalPages || 1)
      setTotal(d?.totalElements || 0)
      setPage(0)
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Không tải được danh sách vé')
    } finally {
      setLoading(false)
    }
  }, [filterParams])

  // Load thêm 1 trang tiếp theo và APPEND vào rows.
  // Dùng ref để chống trùng gọi (scroll bắn nhiều event trước khi state kịp cập nhật).
  const loadingMoreRef = useRef(false)
  const loadMore = useCallback(async () => {
    if (loadingMoreRef.current || loading) return
    if (page >= totalPages - 1) return
    loadingMoreRef.current = true
    setLoadingMore(true)
    try {
      const next = page + 1
      const res = await listBookings({ ...filterParams, page: next, size: 50 })
      const d = res.data?.data
      setRows(prev => [...prev, ...(d?.content || [])])
      setTotalPages(d?.totalPages || 1)
      setTotal(d?.totalElements || 0)
      setPage(next)
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Không tải thêm được danh sách vé')
    } finally {
      loadingMoreRef.current = false
      setLoadingMore(false)
    }
  }, [filterParams, page, totalPages, loading])

  // 2026-10-28 (v2): Infinite scroll — scroll qua ngưỡng 80% chiều cao
  // → tự fetch trang kế tiếp. Dùng cho CẢ desktop (ref container bảng) và
  // mobile (ref container card). Guard loadingMoreRef chặn trigger kép.
  const onScrollLoadMore = useCallback((e) => {
    if (loadingMoreRef.current || loading) return
    if (page >= totalPages - 1) return
    const el = e.currentTarget
    const scrolled = el.scrollTop + el.clientHeight
    const threshold = el.scrollHeight * 0.8
    if (scrolled >= threshold) loadMore()
  }, [loadMore, loading, page, totalPages])

  // Soft-refresh: refetch pages 0..page sau khi sửa/xóa/cập nhật.
  //   - KHÔNG set `loading=true` để bảng không bị thay bằng "Đang tải…" (giữ UI).
  //   - Lưu scrollTop trước khi fetch, restore sau khi commit rows.
  const refresh = useCallback(async () => {
    const dTop = desktopScrollRef.current?.scrollTop ?? 0
    const mTop = mobileScrollRef.current?.scrollTop ?? 0
    const upTo = page
    try {
      const acc = []
      let lastMeta = null
      for (let p = 0; p <= upTo; p++) {
        const res = await listBookings({ ...filterParams, page: p, size: 50 })
        const d = res.data?.data
        acc.push(...(d?.content || []))
        lastMeta = d
        // Nếu BE báo totalPages đã co lại (xóa booking cuối cùng của trang),
        // dừng sớm — không fetch trang không tồn tại.
        if (lastMeta && p >= (lastMeta.totalPages || 1) - 1) break
      }
      setRows(acc)
      if (lastMeta) {
        const tp = lastMeta.totalPages || 1
        setTotalPages(tp)
        setTotal(lastMeta.totalElements || 0)
        if (page > tp - 1) setPage(Math.max(0, tp - 1))
      }
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Không tải lại được danh sách vé')
    } finally {
      // Restore scroll — chạy ở frame tiếp theo để React commit DOM xong.
      requestAnimationFrame(() => {
        if (desktopScrollRef.current) desktopScrollRef.current.scrollTop = dTop
        if (mobileScrollRef.current) mobileScrollRef.current.scrollTop = mTop
      })
    }
  }, [filterParams, page])

  const loadTotals = useCallback(async () => {
    setTotalsLoading(true)
    try {
      const res = await totalsBookings(filterParams)
      setTotals(res.data?.data || [])
    } catch { /* silent */ }
    finally { setTotalsLoading(false) }
  }, [filterParams])

  useEffect(() => { load() }, [load])
  useEffect(() => { loadTotals() }, [loadTotals])

  // 2026-11-15: Khi quay lại Vé máy bay từ Quản lý hóa đơn → nạp lại dữ liệu
  //   (giữ scroll) để phản ánh thay đổi vừa làm bên kia. Bỏ qua lần đầu.
  const firstRefreshRef = useRef(true)
  useEffect(() => {
    if (firstRefreshRef.current) { firstRefreshRef.current = false; return }
    refresh(); loadTotals()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshSignal])

  // Load danh sách công ty 1 lần cho dropdown filter
  useEffect(() => {
    let cancel = false
    listCompanies()
      .then(res => { if (!cancel) setCompanies(res.data?.data || []) })
      .catch(() => { /* silent — filter vẫn work với 0 công ty */ })
    return () => { cancel = true }
  }, [])

  const flatCompanies = useMemo(() => companyOptions(companies || []), [companies])

  // ── Filter client-side theo companyId ─────────────────────
  // Booking match nếu có ≥1 vé có companyId trùng với filter.
  // ── 2026-11-07 ────────────────────────────────────────────
  //   - Sort theo nearestDeparture nếu user bấm nút sort.
  //   - Guard Req 4: nếu user chọn filter UNPAID mà booking có TOTAL ≈ 0
  //     thì không hiển thị booking này (dữ liệu cũ có thể còn paymentStatus
  //     chưa được rollup về PAID — ép client-side cho khớp BE).
  const filteredRows = useMemo(() => {
    let out = rows
    if (companyId != null) {
      out = out.filter(b => (b.tickets || []).some(t => t.companyId === companyId))
    }
    // Guard UNPAID: nếu client tính được total = 0 → ẩn khỏi danh sách UNPAID,
    // vì về mặt logic booking miễn phí đã được coi là đã thanh toán.
    if (paymentStatus === 'UNPAID') {
      out = out.filter(b => {
        const bt = sumAmounts(...(b.tickets || []).map(t =>
          sumAmounts(t.basePrice, t.collectionFee,
            sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
        return bt > 0.5
      })
    }
    if (sortMode === 'nearestDeparture') {
      // Dùng nowTick để sort ổn định trong 1 tick; nearest = chặng ĐẦU chưa qua.
      const keyOf = (b) => {
        const pd = primaryDeparture(b.segments, nowTick)
        return pd?.departMs ?? Number.POSITIVE_INFINITY
      }
      // Clone trước khi sort để không mutate rows gốc.
      out = [...out].sort((a, b) => keyOf(a) - keyOf(b))
    }
    return out
  }, [rows, companyId, paymentStatus, sortMode, nowTick])

  // ── Totals: khi có filter công ty thì tính lại từ các vé khớp filter.
  //    Khi không có filter thì dùng totals từ BE (tổng toàn hệ thống theo
  //    q + date range).
  const displayTotals = useMemo(() => {
    if (companyId == null) return totals
    // 2026-10-12: Split theo fee.currency, không chỉ booking.currency.
    const agg = {
      VND: { subTotal: 0, issuanceFee: 0, grandTotal: 0, ticketCount: 0 },
      USD: { subTotal: 0, issuanceFee: 0, grandTotal: 0, ticketCount: 0 },
    }
    for (const b of filteredRows) {
      const cur = b.currency === 'USD' ? 'USD' : 'VND'
      for (const t of (b.tickets || [])) {
        if (t.companyId !== companyId) continue
        const baseColl = sumAmounts(t.basePrice, t.collectionFee)
        const issuanceFee = parseAmount(t.issuanceFee) || 0
        // basePrice/collection/issuance luôn vào bucket booking.currency
        agg[cur].subTotal += baseColl
        agg[cur].issuanceFee += issuanceFee
        agg[cur].grandTotal += baseColl + issuanceFee
        agg[cur].ticketCount += 1
        // Fees: cộng theo currency riêng
        const fByCur = sumFeesByCurrency(t.fees, cur)
        agg.VND.subTotal += fByCur.VND
        agg.VND.grandTotal += fByCur.VND
        agg.USD.subTotal += fByCur.USD
        agg.USD.grandTotal += fByCur.USD
      }
    }
    return ['VND', 'USD'].map(c => ({
      currency: c,
      subTotal: formatMoney(agg[c].subTotal, c, { withUnit: false }),
      issuanceFee: formatMoney(agg[c].issuanceFee, c, { withUnit: false }),
      grandTotal: formatMoney(agg[c].grandTotal, c, { withUnit: false }),
      ticketCount: agg[c].ticketCount,
    }))
  }, [companyId, filteredRows, totals])

  useEffect(() => {
    setSelectedIds(prev => {
      const valid = new Set(filteredRows.map(r => r.id))
      const next = new Set()
      for (const id of prev) if (valid.has(id)) next.add(id)
      return next
    })
  }, [filteredRows])

  const qTimer = useRef(null)
  const onSearch = (v) => {
    if (qTimer.current) clearTimeout(qTimer.current)
    // 2026-10-28: filter thay đổi → `load` tự reset page=0, không cần setPage ở đây.
    qTimer.current = setTimeout(() => { setQ(v) }, 300)
  }

  // 2026-10-10: Chặn chọn booking đã PAID (không có gì để thu nữa).
  const isPaidBooking = (b) => (b?.paymentStatus === 'PAID')

  const toggleSelect = (id) => {
    const b = filteredRows.find(r => r.id === id)
    if (b && isPaidBooking(b)) return // bỏ qua — booking đã thanh toán xong
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }
  const toggleAllOnPage = () => {
    // Chỉ áp lên các booking CHƯA PAID (bỏ qua đã thanh toán).
    const selectable = filteredRows.filter(r => !isPaidBooking(r))
    setSelectedIds(prev => {
      const allSelected = selectable.length > 0 && selectable.every(r => prev.has(r.id))
      const next = new Set(prev)
      if (allSelected) selectable.forEach(r => next.delete(r.id))
      else selectable.forEach(r => next.add(r.id))
      return next
    })
  }
  const clearSelection = () => setSelectedIds(new Set())

  // 2026-10-10: Lọc bỏ booking PAID khỏi danh sách batch (phòng khi state cũ còn id của booking vừa đổi).
  const selectedBookings = useMemo(
    () => filteredRows.filter(r => selectedIds.has(r.id) && r.paymentStatus !== 'PAID'),
    [filteredRows, selectedIds]
  )

  const onBatchPay = () => {
    if (selectedBookings.length < 2) return toast.error('Chọn ít nhất 2 booking để thu batch.')
    setBatchPay(selectedBookings)
  }

  // 2026-10-28: refresh thay cho load → giữ nguyên các trang đã load thêm
  // và scroll position, user không bị kéo về đầu trang sau khi thao tác.
  const onSavedRefresh = () => { refresh(); loadTotals() }

  // ── 2026-09-20: Xuất báo cáo PDF theo filter ──────────────
  // ── 2026-09-25: sau khi xuất xong, nếu có hóa đơn nháp → hỏi tải luôn ──
  // ── 2026-09-25 (guard) ────────────────────────────────────
  // Chỉ mời tải hóa đơn nháp khi:
  //   G1: date range của báo cáo NẰM TRONG NGÀY HÔM NAY (fromMs & toMs đều
  //       là hôm nay). Nếu chọn khoảng khác → không mời.
  //   G2: MỌI VÉ trong các booking đã có hóa đơn nháp bao phủ. Nếu còn vé
  //       chưa có → warning và không tải.
  // 2026-11-11 (rev2): Bỏ state confirmDraftDl — xem comment downloadDraftsNow.
  const [warnMissingDraft, setWarnMissingDraft] = useState(null) // { missing: [...] }

  // ── 2026-11-07 (rev): tách thành picker 2 option ──────────
  //   A — Báo cáo vé hôm nay: ÉP filter range về hôm nay, giữ nguyên các
  //       filter khác (q, company), rồi chạy flow exportBookingsReport +
  //       hỏi tải hóa đơn nháp như cũ. KHÔNG cần user chọn ngày trước.
  //   B — Báo cáo công nợ: mở modal chọn công ty / chi nhánh, nhập số hoá
  //       đơn, generate PDF riêng.
  const [exportPick, setExportPick] = useState(false)   // bool — mở picker
  const [debtOpen, setDebtOpen] = useState(false)   // bool — mở modal công nợ
  // 2026-11-11: Modal "có kèm hóa đơn nháp không?" khi xuất báo cáo nhiều ngày.
  const [askInvoices, setAskInvoices] = useState(null)   // { bookings } | null

  // ── 2026-11-11: Xuất báo cáo BÁN VÉ ─────────────────────────────────────
  //   Dùng chung 1 nút: xuất các booking trong khoảng ngày UI đang chọn.
  //   Nhánh chạy sau khi có file PDF:
  //     • Range = đúng hôm nay → tự động tải kèm hóa đơn nháp (hành vi cũ).
  //     • Range có nhiều ngày (hoặc một ngày không phải hôm nay) → hỏi modal
  //       "có tải kèm hóa đơn nháp không?".
  //   Trường hợp thiếu / không có hóa đơn nháp: toast báo, không hỏi.
  const handleExportBookingsReport = async () => {
    setExportPick(false)
    if (!fromSale && !toSale) {
      return toast.error('Chọn khoảng ngày bán trước (ô ngày ở toolbar) rồi thử lại.')
    }
    setExporting(true)
    const tid = toast.loading('Đang tải dữ liệu và tạo PDF…')
    try {
      const mod = await import('../../lib/bookingsPdfExport')
      const { bookings, fromMs, toMs } = await mod.exportBookingsReport(filterParams, {
        onProgress: (loaded, total) => {
          toast.loading(`Đã tải ${loaded}/${total || '?'} booking…`, { id: tid })
        },
      })
      toast.success('Đã tạo PDF', { id: tid })

      const count = mod.countDraftInvoices(bookings)
      if (count === 0) return
      const missing = mod.findTicketsMissingDraftInvoice(bookings)
      // ── 2026-11-11 (rev2): Range = hôm nay → KHÔNG hỏi, tải thẳng ──
      //   User đã tắt "Ask where to save each file" trong browser nên muốn
      //   mọi hoá đơn tự về Downloads. Vẫn cảnh báo khi có vé chưa có nháp.
      if (mod.isRangeWithinToday(fromMs, toMs)) {
        if (missing.length > 0) { setWarnMissingDraft({ missing }); return }
        downloadDraftsNow(bookings, count)
      } else {
        // Nhiều ngày / ngày khác → hỏi 2 nút.
        setAskInvoices({ bookings, count, missing })
      }
    } catch (e) {
      console.error('[PDF export]', e)
      toast.error(e?.message || 'Xuất PDF thất bại', { id: tid })
    } finally {
      setExporting(false)
    }
  }

  // 2026-11-11: Tách thành hàm dùng chung — nhánh "hôm nay" gọi thẳng không
  //   qua modal confirm, nhánh "nhiều ngày" đi qua AskInvoicesModal → vẫn
  //   gọi hàm này. Modal "ConfirmDraftDl" cũ bị gỡ ra khỏi JSX bên dưới.
  const downloadDraftsNow = async (bookings, count) => {
    const tid = toast.loading(`Chuẩn bị tải ${count} hoá đơn nháp…`)
    try {
      const mod = await import('../../lib/bookingsPdfExport')
      const { total, done, errors, zipped, zipName } = await mod.downloadDraftInvoices(bookings, {
        onProgress: (d, t) => toast.loading(`Đang tải ${d}/${t} hoá đơn nháp…`, { id: tid }),
      })
      if (done === total) {
        toast.success(
          zipped
            ? `Đã gộp ${done} hoá đơn vào ${zipName}`
            : `Đã tải ${done} hoá đơn nháp`,
          { id: tid, duration: 4000 })
      } else {
        toast.error(`Tải ${done}/${total} hoá đơn nháp — ${errors?.length || 0} file lỗi`, { id: tid })
      }
    } catch (e) {
      console.error('[Draft invoice download]', e)
      toast.error(e?.message || 'Tải hoá đơn nháp thất bại', { id: tid })
    }
  }

  // ── 2026-09-19: click Mã booking → Xuất trình modal. Upload nằm ở cột thao tác. ──
  const openBookingFace = (b) => setPresentation(b)
  const openTicketFace = (b, ticketId) => setFace({ booking: b, ticketId })
  const openUpload = (b) => setUploadFor(b)

  /**
   * 2026-10-12: Thu tiền giờ ở cấp HÓA ĐƠN.
   *   - Booking không có invoice → warning (user phải upload hóa đơn trước)
   *   - Booking có 1 invoice → mở PaymentModal thẳng
   *   - Booking có >1 invoice → mỗi hoá đơn 1 nút riêng trên bảng (2026-11-11);
 *     picker chỉ còn là fallback khi gọi openPay(b) không kèm invoice.
   */
  const openPay = async (b, invoice) => {
    // ── 2026-11-11: Booking tách nhiều hoá đơn → mỗi hoá đơn 1 nút riêng,
    //   bấm nút nào mở thẳng PaymentModal của hoá đơn đó (thu / xem & xoá
    //   phiếu thu). Phục vụ case công ty này trả, công ty kia còn công nợ.
    if (invoice) {
      setPayFor({ booking: b, invoice })
      return
    }
    // 2026-10-13: Booking tổng = 0 → đã PAID auto, không cần thu/tạo invoice.
    const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
      sumAmounts(t.basePrice, t.collectionFee,
        sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
    if (bookingTotal <= 0.5) {
      toast.success('Booking miễn phí (tổng = 0) — đã tự đánh dấu Đã thanh toán.')
      return
    }
    const invs = b.invoices || []
    if (invs.length === 0) {
      // 2026-11-15: Hóa đơn nháp lấy trực tiếp từ VinVoice → mọi booking coi như
      //   đã có hóa đơn nháp. Chưa có bản ghi Invoice thì BE tự tạo mặc định rồi
      //   trả về để thu luôn (bỏ bắt buộc tạo/upload hóa đơn trước).
      try {
        const res = await ensureBookingInvoice(b.id)
        const list = res.data?.data || []            // BE trả DANH SÁCH hoá đơn (tách link)
        const bWithInvs = { ...b, invoices: list }
        const unpaid = list.filter(i => i.paymentStatus !== 'PAID')
        if (unpaid.length === 1) { setPayFor({ booking: bWithInvs, invoice: unpaid[0] }); return }
        if (unpaid.length > 1) { setInvoicePicker(bWithInvs); return }  // nhiều phần → chọn hoá đơn
        if (list.length > 0) { setPaidReceiptsFor(bWithInvs); return }
        toast.error('Không tạo được hóa đơn để thu tiền.')
      } catch (e) {
        toast.error(e?.response?.data?.message || 'Không tạo được hóa đơn để thu tiền.')
      }
      return
    }
    // ── 2026-11-07 (rev2): Booking đã thu đủ TOÀN BỘ hoá đơn → mở modal
    //   RECEIPTS riêng (chỉ xem ảnh biên nhận + xoá). Không mở PaymentModal
    //   nữa vì user không cần nhập thêm tiền khi đã đủ.
    const unpaid = invs.filter(i => i.paymentStatus !== 'PAID')
    if (unpaid.length === 0) {
      setPaidReceiptsFor(b)
      return
    }
    if (invs.length === 1) {
      setPayFor({ booking: b, invoice: invs[0] })
    } else {
      setInvoicePicker(b)
    }
  }

  return (
    // 2026-10-10: Layout flex column — toolbar + totals shrink-0, bảng flex-1 overflow-auto.
    // VmbPage container đã `overflow-hidden`, tab này tự quản lý scroll để các ô
    // search/filter/nút chức năng + card tổng tiền NẰM YÊN, chỉ các dòng cuộn.
    <div className="w-full h-full flex flex-col">
      {/* 2026-11-12: Toolbar — chỉ hiện trên desktop (lg+). Trên mobile các control
          này dồn vào modal mở bằng FAB 🔍 ở góc phải dưới. */}
      <div className="shrink-0 hidden lg:flex lg:flex-row gap-2 mb-3">
        <input
          defaultValue={q}
          onChange={e => onSearch(e.target.value)}
          placeholder="Tìm theo mã booking, số vé, tên khách, hành trình, số hóa đơn…"
          className="flex-1 min-w-0 px-3.5 py-2 rounded-lg border border-gray-300 bg-white text-sm
            focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none" />
        <button type="button" onClick={onOpenInvoices}
          title="Quản lý hóa đơn"
          className="px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white
            text-sm font-semibold shadow-md shadow-indigo-500/20 shrink-0 whitespace-nowrap
            flex items-center gap-1.5">
          🧾 Hóa đơn
        </button>

        {/* 2026-10-09: Filter theo công ty — mặc định "Tất cả" (null) */}
        <div className="w-full lg:w-64 shrink-0">
          <CompanySearchSelect
            value={companyId}
            options={flatCompanies}
            onChange={(id) => setCompanyId(id)}
            placeholder="— Tất cả công ty —"
            noneLabel="— Tất cả công ty —"
            allowNone={true}
          />
        </div>

        <div className="flex gap-2 items-center shrink-0">
          <div className="w-72">
            <DateRangePicker
              value={{ from: fromSale, to: toSale }}
              onChange={({ from, to }) => {
                setFromSale(from)
                setToSale(to)
              }}
              placeholder="Chọn khoảng ngày bán"
            />
          </div>
        </div>

        {/* ── 2026-11-07 (rev): Filter trạng thái → single toggle 3-state ──
            Tất cả → Chưa thanh toán → Đã thanh toán → (loop) Tất cả. */}
        {(() => {
          const CYCLE = ['', 'UNPAID', 'PAID']
          const LABEL = { '': 'Tất cả', UNPAID: 'Chưa thanh toán', PAID: 'Đã thanh toán' }
          const STYLE = {
            '': 'bg-gray-100 text-gray-700 border-gray-300',
            UNPAID: 'bg-rose-500 text-white border-rose-500 shadow-sm',
            PAID: 'bg-emerald-500 text-white border-emerald-500 shadow-sm',
          }
          const next = () => {
            const i = CYCLE.indexOf(paymentStatus)
            setPaymentStatus(CYCLE[(i + 1) % CYCLE.length])
          }
          return (
            <button type="button" onClick={next}
              title="Bấm để đổi: Tất cả → Chưa thanh toán → Đã thanh toán"
              // 2026-11-07 (rev): width cố định ~160px để nút không co giãn
              //   theo nhãn (mỗi state chữ dài khác nhau → đẩy input bên trái).
              className={`w-[160px] text-center px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 border transition ${STYLE[paymentStatus]}`}>
              💳 {LABEL[paymentStatus]}
            </button>
          )
        })()}

        {/* ── 2026-11-07: Sort booking theo thời gian bay gần nhất ── */}
        <button type="button"
          onClick={() => setSortMode(m => m === 'nearestDeparture' ? 'default' : 'nearestDeparture')}
          title="Sắp xếp booking theo thời gian bay gần nhất (chặng chưa qua)"
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 border ${sortMode === 'nearestDeparture'
              ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
              : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
            }`}>
          ⏱ Bay gần nhất {sortMode === 'nearestDeparture' ? '•' : ''}
        </button>

        {/* 2026-11-07 (rev): nút này giờ mở picker 2 option */}
        <button type="button" onClick={() => setExportPick(true)} disabled={exporting}
          title="Xuất PDF — chọn loại báo cáo"
          className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white
            text-sm font-semibold shadow-md shadow-emerald-500/20 shrink-0 disabled:opacity-50">
          {exporting ? '⏳ Đang xuất…' : '📄 Xuất PDF'}
        </button>

        {/* 2026-11-07 (rev): icon-only, giữ title để tooltip */}
        <button type="button" onClick={() => setForm({ mode: 'create' })}
          title="Thêm booking mới"
          className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white
            text-xl font-bold shadow-md shadow-blue-500/20 hover:from-blue-700 hover:to-indigo-700 shrink-0
            flex items-center justify-center leading-none">
          +
        </button>
      </div>

      {/* 2026-11-15: portal ra document.body — bar nằm trong slider có transform
          (swipe Vé máy bay ⟷ Hóa đơn) nên position:fixed bị neo theo slider,
          lệch sang phải/ẩn. Portal ra body để fixed neo theo viewport. */}
      {selectedIds.size > 0 && createPortal(
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40
                        p-3 rounded-xl bg-amber-50 border border-amber-300 shadow-lg
                        flex items-center gap-3 flex-wrap min-w-[320px]">
          <span className="text-sm font-semibold text-amber-900">
            Đã chọn {selectedIds.size} booking
          </span>
          <div className="flex-1" />
          <button onClick={onBatchPay}
            className="px-3 py-1.5 rounded-md bg-blue-600 text-white text-xs font-bold hover:bg-blue-700">
            💰 Thu tiền hàng loạt
          </button>
          <button onClick={clearSelection}
            className="px-2 py-1.5 rounded-md text-xs text-gray-600 hover:bg-white/60">
            Bỏ chọn
          </button>
        </div>,
        document.body
      )}

      {/* 2026-11-12: Σ Tổng — desktop hiện inline; mobile mở bằng FAB Σ. */}
      <div className="hidden lg:block shrink-0">
        <BookingTotalsCard totals={displayTotals} loading={totalsLoading && companyId == null} />
      </div>

      {/* Desktop table — chiếm phần còn lại, cuộn trong khung bảng */}
      <div className="hidden lg:flex flex-1 min-h-0 bg-white rounded-2xl shadow border border-gray-100 overflow-hidden flex-col">
        <div ref={desktopScrollRef} onScroll={onScrollLoadMore} className="flex-1 overflow-auto">
          <table className="w-full text-xs border-collapse table-fixed">
            {/* 2026-11-11: không chèn comment JSX {/_ ... _/} giữa các <col/>
                nữa — comment inline sinh ra whitespace text node giữa
                <colgroup> và <col/>, React bật warning validateDOMNesting.
                Các độ rộng theo thứ tự cột bên dưới:
                  0  checkbox
                  1  Loại/Hãng
                  2  Công ty
                  3  Khách hàng (name + số vé)
                  4  Booking
                  5  Hành trình
                  6..14 các cột tiền + thao tác */}
            <colgroup>
              <col style={{ width: 32 }} />
              <col style={{ width: 130 }} />
              <col style={{ width: 130 }} />
              <col style={{ width: 210 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 130 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 90 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 120 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
            </colgroup>
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px] sticky top-0 z-10">
              <tr>
                <Th center>
                  {(() => {
                    const selectable = filteredRows.filter(r => !isPaidBooking(r))
                    const allSel = selectable.length > 0 && selectable.every(r => selectedIds.has(r.id))
                    return <input type="checkbox"
                      checked={allSel}
                      onChange={toggleAllOnPage}
                      disabled={selectable.length === 0}
                      className="rounded disabled:opacity-30" />
                  })()}
                </Th>
                <Th>Loại / hãng</Th>
                <Th>Công ty</Th>
                <Th>Khách hàng</Th>
                <Th>Booking</Th>
                <Th>Hành trình / giờ đi</Th>
                <Th>Giá gốc</Th>
                <Th>Giá trên vé / phí</Th>
                <Th>Thành tiền</Th>
                <Th>Phí xuất vé</Th>
                <Th>Giá bán</Th>
                <Th>Tổng booking</Th>
                <Th>Quy đổi VND</Th>
                <Th center>Thanh toán</Th>
                <ThR>Thao tác</ThR>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={15} className="text-center py-10 text-gray-400">Đang tải…</td></tr>
              ) : filteredRows.length === 0 ? (
                <tr><td colSpan={15} className="text-center py-14 text-gray-400">
                  {q || fromSale || toSale || companyId != null ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào. Bấm "Thêm booking" để tạo.'}
                </td></tr>
              ) : (
                filteredRows.map((b, bIdx) => renderBookingRows(b, bIdx, {
                  page, nowTick,
                  isSelected: selectedIds.has(b.id),
                  onToggleSelect: toggleSelect,
                  onOpenBookingFace: openBookingFace,
                  onOpenTicketFace: openTicketFace,
                  onPresent: setPresentation,
                  onUpload: openUpload,
                  onInvoice: (bookingId) => setInvMgr(bookingId),
                  onNote: setNoteView,
                  onPay: openPay,
                  onEdit: () => setForm({ mode: 'edit', bookingId: b.id }),
                  onDelete: () => setConfirmDel(b),
                }))
              )}
            </tbody>
          </table>
        </div>
        <LoadMoreBar
          loaded={rows.length}
          total={total}
          hasMore={page < totalPages - 1}
          loading={loadingMore}
        />
      </div>

      {/* Mobile cards — flex-1 overflow-auto */}
      <div ref={mobileScrollRef} onScroll={onScrollLoadMore} className="lg:hidden flex-1 min-h-0 overflow-auto space-y-2">
        {loading ? (
          <div className="text-center py-10 text-gray-400 text-sm">Đang tải…</div>
        ) : filteredRows.length === 0 ? (
          <div className="text-center py-14 text-gray-400 text-sm">
            {q || fromSale || toSale || companyId != null ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào.'}
          </div>
        ) : (
          filteredRows.map(b => (
            <MobileBookingCard key={b.id} booking={b} nowTick={nowTick}
              isSelected={selectedIds.has(b.id)}
              onToggleSelect={toggleSelect}
              onOpenBookingFace={openBookingFace}
              onOpenTicketFace={openTicketFace}
              onPresent={setPresentation}
              onUpload={openUpload}
              onInvoice={(id) => setInvMgr(id)}
              onNote={setNoteView}
              onPay={openPay}
              onEdit={() => setForm({ mode: 'edit', bookingId: b.id })}
              onDelete={() => setConfirmDel(b)} />
          ))
        )}
        <LoadMoreBar
          loaded={rows.length}
          total={total}
          hasMore={page < totalPages - 1}
          loading={loadingMore}
        />
      </div>

      {/* 2026-11-12: FAB mobile — kéo được, gom filter + thêm vé + Σ tổng */}
      <MobileFabCluster storageKey="vmbTicketsFab" hidden={fabHidden}>
        <Fab tone="filter" title="Bộ lọc & tìm kiếm" onClick={() => setMobilePanel('filter')}>🔍</Fab>
        <Fab tone="add" title="Thêm booking" onClick={() => setForm({ mode: 'create' })}>＋</Fab>
        <Fab tone="filter" title="Quản lý hóa đơn" onClick={onOpenInvoices}>🧾</Fab>
        <Fab tone="sum" title="Σ Tổng" onClick={() => setMobilePanel('sum')}>Σ</Fab>
      </MobileFabCluster>

      {mobilePanel === 'filter' && (
        <Modal open onClose={() => setMobilePanel(null)} title="Bộ lọc & tìm kiếm" size="md">
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Tìm kiếm</label>
              <input defaultValue={q} onChange={e => onSearch(e.target.value)}
                placeholder="Mã booking, số vé, tên khách, hành trình, số hóa đơn…"
                className="w-full px-3.5 py-2 rounded-lg border border-gray-300 bg-white text-sm
                  focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Công ty</label>
              <CompanySearchSelect value={companyId} options={flatCompanies}
                onChange={(id) => setCompanyId(id)} placeholder="— Tất cả công ty —"
                noneLabel="— Tất cả công ty —" allowNone={true} portal />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Khoảng ngày bán</label>
              <DateRangePicker value={{ from: fromSale, to: toSale }}
                onChange={({ from, to }) => { setFromSale(from); setToSale(to) }}
                placeholder="Chọn khoảng ngày bán" align="left" portal />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Trạng thái thanh toán</label>
              <div className="flex gap-2">
                {[['', 'Tất cả'], ['UNPAID', 'Chưa TT'], ['PAID', 'Đã TT']].map(([v, l]) => (
                  <button key={v} type="button" onClick={() => setPaymentStatus(v)}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold border transition ${paymentStatus === v
                        ? (v === 'UNPAID' ? 'bg-rose-500 text-white border-rose-500'
                          : v === 'PAID' ? 'bg-emerald-500 text-white border-emerald-500'
                            : 'bg-gray-700 text-white border-gray-700')
                        : 'bg-white text-gray-600 border-gray-300'}`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Sắp xếp theo chuyến bay</label>
              <div className="flex gap-2">
                <button type="button" onClick={() => setSortMode('default')}
                  className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold border ${sortMode !== 'nearestDeparture' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-gray-600 border-gray-300'}`}>
                  Mặc định
                </button>
                <button type="button" onClick={() => setSortMode('nearestDeparture')}
                  className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold border ${sortMode === 'nearestDeparture' ? 'bg-amber-500 text-white border-amber-500' : 'bg-white text-gray-600 border-gray-300'}`}>
                  ⏱ Bay gần nhất
                </button>
              </div>
            </div>
            <button type="button" onClick={() => { setMobilePanel(null); setExportPick(true) }} disabled={exporting}
              className="w-full px-3 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold disabled:opacity-50">
              {exporting ? '⏳ Đang xuất…' : '📄 Xuất PDF'}
            </button>
          </div>
        </Modal>
      )}

      {mobilePanel === 'sum' && (
        <Modal open onClose={() => setMobilePanel(null)} title="Σ Tổng" size="md">
          <BookingTotalsCard totals={displayTotals} loading={totalsLoading && companyId == null} />
        </Modal>
      )}

      {/* Modals */}
      {form && (
        <BookingFormModal
          mode={form.mode} bookingId={form.bookingId}
          onClose={() => setForm(null)}
          onSaved={() => { setForm(null); onSavedRefresh() }}
        />
      )}
      {face && (
        <TicketFaceModal
          booking={{
            ...face.booking,
            _onPickTicket: (tid) => setFace({ booking: face.booking, ticketId: tid })
          }}
          ticketId={face.ticketId}
          onClose={() => setFace(null)}
          onDirty={onSavedRefresh}
        />
      )}
      {invMgr && (
        <InvoiceManagerModal bookingId={invMgr} onClose={() => setInvMgr(null)} onDirty={refresh} />
      )}
      {presentation && (
        <PresentationModal open={true} booking={presentation} onClose={() => setPresentation(null)} />
      )}
      {uploadFor && (
        <UploadOptionsModal
          open={true}
          booking={uploadFor}
          onClose={() => setUploadFor(null)}
          onChanged={async () => {
            // Sau upload, reload booking để lấy state mới nhất (dùng cho grouping/hiện file
            // trong modal con nếu vẫn mở).
            try {
              const res = await import('../../services/vmbApi').then(m => m.getBooking(uploadFor.id))
              const b = res.data?.data
              if (b) setUploadFor(b)
              onSavedRefresh()
            } catch { /* silent */ }
          }}
        />
      )}
      {payFor && (
        <PaymentModal booking={payFor.booking} invoice={payFor.invoice}
          onClose={() => setPayFor(null)}
          onSaved={() => { setPayFor(null); onSavedRefresh() }} />
      )}
      {/* 2026-11-07: Modal xem/xoá biên nhận cho booking đã thanh toán. */}
      {paidReceiptsFor && (
        <PaidReceiptsModal booking={paidReceiptsFor}
          onClose={() => setPaidReceiptsFor(null)}
          onChanged={() => { onSavedRefresh() }}
          onCleared={() => { setPaidReceiptsFor(null); onSavedRefresh() }}
        />
      )}
      {invoicePicker && (
        <InvoicePickerModal booking={invoicePicker}
          onClose={() => setInvoicePicker(null)}
          onPick={(inv) => {
            setPayFor({ booking: invoicePicker, invoice: inv })
            setInvoicePicker(null)
          }} />
      )}
      {batchPay && (
        <BatchPaymentModal bookings={batchPay}
          onClose={() => setBatchPay(null)}
          onSaved={() => { setBatchPay(null); clearSelection(); onSavedRefresh() }} />
      )}
      {noteView && (
        <TicketNoteModal passengerName={noteView.passengerName} note={noteView.note}
          onClose={() => setNoteView(null)} />
      )}
      {/* ── 2026-11-07: Picker 2 option báo cáo PDF ── */}
      {exportPick && (
        <ExportPickerModal
          onClose={() => setExportPick(false)}
          fromSale={fromSale}
          toSale={toSale}
          onPickReport={handleExportBookingsReport}
          onPickDebt={() => { setExportPick(false); setDebtOpen(true) }}
        />
      )}
      {/* 2026-11-11: Hỏi "Có kèm hóa đơn nháp?" cho range nhiều ngày. */}
      {askInvoices && (
        <AskInvoicesModal
          bookings={askInvoices.bookings}
          count={askInvoices.count}
          missing={askInvoices.missing}
          onClose={() => setAskInvoices(null)}
          onYes={() => {
            const data = askInvoices
            setAskInvoices(null)
            // 2026-11-11 (rev2): user đã bấm "Tải kèm" rồi — không hỏi lần 2.
            if (data.missing.length > 0) {
              setWarnMissingDraft({ missing: data.missing })
            } else {
              downloadDraftsNow(data.bookings, data.count)
            }
          }}
        />
      )}
      {/* ── 2026-11-07: Modal báo cáo công nợ ── */}
      {debtOpen && (
        <DebtReportModal
          companies={companies}
          onClose={() => setDebtOpen(false)}
        />
      )}
      {warnMissingDraft && (
        <Modal
          open
          onClose={() => setWarnMissingDraft(null)}
          title="⚠️ Thiếu hóa đơn nháp"
          size="md"
          footer={
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setWarnMissingDraft(null)}
                className="px-4 py-2 text-sm font-semibold rounded-lg
                           bg-amber-600 text-white hover:bg-amber-700">
                Đã hiểu
              </button>
            </div>
          }
        >
          <div className="text-sm text-gray-700 space-y-2">
            <p>
              Không tải hóa đơn nháp vì có <b>{warnMissingDraft.missing.length} vé</b> chưa
              có hóa đơn nháp bao phủ. Vui lòng bổ sung trước khi tải:
            </p>
            <ul className="list-disc pl-5 space-y-1 max-h-72 overflow-y-auto">
              {warnMissingDraft.missing.slice(0, 30).map((m) => (
                <li key={`${m.bookingId}-${m.ticketId}`}>
                  <span className="font-mono text-gray-500">{m.bookingCode}</span>
                  {' — '}
                  <b>{m.passengerName}</b>
                </li>
              ))}
            </ul>
            {warnMissingDraft.missing.length > 30 && (
              <p className="text-xs text-gray-500 italic">
                … và {warnMissingDraft.missing.length - 30} vé khác
              </p>
            )}
          </div>
        </Modal>
      )}
      {/* 2026-11-11 (rev2): Bỏ ConfirmModal trung gian — nhánh hôm nay tải
          thẳng (tắt "Ask where to save" ở browser → auto về Downloads),
          nhánh nhiều ngày đi qua AskInvoicesModal đã hỏi rồi. */}
      {confirmDel && (
        <ConfirmModal
          open title="Xóa booking"
          message={`Xóa booking "${confirmDel.bookingCode || '(chưa có mã)'}" cùng ${confirmDel.tickets?.length || 0} vé, tất cả mặt vé và hóa đơn đính kèm?`}
          confirmLabel="Xóa" danger
          onConfirm={async () => {
            try {
              await deleteBooking(confirmDel.id)
              toast.success('Đã xóa'); setConfirmDel(null); onSavedRefresh()
            } catch (e) {
              toast.error(e?.response?.data?.message || 'Xóa thất bại')
            }
          }}
          onCancel={() => setConfirmDel(null)}
        />
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
//  HEADER CELLS
// ═══════════════════════════════════════════════════════════════

function Th({ children, center }) {
  return (
    <th className={`px-2 py-2 font-semibold align-middle ${center ? 'text-center' : 'text-left'}`}>
      {children}
    </th>
  )
}
function ThR({ children }) {
  return (
    <th className="px-2 py-2 font-semibold text-right align-middle">
      {children}
    </th>
  )
}

// ═══════════════════════════════════════════════════════════════
//  GROUP TICKETS THEO CÔNG TY
// ═══════════════════════════════════════════════════════════════

/**
 * Sắp xếp lại tickets: gom các vé cùng công ty lại với nhau. Thứ tự công ty
 * giữ theo thứ tự xuất hiện đầu tiên trong booking gốc (stable — không sort
 * alphabet, để user vẫn thấy công ty họ nhập đầu tiên ở trên đầu).
 *
 * Ví dụ input:  [Cty A khách1, Cty B khách2, Cty A khách3, Cty A khách4]
 * Output tickets: [khách1, khách3, khách4, khách2]
 * Output groups: [{key:A, size:3, tickets:[k1,k3,k4]}, {key:B, size:1, tickets:[k2]}]
 *
 * Key dùng cho công ty = companyId (null nếu khách lẻ) → 2 vé cùng "khách lẻ"
 * (null companyId) cũng merge.
 */
function groupTicketsByCompany(tickets) {
  const buckets = new Map()   // key → { key, origIdx (first appearance), tickets: [{t, origIdx}] }
  const list = tickets || []
  for (let i = 0; i < list.length; i++) {
    const t = list[i]
    const key = t.companyId == null ? 'none' : `c${t.companyId}`
    if (!buckets.has(key)) buckets.set(key, { key, tickets: [] })
    buckets.get(key).tickets.push({ t, origIdx: i })
  }

  // ── 2026-10-10: sort trong mỗi group theo ticketNumber ASC. ──
  // Vé không có số vé → đẩy xuống cuối, giữ thứ tự add (origIdx).
  // Hiển thị theo yêu cầu user:
  //   BUI HONG PHAT (…740) đứng trước KUWABATA (…741), …
  //   nếu không có số thì giữ thứ tự khi tạo.
  for (const b of buckets.values()) {
    b.tickets.sort((a, bb) => {
      const an = (a.t.ticketNumber || '').trim()
      const bn = (bb.t.ticketNumber || '').trim()
      const aEmpty = an === ''
      const bEmpty = bn === ''
      if (aEmpty && bEmpty) return a.origIdx - bb.origIdx
      if (aEmpty) return 1
      if (bEmpty) return -1
      // Số vé thường toàn số/chữ — so sánh dạng chuỗi là đủ (cùng độ dài).
      // Nếu có khác độ dài, so numeric cho ổn định.
      if (an.length === bn.length) return an < bn ? -1 : an > bn ? 1 : 0
      const na = Number(an), nb = Number(bn)
      if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb
      return an < bn ? -1 : an > bn ? 1 : 0
    })
  }

  const groups = []
  const sortedTickets = []
  for (const b of buckets.values()) {
    groups.push({
      key: b.key,
      size: b.tickets.length,
      firstIdxInSorted: sortedTickets.length,
      ticketIds: b.tickets.map(x => x.t.id),
    })
    for (const x of b.tickets) sortedTickets.push(x.t)
  }
  return { sortedTickets, groups }
}

/**
 * ── 2026-10-10 ──────────────────────────────────────────────
 * Hiển thị số hóa đơn ISSUED/ADJUSTED áp cho ticketIds trong group hiện tại.
 *
 * Logic:
 *   - Lấy các invoice ISSUED/ADJUSTED của booking.
 *   - Mỗi invoice.ticketIds (nếu empty = chung cả booking → coi như áp cho MỌI vé).
 *   - Lọc những invoice có giao với ticketIds của group.
 *   - Nếu tất cả vé trong group dùng CHUNG 1 hóa đơn → hiển thị 1 số.
 *   - Nếu nhiều invoice khác nhau áp lên các cặp vé → hiển thị tất cả, phân cách dấu phẩy.
 */
function InvoiceNumbersForGroup({ booking, ticketIds }) {
  const invs = (booking.invoices || []).filter(i => i.status === 'ISSUED' || i.status === 'ADJUSTED')
  if (invs.length === 0) return null
  const idSet = new Set(ticketIds || [])
  const bookingTicketIds = new Set((booking.tickets || []).map(t => t.id))
  const numbersSet = new Set()
  for (const inv of invs) {
    if (!inv.invoiceNumbers) continue
    const invIds = (inv.ticketIds && inv.ticketIds.length > 0)
      ? inv.ticketIds
      : [...bookingTicketIds] // empty = chung cả booking
    const overlap = invIds.some(id => idSet.has(id))
    if (!overlap) continue
    // Tách & trim
    inv.invoiceNumbers.split(',').forEach(n => {
      const t = n.trim()
      if (t) numbersSet.add(t)
    })
  }
  if (numbersSet.size === 0) return null
  const sorted = [...numbersSet].sort((a, b) => {
    const na = Number(a), nb = Number(b)
    if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb
    return a.localeCompare(b)
  })
  return (
    <div className="mt-1 text-[10px] text-gray-600 font-mono tabular-nums leading-tight break-words"
      title="Số hóa đơn đã phát hành">
      🧾 {sorted.join(', ')}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — DESKTOP TABLE
// ═══════════════════════════════════════════════════════════════

function renderBookingRows(b, bIdx, {
  page, nowTick, isSelected, onToggleSelect,
  onOpenBookingFace, onOpenTicketFace, onPresent, onUpload, onInvoice, onNote, onPay, onEdit, onDelete,
}) {
  // 2026-10-12: Tổng QUY về booking.currency — fees khác currency được convert
  // qua exchangeRate (xem sumTicketFees).
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee,
      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
  const totalVnd = toVnd(bookingTotal, b.currency, b.exchangeRate)
  const N = b.tickets?.length || 1
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
    primary?.band === 'warn' ? 'bg-amber-500 text-white'
      : primary?.band === 'future' ? 'bg-blue-600 text-white'
        : ''

  // Sắp xếp tickets theo company (giữ order xuất hiện đầu tiên)
  const { sortedTickets, groups } = groupTicketsByCompany(b.tickets || [])
  // Map: sortedIdx → group info (chỉ render company cell ở dòng đầu của group)
  const groupStartAt = new Map()
  for (const g of groups) groupStartAt.set(g.firstIdxInSorted, g)

  // ── 2026-11-12: Link trực tiếp cấp VÉ (ticket.linkedBookingId). ──
  //   Map ticketId → ownerCode (chủ) nếu vé đó đang link.
  const ticketLinkMap = new Map()
  for (const t of (b.tickets || [])) {
    if (t.linkedBookingId && t.linkedBookingCode) {
      ticketLinkMap.set(t.id, t.linkedBookingCode)
    }
  }
  // "Toàn booking link" = mọi vé đều link, cùng 1 chủ.
  const allLinked = (b.tickets || []).length > 0
    && (b.tickets || []).every(t => ticketLinkMap.has(t.id))
    && new Set([...ticketLinkMap.values()]).size === 1
  const bookingLevelLinkCode = allLinked ? [...ticketLinkMap.values()][0] : null

  return sortedTickets.map((t, tIdx) => {
    // ── 2026-10-09: BỎ tint theo currency ──
    //   Trước đây USD tint sky-50, nhưng mỗi dòng vẫn in rõ đơn vị
    //   (VND/USD) ở cột giá nên tint thừa + nhiễu khi nhiều booking USD
    //   liền nhau. Giờ tất cả cùng nền trắng; chỉ selected mới đổi màu.
    const rowBg = isSelected ? 'bg-amber-50/60' : 'bg-white'
    const firstRow = tIdx === 0
    const lastRow = tIdx === N - 1
    const cardBorder = `${firstRow ? 'border-t-2 border-t-gray-100' : ''} ${lastRow ? 'border-b-4 border-b-gray-100' : ''}`
    // 2026-11-07: HNH fee luôn VND, cộng vào basePrice (giá bán) khi currency = VND.
    //   Nếu booking USD, FE skip (BE sẽ quy đổi chính xác hơn).
    const withHnh = (b.currency === 'VND' || !b.currency)
      ? sumAmounts(t.basePrice, t.hnhFee)
      : t.basePrice
    const withCollection = sumAmounts(withHnh, t.collectionFee)
    // 2026-10-12: fees quy về booking.currency để cộng cùng basePrice/collection.
    const feesTotal = sumTicketFees(t.fees, b.currency, b.exchangeRate)
    const subTotal = sumAmounts(withCollection, feesTotal)
    const sellPrice = sumAmounts(subTotal, t.issuanceFee)
    const hasFace = faceStatus(b, t.id)
    const groupInfo = groupStartAt.get(tIdx)

    return (
      <tr key={t.id}
        className={`${rowBg} ${cardBorder} hover:bg-blue-50/40 transition-colors align-middle`}>
        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            {/* 2026-10-10: Booking đã PAID không được chọn để thu batch. */}
            <input type="checkbox"
              checked={isSelected}
              disabled={b.paymentStatus === 'PAID'}
              onChange={() => onToggleSelect(b.id)}
              title={b.paymentStatus === 'PAID' ? 'Booking đã thanh toán xong — không cần thu' : undefined}
              className="rounded cursor-pointer disabled:cursor-not-allowed disabled:opacity-30" />
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle relative" rowSpan={N}>
            {primary && badgeCls && (
              <span className={`inline-block mb-1 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold ${badgeCls}`}
                title={`Còn ${primary.text} đến chuyến bay`}>
                ⏱ {primary.text}
              </span>
            )}
            <div className="text-xs font-semibold text-gray-900 leading-tight">
              {kindLabel(b.kind)} · <span className="text-gray-600">{b.airlineCode || '—'}</span>
            </div>
            <div className="text-[10px] text-gray-500 tabular-nums mt-0.5">
              {formatDateTimeShort(b.saleDate)}
            </div>
          </td>
        )}

        {/* Công ty — chỉ render ở dòng đầu group, rowspan = group size */}
        {groupInfo && (
          <td className="px-2 py-2 align-middle border-l border-gray-100"
            rowSpan={groupInfo.size}>
            <CompanyLabel short={t.companyShortName} full={t.companyName} />
            <InvoiceNumbersForGroup booking={b} ticketIds={groupInfo.ticketIds || sortedTickets.slice(tIdx, tIdx + groupInfo.size).map(x => x.id)} />
          </td>
        )}

        {/* Khách hàng — 2 dòng: tên + số vé */}
        <td className="px-2 py-2 align-middle">
          <div className="font-medium text-gray-900 truncate leading-tight">
            {t.passengerName || '—'}
          </div>
          {/* ── 2026-10-10: click-to-copy — "{route} - {ticketNumber}{kindSuffix}" ──
              2026-11-12: Nếu vé này được ké hóa đơn ở booking chủ (mixed trong
              booking), hiển thị "(link <chủ>)" ngay sau số vé. Nếu không có số
              vé thì chỉ hiển thị "(link <chủ>)" ở chỗ số vé luôn. */}
          <button type="button"
            onClick={() => {
              if (!t.ticketNumber) return
              const text = buildIdCopyString(b.segments, t.ticketNumber, b.kind)
              navigator.clipboard.writeText(text)
                .then(() => toast.success(`Đã copy: ${text}`))
                .catch(() => toast.error('Không copy được'))
            }}
            disabled={!t.ticketNumber}
            title={t.ticketNumber
              ? `Click để copy: ${buildIdCopyString(b.segments, t.ticketNumber, b.kind)}`
              : 'Vé chưa có số'}
            className="font-mono text-[10px] text-gray-500 truncate leading-tight mt-0.5 block text-left w-full hover:text-blue-700 hover:underline cursor-copy disabled:cursor-default disabled:hover:no-underline">
            {t.ticketNumber || ''}
            {hasFace && t.ticketNumber && <span className="ml-1 text-emerald-600">📎</span>}
            {!bookingLevelLinkCode && ticketLinkMap.has(t.id) && (
              <span className="ml-1 text-amber-400 italic no-underline"
                title={`Hóa đơn của vé này đã chuyển sang booking ${ticketLinkMap.get(t.id)}`}>
                {t.ticketNumber ? '(' : ''}link {ticketLinkMap.get(t.id)}{t.ticketNumber ? ')' : ''}
              </span>
            )}
          </button>
        </td>

        {/* Booking — 2026-10-10 click copy "{route} - {bookingCode}{kindSuffix}" */}
        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            <button type="button"
              onClick={() => {
                if (!b.bookingCode) return
                const text = buildIdCopyString(b.segments, b.bookingCode, b.kind)
                navigator.clipboard.writeText(text)
                  .then(() => toast.success(`Đã copy: ${text}`))
                  .catch(() => toast.error('Không copy được'))
              }}
              disabled={!b.bookingCode}
              title={b.bookingCode
                ? `Click để copy: ${buildIdCopyString(b.segments, b.bookingCode, b.kind)}`
                : 'Chưa có mã'}
              className="block w-full text-left font-mono text-[11px] font-bold text-gray-900 hover:text-blue-700 hover:underline truncate cursor-copy disabled:cursor-default">
              {b.bookingCode || '—'}
              {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
            </button>
            {/* ── 2026-10-16 + 2026-11-12 Hiển thị trạng thái invoice group ──
                · Booking chủ   → luôn hiện (dù chỉ 1 member)
                · Booking phụ   → chỉ hiện ở cột booking khi MỌI vé đều đã link
                                   sang cùng 1 chủ. Trường hợp mixed → hiện per-ticket
                                   ở cột khách hàng (xem bên dưới). */}
            {b.isInvoiceGroupOwner && (
              <div className="mt-0.5 font-mono text-[10px] italic text-indigo-400" title="Booking chủ — các booking khác link vào đây">
                Booking chủ
              </div>
            )}
            {!b.isInvoiceGroupOwner && bookingLevelLinkCode && (
              <div className="mt-0.5 font-mono text-[10px] italic text-amber-400" title={`Link ${bookingLevelLinkCode} — mọi hóa đơn đã chuyển sang booking chủ`}>
                Link {bookingLevelLinkCode}
              </div>
            )}
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            {(b.segments || []).length === 0 ? <span className="text-gray-400">—</span> : (() => {
              const concat = routeConcat(b.segments)
              const copyRoute = () => {
                if (!concat) return
                navigator.clipboard.writeText(concat)
                  .then(() => toast.success(`Đã copy: ${concat}`))
                  .catch(() => toast.error('Không copy được'))
              }
              return (
                <button type="button" onClick={copyRoute}
                  title={`Click để copy: ${concat}`}
                  className="block w-full text-left cursor-copy hover:bg-blue-50 rounded px-1 -mx-1">
                  {(b.segments || []).map((s, i) => (
                    <div key={i} className={`${i > 0 ? 'mt-1.5 pt-1.5 border-t border-dashed border-gray-200' : ''}`}>
                      <div className="text-xs font-bold text-gray-900 leading-tight">
                        {s.fromCode} <span className="text-gray-400">→</span> {s.toCode}
                      </div>
                      <div className="text-[11px] tabular-nums text-gray-500 leading-tight">
                        {formatDepart(s.departLocalMs, s.fromCode) || '—'}
                      </div>
                    </div>
                  ))}
                </button>
              )
            })()}
          </td>
        )}

        <TdMoneyPair
          value1={t.basePrice}
          value2={t.collectionFee}
          currency={b.currency}
          exchangeRate={b.exchangeRate}
          bold1
          // 2026-10-10: Vé đầu tiên trong booking → click phí thu hộ sẽ copy
          // TỔNG phí thu hộ của mọi vé trong booking (user tiện gộp vào 1 bút toán).
          value2OverrideSum={
            // Vé đầu tiên hiển thị trong booking (sau sort theo số vé) → gộp tổng
            // phí thu hộ của mọi vé cùng booking vào ô này.
            tIdx === 0
              ? sumAmounts(...(b.tickets || []).map(x => x.collectionFee || 0))
              : null
          }
        />
        <TdInvoiceAndFees
          withCollection={withCollection} fees={t.fees}
          currency={b.currency} exchangeRate={b.exchangeRate}
          segments={b.segments}
          ticketNumber={t.ticketNumber}
          bookingCode={b.bookingCode}
        />
        <TdMoney value={subTotal} currency={b.currency} exchangeRate={b.exchangeRate} bold />
        <TdMoney value={t.issuanceFee} currency={b.currency} exchangeRate={b.exchangeRate} muted />
        <TdMoney value={sellPrice} currency={b.currency} exchangeRate={b.exchangeRate} bold />

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle border-l border-r border-gray-200"
            rowSpan={N}>
            <div className="font-mono tabular-nums text-sm font-bold text-blue-700">
              {formatMoney(bookingTotal, b.currency)}
            </div>
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle" rowSpan={N}>
            {b.currency === 'VND' ? (
              <span className="text-gray-400 text-[11px]">—</span>
            ) : (
              <>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900">
                  {formatMoney(totalVnd, 'VND')}
                </div>
                <div className="text-[10px] text-gray-500 tabular-nums">
                  1 USD = {b.exchangeRate ? formatMoney(b.exchangeRate, 'VND', { withUnit: false }) : '—'}
                </div>
              </>
            )}
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            <PaymentCell booking={b} bookingTotal={bookingTotal} onPay={onPay} />
          </td>
        )}

        {/* Thao tác — 2026-09-19: rút gọn còn 5 nút. Note ở mỗi ticket, các nút khác ở firstRow. */}
        {/* 2026-09-20: canh phải theo yêu cầu — icons dồn về bên phải */}
        <td className="px-2 py-2 align-middle">
          <div className="flex flex-wrap items-center justify-end gap-1">
            {t.note && (
              <button type="button"
                onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                title={'Ghi chú: ' + (t.note.length > 60 ? t.note.slice(0, 60) + '…' : t.note)}
                className="w-7 h-7 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-700 inline-flex items-center justify-center">
                📝
              </button>
            )}
            {firstRow && (
              <>
                <button type="button" onClick={() => onPresent(b)}
                  title="Xuất trình (Thông tin booking / Mặt vé / Hóa đơn)"
                  className="w-7 h-7 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-700 flex items-center justify-center">
                  {/* 👁 — xem/trình bày ra ngoài, phân biệt rõ với upload */}
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                </button>
                <button type="button" onClick={() => onUpload(b)}
                  title="Upload (Thông tin booking / Mặt vé / Hóa đơn)"
                  className="w-7 h-7 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  {/* ⬆ cloud-upload — khác hẳn con mắt ở trên */}
                  <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17 8 12 3 7 8" />
                    <line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                </button>
                <button type="button" onClick={onEdit}
                  title="Sửa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-gray-200 flex items-center justify-center">✎</button>
                <button type="button" onClick={onDelete}
                  title="Xóa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-rose-100 hover:text-rose-700 flex items-center justify-center">🗑</button>
              </>
            )}
          </div>
        </td>
      </tr>
    )
  })
}

// ── Sub-components ─────────────────────────────────────

function CompanyLabel({ short, full }) {
  if (!full && !short) {
    return <span className="text-[10px] text-gray-400 italic">Khách lẻ</span>
  }
  const label = short || autoShort(full)
  return (
    <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800"
      title={full}>
      {label}
    </span>
  )
}

function autoShort(name) {
  if (!name) return '—'
  const parts = name.split(/\s+/).filter(x => x && !/^(và|-|của)$/i.test(x))
  if (parts.length === 1) return parts[0].slice(0, 6).toUpperCase()
  return parts.slice(0, 3).map(p => p[0]?.toUpperCase() || '').join('')
}

function PaymentCell({ booking, bookingTotal, onPay }) {
  // 2026-11-11: Booking tách ≥ 2 hoá đơn → mỗi hoá đơn 1 nút thanh toán riêng.
  if (bookingTotal > 0.5 && (booking.invoices || []).length > 1) {
    return <InvoicePayButtons booking={booking} onPay={onPay} />
  }
  const stRaw = booking.paymentStatus || 'UNPAID'
  const paid = parseAmount(booking.paidAmount) || 0
  const remain = Math.max(0, bookingTotal - paid)

  // 2026-10-13:
  //   - total ≈ 0 → PAID (booking miễn phí/không có giá).
  //   - đã thu đủ (remain ≤ 0) & total > 0 → PAID (safeguard nếu BE
  //     trả PARTIAL do stale cache / nhiều invoice).
  //   - còn lại → bám theo stRaw của BE.
  let st
  if (bookingTotal <= 0.5) st = 'PAID'
  else if (remain <= 0.5) st = 'PAID'
  else st = stRaw

  const paidStr = formatMoney(paid, booking.currency, { withUnit: false })
  const badge =
    st === 'PAID' ? { cls: 'bg-green-100 text-green-700', label: 'Đã thanh toán' }
      : st === 'PARTIAL' ? { cls: 'bg-amber-100 text-amber-700', label: `Đã thu: ${paidStr}` }
        : { cls: 'bg-rose-100 text-rose-700', label: 'Chưa thanh toán' }

  return (
    <button type="button" onClick={() => onPay(booking)}
      className={`px-2 py-1 rounded-md ${badge.cls} hover:brightness-95 transition text-left w-full`}>
      <div className="text-[10px] font-bold">{badge.label}</div>
      {st === 'PARTIAL' && (
        <div className="text-[10px] font-mono tabular-nums mt-0.5 opacity-80">
          còn {formatMoney(remain, booking.currency, { withUnit: false })}
        </div>
      )}
    </button>
  )
}

/**
 * ── 2026-11-11: Tên hiển thị của 1 hoá đơn trên nút thanh toán ──
 *   Ưu tiên tên viết tắt công ty của các vé mà hoá đơn áp cho (hoá đơn tách
 *   theo công ty). Vé không có công ty → "Khách lẻ". Hoá đơn chung (ticketIds
 *   rỗng) → "Chung". Nhiều hoá đơn trùng nhãn → thêm số hoá đơn / tên khách
 *   để phân biệt.
 */
function invoicePayLabels(booking) {
  const invs = booking.invoices || []
  const tickets = booking.tickets || []
  const byId = new Map(tickets.map(t => [t.id, t]))
  const base = invs.map(inv => {
    const ids = inv.ticketIds || []
    if (ids.length === 0) return { label: 'Chung', full: 'Hoá đơn chung cả booking', paxs: tickets }
    const paxs = ids.map(id => byId.get(id)).filter(Boolean)
    const names = []
    const fulls = []
    for (const t of paxs) {
      const label = (t.companyName || t.companyShortName)
        ? (t.companyShortName || autoShort(t.companyName))
        : 'Khách lẻ'
      if (!names.includes(label)) {
        names.push(label)
        fulls.push(t.companyName || label)
      }
    }
    return {
      label: names.join(' + ') || `${ids.length} vé`,
      full: fulls.join(' + '),
      paxs,
    }
  })
  const count = new Map()
  for (const x of base) count.set(x.label, (count.get(x.label) || 0) + 1)
  return base.map((x, i) => {
    const inv = invs[i]
    let label = x.label
    if (count.get(x.label) > 1) {
      const num = (inv.invoiceNumbers || '').split(',')[0].trim()
      if (num) label += ` #${num}`
      else if (x.paxs.length === 1) {
        // Tên gọi (từ cuối) của hành khách: "NGUYỄN VĂN A" → "A".
        const last = (x.paxs[0].passengerName || '').trim().split(/\s+/).pop()
        label += last ? ` · ${last}` : ` (${i + 1})`
      } else label += ` (${i + 1})`
    }
    const who = x.paxs.map(t => t.passengerName).filter(Boolean).join(', ')
    return { label, title: [x.full, who].filter(Boolean).join(' — ') }
  })
}

/**
 * ── 2026-11-11: Mỗi hoá đơn tách = 1 nút thanh toán ──
 *   Booking tách N hoá đơn → N nút xếp dọc, mỗi nút có nhãn công ty + trạng
 *   thái riêng (Chưa thanh toán / Đã thu một phần / Đã thanh toán). Bấm nút →
 *   onPay(booking, invoice) mở PaymentModal của đúng hoá đơn đó.
 */
function InvoicePayButtons({ booking, onPay }) {
  const invs = booking.invoices || []
  const labels = invoicePayLabels(booking)
  return (
    <div className="flex flex-col gap-1 w-full">
      {invs.map((inv, i) => {
        const total = parseAmount(inv.grandTotal) || 0
        const paid = parseAmount(inv.paidAmount) || 0
        const remain = Math.max(0, total - paid)
        const st = (total <= 0.5 || remain <= 0.5) ? 'PAID' : (inv.paymentStatus || 'UNPAID')
        const cls =
          st === 'PAID' ? 'bg-green-100 text-green-700'
            : st === 'PARTIAL' ? 'bg-amber-100 text-amber-700'
              : 'bg-rose-100 text-rose-700'
        const money = (v) => formatMoney(v, booking.currency, { withUnit: false })
        const line =
          st === 'PAID' ? 'Đã thanh toán'
            : st === 'PARTIAL' ? `Còn ${money(remain)}`
              : `Chưa thu ${money(total)}`
        return (
          <button key={inv.id} type="button"
            onClick={() => onPay(booking, inv)}
            title={`${labels[i].title}\nTổng hoá đơn: ${money(total)} · Đã thu: ${money(paid)}`}
            className={`px-2 py-1 rounded-md ${cls} hover:brightness-95 transition text-left w-full`}>
            <div className="text-[10px] font-bold truncate">{labels[i].label}</div>
            <div className="text-[10px] font-mono tabular-nums opacity-80 whitespace-nowrap">{line}</div>
          </button>
        )
      })}
    </div>
  )
}

/**
 * ── 2026-09-20: click-to-copy ─────────────────────────────────
 * Cell tiền là 1 button. Click → copy vào clipboard số nguyên (không format,
 * không unit). Nếu currency=USD → nhân với exchangeRate của booking để ra
 * VND rồi copy (đơn vị: đồng, làm tròn).
 *
 * Trường hợp cần chỉ copy raw (không đổi sang VND), truyền {@code rawCopy}.
 */
async function copyMoneyAsClipboard(numericValue, currency, exchangeRate, rawCopy) {
  if (!Number.isFinite(numericValue)) return
  let vnd = numericValue
  if (!rawCopy && currency === 'USD') {
    const rate = parseAmount(exchangeRate)
    if (Number.isFinite(rate) && rate > 0) {
      vnd = numericValue * rate
    }
  }
  const intVnd = Math.round(vnd)
  const text = String(intVnd)
  try {
    await navigator.clipboard.writeText(text)
    // Hiển thị theo format có dấu chấm cho user dễ đọc trong toast
    toast.success(`Đã copy: ${intVnd.toLocaleString('vi-VN')}`)
  } catch (e) {
    toast.error('Không copy được vào clipboard')
  }
}

function TdMoney({ value, currency, exchangeRate, bold, muted }) {
  const n = typeof value === 'number' ? value : parseAmount(value)
  const cls =
    !Number.isFinite(n) ? 'text-gray-300'
      : muted ? 'text-gray-500'
        : bold ? 'text-gray-900 font-semibold'
          : 'text-gray-700'
  const isClickable = Number.isFinite(n) && n !== 0
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={isClickable ? () => copyMoneyAsClipboard(n, currency, exchangeRate) : undefined}
        disabled={!isClickable}
        title={isClickable ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`${cls} text-left ${isClickable ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n, currency, { withUnit: false })}
      </button>
    </td>
  )
}

function TdMoneyPair({ value1, value2, currency, exchangeRate, bold1, value2OverrideSum }) {
  const n1 = typeof value1 === 'number' ? value1 : parseAmount(value1)
  const n2 = typeof value2 === 'number' ? value2 : parseAmount(value2)
  const cls1 =
    !Number.isFinite(n1) ? 'text-gray-300'
      : bold1 ? 'text-gray-900 font-semibold'
        : 'text-gray-700'
  const clickable1 = Number.isFinite(n1) && n1 !== 0
  const clickable2 = Number.isFinite(n2) && n2 !== 0
  // 2026-10-10: Nếu có override (vé đầu tiên) → click vào collection fee copy tổng
  // của cả booking thay vì chỉ số của riêng vé.
  const hasSumOverride = value2OverrideSum != null && Number.isFinite(value2OverrideSum) && value2OverrideSum !== 0
  const copyValueForSecond = hasSumOverride ? value2OverrideSum : n2
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={clickable1 ? () => copyMoneyAsClipboard(n1, currency, exchangeRate) : undefined}
        disabled={!clickable1}
        title={clickable1 ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`${cls1} text-left block ${clickable1 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n1, currency, { withUnit: false })}
      </button>
      <button type="button"
        onClick={clickable2 ? () => copyMoneyAsClipboard(copyValueForSecond, currency, exchangeRate) : undefined}
        disabled={!clickable2}
        title={clickable2
          ? (hasSumOverride
            ? `Click để copy TỔNG phí thu hộ cả booking: ${formatMoney(value2OverrideSum, currency, { withUnit: false })}`
            : (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy'))
          : undefined}
        className={`text-[10px] text-left block ${hasSumOverride ? 'text-blue-600 font-semibold' : 'text-gray-400'} ${clickable2 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {Number.isFinite(n2) && n2 !== 0 ? formatMoney(n2, currency, { withUnit: false }) : '—'}
      </button>
    </td>
  )
}


/**
 * Cột "Giá trên vé / phí" — hiển thị withCollection ở trên, list phí phát sinh
 * bên dưới. Mỗi phí = label bên trái + số tiền bên phải (canh phải).
 * Click số tiền → copy (quy đổi VND nếu USD).
 *
 * ── 2026-09-20 rework ────────────────────────────────
 * Trước dùng TdMoneyPair value2={feesTotal} → chỉ hiển thị TỔNG phí ở dòng
 * phụ nhỏ xíu, user không biết vé đã có phí gì. Nay list chi tiết mỗi loại
 * phí trên 1 dòng, canh phải giá tiền để cột nhìn gọn.
 */
/**
 * "Phí trợ giúp đặc biệt" → "Phí Trợ Giúp Đặc Biệt".
 * Viết hoa chữ cái đầu MỖI từ. Unicode-aware (nhận đúng chữ tiếng Việt có
 * dấu như "đ", "ơ", "ư", các nguyên âm có dấu…).
 *
 * Không dùng String.prototype.toUpperCase() cho toàn bộ vì user chỉ muốn hoa
 * chữ đầu, giữ các chữ sau nguyên vẹn.
 */
function titleCaseVi(str) {
  if (!str) return ''
  return String(str)
    .split(/(\s+)/)                    // tách nhưng giữ khoảng trắng
    .map(part => {
      if (/^\s+$/.test(part)) return part
      // Lấy ký tự đầu (Unicode-aware qua Array.from để không tách bậy chữ có dấu)
      const chars = Array.from(part)
      if (chars.length === 0) return part
      chars[0] = chars[0].toLocaleUpperCase('vi-VN')
      return chars.join('')
    })
    .join('')
}

function TdInvoiceAndFees({ withCollection, fees, currency, exchangeRate, segments, ticketNumber, bookingCode }) {
  const n1 = typeof withCollection === 'number' ? withCollection : parseAmount(withCollection)
  const clickable1 = Number.isFinite(n1) && n1 !== 0
  const feesList = Array.isArray(fees) ? fees : []
  return (
    <td className="px-2 py-2 text-left font-mono tabular-nums align-middle">
      <button type="button"
        onClick={clickable1 ? () => copyMoneyAsClipboard(n1, currency, exchangeRate) : undefined}
        disabled={!clickable1}
        title={clickable1 ? (currency === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy') : undefined}
        className={`text-gray-900 font-semibold text-left block ${clickable1 ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
        {formatMoney(n1, currency, { withUnit: false })}
      </button>
      {feesList.length === 0 ? (
        <div className="text-[10px] text-gray-400">—</div>
      ) : (
        <div className="mt-0.5 space-y-0.5">
          {feesList.map((f, i) => {
            const amt = parseAmount(f.amount)
            const canCopy = Number.isFinite(amt) && amt !== 0
            const label = f.feeTypeLabel || f.feeType
            const labelTitleCase = titleCaseVi(label)
            // 2026-10-12: fee có currency riêng — display + copy đúng theo nó.
            const feeCur = (f.currency || currency || 'VND').toUpperCase()
            // ── 2026-11-07 (rev): Ưu tiên số vé RIÊNG của dịch vụ nếu có,
            //   nếu không thì dùng số vé chính của ticket (fallback cũ).
            //   VD vé chính 11111111, phí hành lý có số vé riêng 11111112 →
            //   copy: "SGNHAN - 11111112 (Phí Hành Lý)". Không có số riêng →
            //   copy: "SGNHAN - 11111111 (Phí Hành Lý)".
            const feeTicketForCopy = (f.ticketNumber || '').trim() || ticketNumber
            const copyText = buildFeeCopyString(segments, feeTicketForCopy, bookingCode, labelTitleCase)
            const copyLabel = () => {
              navigator.clipboard.writeText(copyText)
                .then(() => toast.success(`Đã copy: ${copyText}`))
                .catch(() => toast.error('Không copy được'))
            }
            // 2026-11-07 (rev): Mỗi phí render 2 DÒNG (dòng 1: tên phí, dòng
            // 2: số tiền) để không bị chồng chéo khi tên phí dài. KHÔNG hiển
            // thị số vé riêng (ticketNumber) của phí trên UI — số đó chỉ
            // dùng ngầm trong copy (đã handle ở buildFeeCopyString phía trên).
            return (
              <div key={i} className="text-[10px] leading-tight">
                <button type="button"
                  onClick={copyLabel}
                  title={`Click để copy: "${copyText}"`}
                  className="text-gray-600 truncate text-left block w-full hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy">
                  {label}
                </button>
                <button type="button"
                  onClick={canCopy ? () => copyMoneyAsClipboard(amt, feeCur, exchangeRate) : undefined}
                  disabled={!canCopy}
                  title={canCopy
                    ? (feeCur === 'USD' ? 'Click để copy (quy đổi VND)' : 'Click để copy')
                    : undefined}
                  className={`font-mono tabular-nums text-left block w-full ${feeCur !== currency ? 'text-amber-700 font-semibold' : 'text-gray-700'
                    } ${canCopy ? 'hover:bg-blue-50 hover:text-blue-700 rounded px-1 -mx-1 cursor-copy' : ''}`}>
                  {formatMoney(amt, feeCur, { withUnit: false })}
                  {feeCur !== currency && (
                    <span className="ml-0.5 text-[9px] opacity-70">{feeCur}</span>
                  )}
                </button>
              </div>
            )
          })}
        </div>
      )}
    </td>
  )
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — MOBILE CARD
// ═══════════════════════════════════════════════════════════════

/**
 * 2026-11-12: 1 dòng hoá đơn trong card vé (mobile).
 *   - "Hoá đơn N" + tag Nháp/PH + tên các khách trong hoá đơn.
 *   - Nếu hoá đơn gộp vé của booking khác (link group) → chỉ note
 *     "Hoá đơn gộp với booking <code>", KHÔNG hiện số tiền chưa thu.
 *   - Bấm vào dòng → mở modal thanh toán hoá đơn đó.
 */
function MobileInvoiceLine({ booking, inv, index, onPay }) {
  const byId = new Map((booking.tickets || []).map(t => [t.id, t]))
  const previews = (inv.ticketPreviews && inv.ticketPreviews.length) ? inv.ticketPreviews : null

  // Booking khác mà hoá đơn này gộp vào (link group).
  const otherBks = new Set()
  if (previews) previews.forEach(p => {
    if (p.bookingId && p.bookingId !== booking.id && p.bookingCode) otherBks.add(p.bookingCode)
  })
  if (inv.sourceBookingId && inv.sourceBookingId !== booking.id && inv.sourceBookingCode) {
    otherBks.add(inv.sourceBookingCode)
  }
  const isGroup = otherBks.size > 0

  // Tên khách của booking HIỆN TẠI trong hoá đơn.
  let names
  if (previews) {
    names = previews.filter(p => !p.bookingId || p.bookingId === booking.id)
      .map(p => p.passengerName).filter(Boolean)
  } else if ((inv.ticketIds || []).length > 0) {
    names = inv.ticketIds.map(id => byId.get(id)?.passengerName).filter(Boolean)
  } else {
    names = (booking.tickets || []).map(t => t.passengerName).filter(Boolean) // chung cả booking
  }

  const issued = inv.status === 'ISSUED' || inv.status === 'ADJUSTED'
  const tagCls = issued ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
  const tagTxt = issued ? (inv.invoiceNumbers ? `PH #${inv.invoiceNumbers}` : 'Đã PH') : 'Nháp'

  return (
    <button type="button" onClick={() => onPay(booking, inv)}
      className="w-full text-left text-[11px] flex items-start gap-1.5 hover:bg-black/5 rounded px-1 -mx-1 py-0.5">
      <span className="font-bold text-gray-700 shrink-0">Hoá đơn {index + 1}</span>
      <span className={`shrink-0 text-[9px] font-bold px-1.5 py-0.5 rounded ${tagCls}`}>{tagTxt}</span>
      <span className="text-gray-600 break-words min-w-0">
        {isGroup
          ? <>— Hoá đơn gộp với booking {[...otherBks].join(', ')}</>
          : <>— {names.join(', ') || '—'}</>}
      </span>
    </button>
  )
}

function MobileBookingCard({ booking: b, nowTick, isSelected, onToggleSelect,
  onOpenBookingFace, onOpenTicketFace,
  onPresent, onUpload,
  onInvoice, onNote, onPay, onEdit, onDelete }) {
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee,
      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee)))
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
    primary?.band === 'warn' ? 'bg-amber-500 text-white'
      : primary?.band === 'future' ? 'bg-blue-600 text-white'
        : 'bg-gray-200 text-gray-600'
  // 2026-10-13: Same safeguard như desktop PaymentCell.
  const paidNum = parseAmount(b.paidAmount) || 0
  const remainBk = Math.max(0, bookingTotal - paidNum)
  const stRaw = b.paymentStatus || 'UNPAID'
  const st = (bookingTotal <= 0.5 || remainBk <= 0.5) ? 'PAID' : stRaw
  const stCls =
    st === 'PAID' ? 'bg-green-100 text-green-700'
      : st === 'PARTIAL' ? 'bg-amber-100 text-amber-700'
        : 'bg-rose-100 text-rose-700'
  const stLabel =
    st === 'PAID' ? 'Đã thanh toán'
      : st === 'PARTIAL' ? 'Thanh toán 1 phần'
        : 'Chưa thanh toán'

  // ── 2026-11-12: Màu nền card theo trạng thái hoá đơn + thanh toán ──
  //   PH + đã TT → xanh lá; PH + chưa TT → xanh dương; chỉ có nháp → cam;
  //   chưa có hoá đơn → trắng. isSelected (batch) đè bằng vàng.
  const invList = b.invoices || []
  const hasIssued = invList.some(i => i.status === 'ISSUED' || i.status === 'ADJUSTED')
  const hasDraft = invList.some(i => i.status === 'DRAFT')
  const toneCls =
    isSelected ? 'bg-amber-100 border-amber-300'
      : hasIssued && st === 'PAID' ? 'bg-green-50 border-green-200'
        : hasIssued ? 'bg-blue-50 border-blue-200'
          : hasDraft ? 'bg-amber-50 border-amber-200'
            : 'bg-white border-gray-200'

  // Mobile cũng group theo company cho nhất quán
  const { sortedTickets } = groupTicketsByCompany(b.tickets || [])

  return (
    <div className={`rounded-xl border shadow-sm p-3 relative ${toneCls}`}>
      {/* Header: countdown + loại·hãng + mã booking NẰM CÙNG DÒNG */}
      <div className="flex items-start gap-2 mb-2">
        <input type="checkbox" checked={isSelected}
          onChange={() => onToggleSelect(b.id)}
          className="mt-1.5 rounded cursor-pointer shrink-0" />
        <div className="flex-1 min-w-0 flex items-center gap-1.5 flex-wrap">
          {primary && (
            <span className={`inline-block px-1.5 py-0.5 rounded-md font-mono text-[10px] font-bold ${badgeCls}`}>
              ⏱ {primary.text}
            </span>
          )}
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-bold">
            {kindLabel(b.kind)} · {b.airlineCode || '?'}
          </span>
          <button type="button"
            onClick={() => {
              if (!b.bookingCode) return
              const text = buildIdCopyString(b.segments, b.bookingCode, b.kind)
              navigator.clipboard.writeText(text)
                .then(() => toast.success(`Đã copy: ${text}`))
                .catch(() => toast.error('Không copy được'))
            }}
            disabled={!b.bookingCode}
            title={b.bookingCode
              ? `Click để copy: ${buildIdCopyString(b.segments, b.bookingCode, b.kind)}`
              : 'Chưa có mã'}
            className="font-mono text-xs font-bold text-gray-900 hover:text-blue-700 hover:underline cursor-copy disabled:cursor-default">
            {b.bookingCode || '—'}
            {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
          </button>
        </div>
        <button onClick={onEdit} className="text-gray-500 hover:text-gray-800 w-7 h-7 rounded-md hover:bg-gray-100 shrink-0">✎</button>
        <button onClick={onDelete} className="text-gray-500 hover:text-rose-600 w-7 h-7 rounded-md hover:bg-rose-50 shrink-0">🗑</button>
      </div>

      {/* Thời gian xuất vé (badge) */}
      <div className="flex items-center gap-1.5 mb-2">
        <span className="text-[10px] text-gray-400 uppercase tracking-wide">Thời gian xuất vé</span>
        <span className="text-[10px] font-mono tabular-nums px-1.5 py-0.5 rounded bg-gray-100 text-gray-600">
          {formatDateTimeShort(b.saleDate)}
        </span>
      </div>

      {/* Hành trình — highlight chặng đang được đếm ngược */}
      <div className="text-[11px] mb-2 space-y-0.5">
        {(b.segments || []).map((s, i) => {
          const isActive = primary && s.departLocalMs === primary.departMs
          return (
            <div key={i} className={`px-1.5 py-0.5 rounded ${isActive ? 'bg-amber-200/70 ring-1 ring-amber-300 font-semibold' : ''}`}>
              {/* 2026-11-16: Khi highlight (nền vàng), ép chữ màu tối bằng arbitrary
                  value để dark-theme KHÔNG override thành chữ sáng (trùng nền). */}
              <span className={`font-bold ${isActive ? 'text-[#1f2937]' : 'text-gray-800'}`}>{s.fromCode} → {s.toCode}</span>
              <span className={`mx-1 ${isActive ? 'text-[#6b7280]' : 'text-gray-400'}`}>·</span>
              <span className={`tabular-nums ${isActive ? 'text-[#374151]' : 'text-gray-600'}`}>{formatDepartFull(s.departLocalMs, s.fromCode)}</span>
            </div>
          )
        })}
      </div>

      <div className="divide-y divide-gray-100 -mx-3">
        {sortedTickets.map(t => {
          const hasFace = faceStatus(b, t.id)
          return (
            <div key={t.id} className="px-3 py-2">
              <div className="flex items-start gap-2">
                <div className="flex-1 min-w-0">
                  {/* Tên khách dài → WRAP, không truncate */}
                  <div className="flex items-start gap-1.5 mb-0.5 flex-wrap">
                    <CompanyLabel short={t.companyShortName} full={t.companyName} />
                    <span className="text-sm font-semibold text-gray-900 break-words">{t.passengerName || '—'}</span>
                  </div>
                  {/* Vé không có số → emdash, KHÔNG hiện "chưa có số vé" */}
                  <div className="font-mono text-[10px] text-gray-500 break-all"
                    title={hasFace ? 'Vé này đã có mặt vé' : 'Vé chưa có mặt vé'}>
                    {t.ticketNumber || '—'}
                    {hasFace && <span className="ml-1 text-emerald-600">📎</span>}
                  </div>
                </div>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900 shrink-0">
                  {formatMoney(
                    sumAmounts(t.basePrice, t.collectionFee,
                      sumTicketFees(t.fees, b.currency, b.exchangeRate), t.issuanceFee),
                    b.currency
                  )}
                </div>
              </div>
              {t.note && (
                <button type="button"
                  onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                  className="mt-1 h-7 w-7 rounded-md text-[11px] font-semibold bg-amber-100 text-amber-700 flex items-center justify-center">
                  📝
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* ── 2026-11-12: Danh sách hoá đơn — "Hoá đơn 1/2 + khách" hoặc note gộp ── */}
      {invList.length > 0 && (
        <div className="mt-2 pt-2 border-t border-gray-100 space-y-1">
          {invList.map((inv, i) => (
            <MobileInvoiceLine key={inv.id} booking={b} inv={inv} index={i} onPay={onPay} />
          ))}
        </div>
      )}

      <div className="mt-2 pt-2 border-t border-gray-100 flex items-center justify-between gap-2 flex-wrap">
        <button type="button" onClick={() => onPay(b)}
          className={`px-2 py-1 rounded-md ${stCls} text-[11px] font-bold`}>
          {stLabel}
        </button>
        <button type="button" onClick={() => onPresent(b)}
          className="text-[11px] px-2 py-1 rounded-md bg-blue-100 text-blue-700 font-semibold inline-flex items-center gap-1">
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
          </svg>
          Xuất trình
        </button>
        <button type="button" onClick={() => onUpload(b)}
          className="text-[11px] px-2 py-1 rounded-md bg-emerald-100 text-emerald-700 font-semibold inline-flex items-center gap-1">
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Upload
        </button>
        <div className="flex-1" />
        <span className="font-mono tabular-nums font-bold text-blue-700 text-sm">
          {formatMoney(bookingTotal, b.currency)}
        </span>
      </div>
    </div>
  )
}

/**
 * 2026-10-28 (v2): Status bar cho infinite-scroll (bỏ nút "Tải thêm").
 *   - Hiển thị "Đang hiển thị X/Y booking".
 *   - Khi `loading=true` (đang fetch trang kế) → thêm "⏳ Đang tải thêm…".
 *   - Khi `hasMore=false` → "Đã hiển thị đủ".
 *   - Trigger fetch nằm ở scroll handler (80% chiều cao) của container.
 */
function LoadMoreBar({ loaded, total, hasMore, loading }) {
  if (!loaded) return null
  return (
    <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-t border-gray-100 text-xs">
      <span className="text-gray-500">
        Đang hiển thị <b>{loaded}</b>{total ? <>/<b>{total}</b></> : null} booking
      </span>
      {loading ? (
        <span className="text-blue-600 font-semibold">⏳ Đang tải thêm…</span>
      ) : hasMore ? (
        <span className="text-gray-400 italic">Cuộn xuống để tải thêm</span>
      ) : (
        <span className="text-gray-400 italic">Đã hiển thị đủ</span>
      )}
    </div>
  )
}

// ── Utility ─────────────────────────────────────────────

function faceStatus(b, ticketId) {
  if (b.sharedTicketFace) return !!b.bookingFace
  const t = (b.tickets || []).find(x => x.id === ticketId)
  return !!t?.ticketFace
}

function kindLabel(k) {
  return { NEW: 'Mua mới', EXCHANGE: 'Đổi', REFUND: 'Hoàn', SERVICE: 'Dịch vụ' }[k] || k
}

/**
 * Tính tổng số tiền của list TicketFee của 1 vé, QUY về {@code targetCurrency}.
 *
 * ── 2026-10-12 multi-currency ────────────────────────────────
 * Mỗi fee có thể có currency riêng (VND/USD/null=inherit booking). Khi gộp
 * về booking.currency:
 *   - fee cùng currency → cộng thẳng
 *   - fee VND vào booking USD → chia cho exchangeRate
 *   - fee USD vào booking VND → nhân với exchangeRate
 *   - rate thiếu → bỏ qua (coi như 0) để không ra NaN
 */
function sumTicketFees(fees, targetCurrency = 'VND', exchangeRate = null) {
  if (!fees || fees.length === 0) return 0
  const rate = parseAmount(exchangeRate)
  let total = 0
  for (const f of fees) {
    const amt = parseAmount(f.amount)
    if (!Number.isFinite(amt)) continue
    const fc = (f.currency || targetCurrency || 'VND').toUpperCase()
    if (fc === targetCurrency) {
      total += amt
    } else if (targetCurrency === 'USD' && fc === 'VND') {
      if (Number.isFinite(rate) && rate > 0) total += amt / rate
    } else if (targetCurrency === 'VND' && fc === 'USD') {
      if (Number.isFinite(rate) && rate > 0) total += amt * rate
    }
  }
  return total
}

/**
 * Sum fees theo RIÊNG từng currency, trả { VND, USD }. Phục vụ TotalsCard
 * để bucket chính xác (fee VND trong booking USD vẫn vào VND).
 */
function sumFeesByCurrency(fees, fallbackCurrency = 'VND') {
  const out = { VND: 0, USD: 0 }
  if (!fees) return out
  for (const f of fees) {
    const amt = parseAmount(f.amount)
    if (!Number.isFinite(amt)) continue
    const fc = (f.currency || fallbackCurrency || 'VND').toUpperCase()
    if (fc === 'VND' || fc === 'USD') out[fc] += amt
  }
  return out
}

function formatDateTimeShort(ms) {
  if (!ms) return '—'
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(new Date(ms))
    const p = (t) => parts.find(x => x.type === t)?.value || ''
    return `${p('hour')}:${p('minute')} ${p('day')}/${p('month')}/${p('year')}`
  } catch { return '' }
}

/**
 * Ghép các mã sân bay trong segments thành 1 chuỗi liền, bỏ trùng lặp liền kề.
 * Dùng cho click-to-copy ô Hành trình.
 * VD: [{HAN,NRT}, {NRT,HAN}] → "HANNRTHAN"
 *     [{HAN,NRT}, {HKG,HAN}] → "HANNRTHKGHAN"  (route gãy — vẫn concat đủ mã)
 */
function routeCodes(segments) {
  if (!segments || segments.length === 0) return ''
  const codes = []
  for (const s of segments) {
    if (codes[codes.length - 1] !== s.fromCode) codes.push(s.fromCode)
    if (codes[codes.length - 1] !== s.toCode) codes.push(s.toCode)
  }
  return codes.join('')
}

/**
 * 2026-10-10: click hành trình → copy "SGNCGKSGN - " (có hậu tố - để user
 * paste tiếp). Giữ cho ô Hành trình.
 */
function routeConcat(segments) {
  const r = routeCodes(segments)
  return r ? r + ' - ' : ''
}

/**
 * 2026-10-10: Hậu tố loại giao dịch cho string copy từ booking.
 *   EXCHANGE → " (Phí Đổi Vé)"
 *   REFUND   → " (Phí Hoàn Vé)"
 *   NEW / SERVICE → ""
 */
function kindCopySuffix(kind) {
  if (kind === 'EXCHANGE') return ' (Phí Đổi Vé)'
  if (kind === 'REFUND') return ' (Phí Hoàn Vé)'
  return ''
}

/**
 * 2026-10-10: Build chuỗi copy chuẩn cho mã booking / số vé.
 *   "{route} - {id}{kindSuffix}"
 * Route trống → "{id}{kindSuffix}" (fallback khi booking chưa có segment).
 */
function buildIdCopyString(segments, id, kind) {
  const r = routeCodes(segments)
  const suffix = kindCopySuffix(kind)
  if (!r) return `${id}${suffix}`
  return `${r} - ${id}${suffix}`
}

/**
 * 2026-10-10: Build chuỗi copy cho dòng phí dịch vụ.
 *   "{route} - {ticketNumber || bookingCode} ({feeLabelTitleCase})"
 * KHÔNG áp dụng kindSuffix (fee label đã là identifier riêng).
 */
function buildFeeCopyString(segments, ticketNumber, bookingCode, feeLabelTitleCase) {
  const r = routeCodes(segments)
  const id = (ticketNumber && ticketNumber.trim()) || bookingCode || ''
  const feePart = `(${feeLabelTitleCase})`
  if (!r) return id ? `${id} ${feePart}` : feePart
  return id ? `${r} - ${id} ${feePart}` : `${r} - ${feePart}`
}
// ═══════════════════════════════════════════════════════════════════════════
//  2026-11-07 — Export PDF Picker + Debt Report Modal
// ═══════════════════════════════════════════════════════════════════════════

/** dd/MM/yyyy cho hiển thị trong picker. Null-safe. */
function formatRangeLabel(fromSale, toSale) {
  const f = (iso) => {
    if (!iso) return ''
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
    return m ? `${m[3]}/${m[2]}/${m[1]}` : iso
  }
  const a = f(fromSale), b = f(toSale)
  if (a && b) return a === b ? `ngày ${a}` : `${a} — ${b}`
  if (a) return `từ ${a}`
  if (b) return `đến ${b}`
  return ''
}

/**
 * 2026-11-11: Picker rút gọn còn 2 lựa chọn — Báo cáo bán vé và Báo cáo công
 * nợ. "Báo cáo bán vé" xuất các booking trong KHOẢNG NGÀY UI đang chọn. Nếu
 * khoảng = đúng hôm nay → tự kèm hóa đơn nháp; nếu khác → hỏi modal 2 nút.
 */
function ExportPickerModal({ onClose, fromSale, toSale, onPickReport, onPickDebt }) {
  const hasRange = !!(fromSale || toSale)
  const rangeLabel = formatRangeLabel(fromSale, toSale) || 'chưa chọn'
  return (
    <Modal open onClose={onClose} title="Xuất PDF" size="md">
      <div className="space-y-3">
        <button type="button" onClick={onPickReport} disabled={!hasRange}
          title={hasRange ? '' : 'Chọn khoảng ngày bán ở toolbar trước khi dùng.'}
          className={`w-full text-left p-4 rounded-xl border-2 transition ${hasRange
              ? 'border-emerald-200 bg-emerald-50 hover:bg-emerald-100 hover:border-emerald-400'
              : 'border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed'
            }`}>
          <div className="flex items-center gap-3">
            <div className="text-2xl">📅</div>
            <div className="flex-1">
              <div className="font-bold text-emerald-900">Báo cáo bán vé</div>
              <div className="text-xs text-emerald-700 mt-0.5">
                Các booking trong khoảng <b>{rangeLabel}</b>.
                {' '}Nếu là <b>hôm nay</b> sẽ tự kèm hoá đơn nháp;
                nếu nhiều ngày sẽ hỏi có kèm hoá đơn hay không.
              </div>
            </div>
          </div>
        </button>
        <button type="button" onClick={onPickDebt}
          className="w-full text-left p-4 rounded-xl border-2 border-indigo-200 bg-indigo-50 hover:bg-indigo-100 hover:border-indigo-400 transition">
          <div className="flex items-center gap-3">
            <div className="text-2xl">💼</div>
            <div className="flex-1">
              <div className="font-bold text-indigo-900">Báo cáo công nợ</div>
              <div className="text-xs text-indigo-700 mt-0.5">
                Chọn công ty / chi nhánh → list các booking chưa thanh toán → nhập số hoá đơn → xuất PDF.
              </div>
            </div>
          </div>
        </button>
      </div>
    </Modal>
  )
}

/**
 * 2026-11-11: Hỏi có kèm hóa đơn nháp không, cho range nhiều ngày. Tiền thân
 * của luồng "confirm download" — giữ 1 bước trung gian để user chủ động.
 */
function AskInvoicesModal({ bookings, count, missing, onClose, onYes }) {
  const bookingCount = (bookings || []).length
  return (
    <Modal open onClose={onClose} title="Tải thêm hoá đơn nháp?" size="md">
      <div className="space-y-3">
        <div className="text-sm text-gray-700">
          Báo cáo đã được tạo cho <b>{bookingCount}</b> booking. Bên cạnh đó có
          <b> {count}</b> hoá đơn nháp sẵn sàng tải.
          {missing.length > 0 && (
            <span className="block mt-1 text-amber-700">
              ⚠ Có <b>{missing.length}</b> vé chưa có hoá đơn nháp — bạn vẫn có thể tải
              những hoá đơn hiện có, hệ thống sẽ cảnh báo danh sách còn thiếu.
            </span>
          )}
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button type="button" onClick={onClose}
            className="p-3 rounded-xl border-2 border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-sm font-semibold">
            Không cần, đóng lại
          </button>
          <button type="button" onClick={onYes}
            className="p-3 rounded-xl border-2 border-indigo-200 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 text-sm font-semibold">
            Tải kèm hoá đơn nháp
          </button>
        </div>
      </div>
    </Modal>
  )
}

/**
 * Modal build báo cáo công nợ:
 *   1. User chọn công ty (bao gồm chi nhánh) qua CompanySearchSelect.
 *   2. Component auto-fetch booking UNPAID + lọc client-side theo companyId.
 *   3. Table: 1 row/booking với input "số hoá đơn" (chỉ nhận số).
 *   4. Nút "Tạo PDF" → gọi exportDebtReport.
 */
function DebtReportModal({ companies, onClose }) {
  const [companyId, setCompanyId] = useState(null)
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(false)
  const [building, setBuilding] = useState(false)

  // ── 2026-11-07 (rev2): Chỉ hiện CÔNG TY CHÍNH (root) trong dropdown ──
  //   Chi nhánh KHÔNG hiển thị ở danh sách chọn. Khi user pick root, modal
  //   sẽ tự group bookings theo từng công ty / chi nhánh để hiển thị section.
  const rootOptions = useMemo(() => {
    return companies
      .filter(c => !c.parentId)
      .sort((a, b) => a.name.localeCompare(b.name, 'vi'))
      .map(c => ({ id: c.id, label: c.name }))
  }, [companies])

  // ID cần match khi fetch: ROOT + tất cả chi nhánh con của ROOT.
  const matchIds = useMemo(() => {
    if (companyId == null) return []
    const picked = companies.find(x => x.id === companyId)
    if (!picked) return [companyId]
    const rootId = picked.parentId || picked.id
    const branchIds = companies.filter(x => x.parentId === rootId).map(x => x.id)
    return [rootId, ...branchIds]
  }, [companyId, companies])

  // Fetch booking UNPAID khi đổi công ty.
  useEffect(() => {
    if (companyId == null || matchIds.length === 0) {
      setBookings([]); return
    }
    let cancel = false
    setLoading(true)
      ; (async () => {
        try {
          const mod = await import('../../lib/bookingsPdfExport')
          const bs = await mod.fetchUnpaidBookingsByCompany(matchIds)
          if (!cancel) setBookings(bs)
        } catch (e) {
          console.error('[debt fetch]', e)
          toast.error('Không tải được danh sách booking')
        } finally {
          if (!cancel) setLoading(false)
        }
      })()
    return () => { cancel = true }
  }, [companyId, matchIds])

  // ── 2026-11-11: Group theo công ty của TỪNG VÉ (không còn lấy công ty của
  //   vé đầu tiên). 1 booking có thể có khách của nhiều công ty, mỗi công ty
  //   1 hoá đơn tách riêng → mỗi section chỉ nhận ĐÚNG các vé còn nợ thuộc
  //   công ty đó; booking được thu hẹp (narrowBooking) nên tổng tiền + số
  //   hoá đơn phía sau cũng chỉ tính trên phần vé này.
  //   Thứ tự section: ROOT đầu tiên, rồi các chi nhánh theo createdAt.
  const sections = useMemo(() => {
    if (!companyId || bookings.length === 0) return []
    const picked = companies.find(x => x.id === companyId)
    if (!picked) return []
    const rootId = picked.parentId || picked.id
    const root = companies.find(x => x.id === rootId)
    const branches = companies
      .filter(x => x.parentId === rootId)
      .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0))
    const orderedCompanies = [root, ...branches].filter(Boolean)
    const out = []
    for (const c of orderedCompanies) {
      const bs = []
      for (const b of bookings) {
        const mine = unpaidTicketsOf(b, t => t.companyId === c.id)
        if (mine.length) bs.push(narrowBooking(b, mine))
      }
      if (bs.length) out.push({ company: c, bookings: bs })
    }
    return out
  }, [bookings, companyId, companies])

  // Mỗi section có 1 checkbox (default checked). State: Set<companyId>.
  const [excluded, setExcluded] = useState(new Set())
  // Khi đổi công ty → reset exclusion (tránh trạng thái cũ dính lại).
  useEffect(() => { setExcluded(new Set()) }, [companyId])
  const toggleExcluded = (cid) => {
    setExcluded(prev => {
      const next = new Set(prev)
      if (next.has(cid)) next.delete(cid)
      else next.add(cid)
      return next
    })
  }

  const { rootName, rootCode } = useMemo(() => {
    if (companyId == null) return { rootName: '', rootCode: '' }
    const picked = companies.find(x => x.id === companyId)
    if (!picked) return { rootName: '', rootCode: '' }
    const root = picked.parentId
      ? (companies.find(x => x.id === picked.parentId) || picked)
      : picked
    // ── 2026-11-07: Mã công ty cho filename — dùng shortName nếu có, else
    //   abbreviation từ name (chữ cái đầu mỗi từ, bỏ dấu, viết hoa).
    const toCode = (c) => {
      if (c.shortName && c.shortName.trim()) {
        return c.shortName.trim().replace(/[^A-Za-z0-9]/g, '')
      }
      // bỏ dấu
      const noDia = (c.name || '').normalize('NFD').replace(/[̀-ͯ]/g, '')
        .replace(/đ/g, 'd').replace(/Đ/g, 'D')
      return noDia.split(/\s+/).map(w => w[0] || '').join('')
        .toUpperCase().replace(/[^A-Z0-9]/g, '') || `C${c.id}`
    }
    return { rootName: root.name, rootCode: toCode(root) }
  }, [companyId, companies])

  const onBuild = async () => {
    const active = sections.filter(s => !excluded.has(s.company.id))
    if (!active.length) return toast.error('Chọn ít nhất 1 công ty để xuất')
    setBuilding(true)
    const tid = toast.loading('Đang tạo PDF công nợ…')
    try {
      const mod = await import('../../lib/bookingsPdfExport')
      await mod.exportDebtReport({
        rootName,
        rootCode,
        sections: active.map(s => ({
          companyName: s.company.name,
          bookings: s.bookings,
        })),
      })
      toast.success('Đã tạo PDF công nợ', { id: tid })
      onClose()
    } catch (e) {
      console.error('[debt build]', e)
      toast.error(e?.message || 'Tạo PDF thất bại', { id: tid })
    } finally {
      setBuilding(false)
    }
  }

  return (
    <Modal open onClose={onClose} title="Báo cáo công nợ" size="debt"
      footer={
        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose}
            className="px-4 py-2 rounded-md text-sm font-semibold text-gray-600 hover:bg-gray-100">
            Huỷ
          </button>
          <button type="button" onClick={onBuild}
            disabled={!sections.length || building}
            className="px-4 py-2 rounded-md bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 disabled:opacity-50">
            {building ? '⏳ Đang tạo…' : '📄 Tạo PDF'}
          </button>
        </div>
      }>
      <div className="space-y-3">
        <div>
          <div className="text-[11px] font-semibold text-gray-600 mb-1">Chọn công ty (chi nhánh sẽ hiển thị bên dưới)</div>
          <CompanySearchSelect
            value={companyId}
            options={rootOptions}
            onChange={setCompanyId}
            allowNone={false}
            placeholder="— Chọn công ty —"
            portal
          />
        </div>

        {companyId == null ? (
          <div className="text-xs text-gray-500 italic py-8 text-center">
            Chọn công ty để xem danh sách booking chưa thanh toán.
          </div>
        ) : loading ? (
          <div className="text-xs text-gray-500 italic py-8 text-center">Đang tải…</div>
        ) : sections.length === 0 ? (
          <div className="text-xs text-gray-500 italic py-8 text-center">
            Công ty này (và các chi nhánh) không có vé nào chưa thanh toán.
          </div>
        ) : (
          <div className="space-y-3 max-h-[60dvh] overflow-y-auto pr-1">
            {sections.map(s => {
              const isExcluded = excluded.has(s.company.id)
              // 2026-11-07: Đếm số hoá đơn UNIQUE của section (không phải số booking).
              const invSet = new Set()
              for (const b of s.bookings) {
                for (const inv of (b.invoices || [])) {
                  if (!inv.invoiceNumbers) continue
                  inv.invoiceNumbers.split(',').forEach(n => {
                    const t = n.trim()
                    if (t) invSet.add(t)
                  })
                }
              }
              const invCount = invSet.size
              return (
                <div key={s.company.id}
                  className={`border rounded-lg overflow-hidden transition
                    ${isExcluded ? 'border-gray-200 opacity-60' : 'border-indigo-200'}`}>
                  <label className={`flex items-center gap-2 px-3 py-2 border-b cursor-pointer select-none
                    ${isExcluded ? 'bg-gray-50' : 'bg-indigo-50'}`}>
                    <input type="checkbox" checked={!isExcluded}
                      onChange={() => toggleExcluded(s.company.id)}
                      className="w-4 h-4 accent-indigo-600" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-gray-900 truncate">{s.company.name}</div>
                      <div className="text-[11px] text-gray-600">
                        {invCount > 0 ? `${invCount} hoá đơn` : `Chưa có hoá đơn`}
                      </div>
                    </div>
                  </label>
                  {!isExcluded && (
                    <div className="divide-y">
                      {s.bookings.map(b => {
                        const nums = collectBookingInvoiceNumbers(b)
                        return (
                          <div key={b.id} className="flex items-center gap-2 px-3 py-2 text-xs">
                            <div className="w-24 font-mono font-bold text-gray-900">{b.bookingCode}</div>
                            <div className="flex-1 text-gray-600 truncate">
                              {(b.tickets || []).map(t => t.passengerName).join(' · ')}
                            </div>
                            <div className="w-16 text-right text-gray-500 font-mono tabular-nums">
                              {(b.tickets || []).length} vé
                            </div>
                            {/* 2026-11-07 (rev): stack DỌC — dùng <div> block
                                cho mỗi badge + w-fit + items-end để canh phải */}
                            <div className="w-56 font-mono flex flex-col items-end gap-1 self-start">
                              {nums.length === 0 ? (
                                <span className="text-gray-400 italic text-[11px]">chưa có hoá đơn</span>
                              ) : (
                                nums.map(n => (
                                  <div key={n}
                                    className="block w-fit px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[11px] font-semibold whitespace-nowrap">
                                    #C26MCB{n}
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </Modal>
  )
}

/**
 * 2026-11-07: Gom các số hoá đơn của 1 booking từ booking.invoices.
 *   invoice.invoiceNumbers là chuỗi CSV ("355,356"). Trả về list đã dedupe,
 *   sort tăng dần theo số nếu parse được, else theo alpha.
 */
export function collectBookingInvoiceNumbers(b) {
  const set = new Set()
  for (const inv of (b.invoices || [])) {
    if (!inv.invoiceNumbers) continue
    inv.invoiceNumbers.split(',').forEach(n => {
      const t = n.trim()
      if (t) set.add(t)
    })
  }
  return [...set].sort((a, c) => {
    const na = Number(a), nc = Number(c)
    if (Number.isFinite(na) && Number.isFinite(nc)) return na - nc
    return a.localeCompare(c)
  })
}

// ═══════════════════════════════════════════════════════════════════════════
//  2026-11-07: PaidReceiptsModal — xem/xoá biên nhận cho booking đã thanh toán
//    Open khi click "Đã thanh toán" badge: KHÔNG hiển thị form nhập thêm nữa.
//    Chỉ list các payment (từ mọi invoice của booking) kèm file preview + nút
//    xoá từng phiếu HOẶC "Xoá tất cả" (reset về Chưa thanh toán).
// ═══════════════════════════════════════════════════════════════════════════
function PaidReceiptsModal({ booking, onClose, onChanged, onCleared }) {
  const [rows, setRows] = useState([])        // [{ invoice, payments }]
  const [loading, setLoading] = useState(true)
  const [preview, setPreview] = useState(null)      // { url, name }
  const [confirmDel, setConfirmDel] = useState(null)   // { payment }
  const [confirmAll, setConfirmAll] = useState(false)
  const [busy, setBusy] = useState(false)

  const reload = useCallback(async () => {
    setLoading(true)
    try {
      const invs = booking.invoices || []
      const results = await Promise.all(invs.map(async (inv) => {
        try {
          const res = await listInvoicePayments(inv.id)
          return { invoice: inv, payments: res.data?.data || [] }
        } catch { return { invoice: inv, payments: [] } }
      }))
      setRows(results)
    } finally { setLoading(false) }
  }, [booking])

  useEffect(() => { reload() }, [reload])

  const allPayments = useMemo(() =>
    rows.flatMap(r => r.payments.map(p => ({ ...p, _invoice: r.invoice }))),
    [rows])

  const doDelOne = async () => {
    if (!confirmDel) return
    setBusy(true)
    try {
      await deletePayment(confirmDel.payment.id)
      toast.success('Đã xoá phiếu thu')
      setConfirmDel(null)
      await reload()
      onChanged?.()
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Xoá thất bại')
    } finally { setBusy(false) }
  }

  const doDelAll = async () => {
    setBusy(true)
    const tid = toast.loading('Đang xoá tất cả phiếu thu…')
    try {
      // Xoá tuần tự để BE rollup paidAmount đúng.
      for (const p of allPayments) {
        await deletePayment(p.id)
      }
      toast.success('Đã reset toàn bộ phiếu thu của booking này', { id: tid })
      setConfirmAll(false)
      onCleared?.()
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Xoá thất bại', { id: tid })
      await reload()
    } finally { setBusy(false) }
  }

  return (
    <>
      <Modal open onClose={onClose} title={`Biên nhận đã thu — ${booking.bookingCode || ''}`} size="lg"
        // 2026-11-07: Khi ZoomablePreview / Confirm modal đang mở phía trên,
        //   suppress ESC của modal này — tránh ESC "xuyên" đóng cả 2 cùng lúc.
        disableEsc={!!preview || !!confirmDel || confirmAll}
        footer={
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => setConfirmAll(true)}
              disabled={busy || allPayments.length === 0}
              title="Xoá tất cả phiếu thu + ảnh của booking này; tự reset về Chưa thanh toán"
              className="px-4 py-2 rounded-md text-sm font-semibold text-rose-700 hover:bg-rose-50 border border-rose-300 disabled:opacity-40">
              🗑 Xoá trạng thái đã thu
            </button>
            <div className="flex-1" />
            <button onClick={onClose}
              className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-md font-medium">
              Đóng
            </button>
          </div>
        }>
        <div className="space-y-4">
          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
            Booking này đã thu đủ. Dưới đây là <b>{allPayments.length}</b> phiếu thu đã ghi nhận.
            Click <b>×</b> trên 1 phiếu để xoá riêng (sẽ trừ lại số tiền đã thu),
            hoặc nút <b>Xoá trạng thái đã thu</b> để xoá sạch và reset về Chưa thanh toán.
          </div>

          {loading ? (
            <div className="py-10 text-center text-xs text-gray-400 italic">Đang tải…</div>
          ) : allPayments.length === 0 ? (
            <div className="py-10 text-center text-xs text-gray-400 italic">
              Không có phiếu thu nào (có thể booking miễn phí hoặc đã bị xoá hết).
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {allPayments.map(p => {
                const inv = p._invoice
                const invLabel = inv?.invoiceNumbers
                  ? `#C26MCB${inv.invoiceNumbers.split(',')[0].trim()}`
                  : `Nháp HĐ #${inv?.id}`
                return (
                  <div key={p.id}
                    className="rounded-xl border border-gray-200 bg-white shadow-sm hover:shadow-md transition overflow-hidden flex flex-col">
                    {/* Thumbnail (nếu có ảnh) */}
                    {p.fileUrl ? (
                      <button type="button"
                        onClick={() => setPreview({ url: p.fileUrl, name: p.fileOriginal || 'Biên nhận' })}
                        title="Click để phóng to xem"
                        className="w-full h-40 bg-gray-50 border-b border-gray-200 flex items-center justify-center overflow-hidden group">
                        {isImageUrl(p.fileUrl) ? (
                          <img src={resolvePublicUrl(p.fileUrl)} alt="Biên nhận"
                            className="w-full h-full object-contain group-hover:scale-105 transition-transform" />
                        ) : (
                          <div className="text-4xl text-gray-300 group-hover:text-gray-500">📄</div>
                        )}
                      </button>
                    ) : (
                      <div className="w-full h-40 bg-gray-50 border-b border-gray-200 flex items-center justify-center text-xs text-gray-400 italic">
                        (không có ảnh biên nhận)
                      </div>
                    )}
                    <div className="p-3 flex-1 flex items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-mono font-bold text-emerald-700 text-sm">+{p.amount}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold whitespace-nowrap">
                            {invLabel}
                          </span>
                        </div>
                        <div className="text-[11px] text-gray-500">
                          {p.createdAt ? new Date(p.createdAt).toLocaleString('vi-VN') : ''}
                          {p.createdBy && <span className="ml-1 text-gray-400">· bởi {p.createdBy}</span>}
                        </div>
                        {p.note && (
                          <div className="mt-1 text-xs text-gray-700 whitespace-pre-wrap break-words">
                            {p.note}
                          </div>
                        )}
                      </div>
                      <button type="button" onClick={() => setConfirmDel({ payment: p })}
                        title="Xoá phiếu thu này (trừ lại số tiền đã thu)"
                        className="shrink-0 w-8 h-8 rounded-md text-rose-600 hover:bg-rose-50 text-lg leading-none">
                        ×
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </Modal>

      {preview && (
        <ZoomablePreview
          filePath={preview.url}
          fileName={preview.name}
          title={`Biên nhận · ${preview.name}`}
          onClose={() => setPreview(null)}
        />
      )}

      {confirmDel && (
        <ConfirmModal
          open title="Xoá phiếu thu"
          message={`Xoá phiếu thu +${confirmDel.payment.amount}? Số tiền đã thu sẽ bị trừ lại tương ứng; ảnh biên nhận cũng bị xoá.`}
          confirmLabel="Xoá" danger
          onConfirm={doDelOne}
          onClose={() => setConfirmDel(null)}
        />
      )}
      {confirmAll && (
        <ConfirmModal
          open title="Xoá trạng thái đã thu"
          message={`Thao tác này xoá ${allPayments.length} phiếu thu + ảnh đính kèm, trừ sạch số tiền đã thu, reset booking về Chưa thanh toán. Không thể hoàn tác. Tiếp tục?`}
          confirmLabel="Xoá tất cả" danger
          onConfirm={doDelAll}
          onClose={() => setConfirmAll(false)}
        />
      )}
    </>
  )
}

function isImageUrl(u) {
  if (!u) return false
  const s = u.split('?')[0].toLowerCase()
  return /\.(png|jpe?g|gif|bmp|webp|heic|heif)$/.test(s)
}
function resolvePublicUrl(u) {
  if (!u) return u
  if (/^https?:\/\//i.test(u)) return u
  const BASE = import.meta.env.VITE_API_URL || 'http://localhost:9009'
  return BASE + (u.startsWith('/') ? u : '/' + u)
}