import { useEffect, useRef, useState } from 'react'
import toast from 'react-hot-toast'
import Modal from '../common/Modal'
import ConfirmModal from '../common/ConfirmModal'
import FilePreviewModal from '../files/FilePreviewModal'
import {
  getPassenger, createPassenger, updatePassenger,
  uploadCccdFile, uploadPassportFile, removeCccdFile, removePassportFile,
} from '../../services/vmbApi'

/**
 * Form thêm / sửa 1 hành khách.
 *
 * ── Chọn công ty ─────────────────────────────────────────
 * 2 chế độ:
 *   - "Chọn có sẵn" → dropdown liệt kê công ty
 *   - "Gõ tên mới"  → text input, BE tự tạo company mới nếu chưa có
 *
 * ── File CCCD / Hộ chiếu ─────────────────────────────────
 * Bản trước chỉ cho upload SAU KHI đã lưu (cần passenger.id để gọi endpoint
 * upload). Bản này BUFFER file ở client trong lúc tạo mới — người dùng chọn
 * ảnh ngay, submit form sẽ tạo passenger rồi upload luôn theo thứ tự. Ít click
 * hơn, form khỏi phải chuyển "mode giữa chừng".
 *
 * Ở chế độ SỬA (mode='edit'), upload chạy ngay lập tức (không buffer) vì id
 * đã có sẵn — user nhấn "Thay" → gọi API luôn, không chờ nút "Lưu".
 */
export default function PassengerFormModal({ mode: initialMode = 'create', passengerId, companies, onClose, onSaved }) {
  const [mode, setMode] = useState(initialMode)
  const [id, setId]     = useState(passengerId || null)
  const [loading, setLoading] = useState(mode === 'edit')
  const [busy, setBusy] = useState(false)

  const [companyPickMode, setCompanyPickMode] = useState('existing')

  const [form, setForm] = useState({
    companyId: '',
    newCompanyName: '',
    fullName: '',
    cccdNo: '',
    passportNo: '',
    dob: '',
    expiryDate: '',
    gender: 'MALE',
  })

  // Đã upload lên BE (chỉ có ở edit mode) — {url, original}
  const [cccdFile,     setCccdFile]     = useState(null)
  const [passportFile, setPassportFile] = useState(null)

  // Buffer client (chỉ có ở create mode chưa lưu) — File object thô
  const [cccdBuf,     setCccdBuf]     = useState(null)
  const [passportBuf, setPassportBuf] = useState(null)

  const [preview, setPreview] = useState(null)
  const [confirmDelFile, setConfirmDelFile] = useState(null)

  const cccdInputRef = useRef(null)
  const ppInputRef   = useRef(null)

  // Load nếu edit
  useEffect(() => {
    if (mode !== 'edit' || !id) return
    ;(async () => {
      setLoading(true)
      try {
        const res = await getPassenger(id)
        const p = res.data?.data
        if (!p) throw new Error('Không tìm thấy')
        setForm({
          companyId: p.companyId ? String(p.companyId) : '',
          newCompanyName: '',
          fullName: p.fullName || '',
          cccdNo: p.cccdNo || '',
          passportNo: p.passportNo || '',
          dob: p.dob || '',
          expiryDate: p.expiryDate || '',
          gender: p.gender || 'MALE',
        })
        setCccdFile(p.cccdUrl ? { url: p.cccdUrl, original: p.cccdOriginal } : null)
        setPassportFile(p.passportUrl ? { url: p.passportUrl, original: p.passportOriginal } : null)
      } catch (e) {
        toast.error(e?.response?.data?.message || 'Không tải được hành khách')
        onClose()
      } finally {
        setLoading(false)
      }
    })()
  }, [mode, id, onClose])

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    if (!form.fullName.trim()) return toast.error('Tên khách không được để trống')
    if (companyPickMode === 'new' && !form.newCompanyName.trim())
      return toast.error('Gõ tên công ty mới')

    const body = {
      ...form,
      companyId: companyPickMode === 'existing' && form.companyId ? Number(form.companyId) : null,
      newCompanyName: companyPickMode === 'new' ? form.newCompanyName : null,
    }

    setBusy(true)
    try {
      if (mode === 'edit') {
        await updatePassenger(id, body)
        toast.success('Đã cập nhật')
        onSaved()
      } else {
        // 1. Tạo passenger
        const res = await createPassenger(body)
        const saved = res.data?.data
        // 2. Nếu có file buffered, upload ngay (không chờ user thao tác thêm)
        if (cccdBuf || passportBuf) {
          try {
            if (cccdBuf)     await uploadCccdFile(saved.id, cccdBuf)
            if (passportBuf) await uploadPassportFile(saved.id, passportBuf)
          } catch (upErr) {
            // Passenger đã tạo thành công nhưng upload file lỗi — thông báo riêng
            // để user biết cần thử lại thao tác upload thôi, khỏi tạo lại từ đầu.
            toast.error('Đã tạo khách nhưng tải file thất bại: ' + (upErr?.response?.data?.message || upErr?.message))
          }
        }
        toast.success('Đã tạo hành khách')
        onSaved()
      }
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Lưu thất bại')
    } finally {
      setBusy(false)
    }
  }

  // ── Upload NGAY (edit mode) hoặc BUFFER (create mode) ────────
  const handlePickFile = (kind, file) => {
    if (!file) return
    if (mode === 'create') {
      if (kind === 'cccd')     setCccdBuf(file)
      else                     setPassportBuf(file)
      return
    }
    // edit mode: upload ngay
    ;(async () => {
      setBusy(true)
      try {
        const res = kind === 'cccd'
          ? await uploadCccdFile(id, file)
          : await uploadPassportFile(id, file)
        const p = res.data?.data
        if (kind === 'cccd')     setCccdFile({ url: p.cccdUrl, original: p.cccdOriginal })
        else                     setPassportFile({ url: p.passportUrl, original: p.passportOriginal })
        toast.success('Đã tải lên')
      } catch (e) {
        toast.error(e?.response?.data?.message || 'Tải file thất bại')
      } finally {
        setBusy(false)
      }
    })()
  }

  const doRemoveFile = async (kind) => {
    if (mode === 'create') {
      // Chỉ xóa buffer local
      if (kind === 'cccd')     setCccdBuf(null)
      else                     setPassportBuf(null)
      setConfirmDelFile(null)
      return
    }
    setBusy(true)
    try {
      if (kind === 'cccd') { await removeCccdFile(id); setCccdFile(null) }
      else                 { await removePassportFile(id); setPassportFile(null) }
      toast.success('Đã gỡ file')
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Gỡ file thất bại')
    } finally {
      setBusy(false)
      setConfirmDelFile(null)
    }
  }

  const isEditMode = mode === 'edit' && id

  // Slot hiển thị — trong create dùng buffer, trong edit dùng file đã upload
  const cccdSlot = mode === 'create'
    ? (cccdBuf     ? { original: cccdBuf.name,     buffered: true, localUrl: URL.createObjectURL(cccdBuf) } : null)
    : cccdFile
  const passportSlot = mode === 'create'
    ? (passportBuf ? { original: passportBuf.name, buffered: true, localUrl: URL.createObjectURL(passportBuf) } : null)
    : passportFile

  return (
    <>
      <Modal
        open
        onClose={busy ? undefined : onClose}
        title={isEditMode ? 'Sửa hành khách' : 'Thêm hành khách mới'}
        size="lg"
        closeOnBackdrop={!busy}
        footer={
          <div className="flex justify-end gap-2">
            <button type="button" onClick={onClose} disabled={busy}
              className="px-4 py-2 text-sm rounded-lg text-gray-600 hover:bg-gray-200 disabled:opacity-50">
              Hủy
            </button>
            <button type="submit" form="pax-form" disabled={busy || loading}
              className="px-4 py-2 text-sm font-semibold rounded-lg bg-blue-600 text-white
                hover:bg-blue-700 disabled:opacity-50">
              {busy ? 'Đang lưu…' : (isEditMode ? 'Lưu thay đổi' : 'Tạo hành khách')}
            </button>
          </div>
        }
      >
        {loading ? (
          <div className="py-10 text-center text-gray-400 text-sm">Đang tải…</div>
        ) : (
          <>
            <form id="pax-form" onSubmit={submit} className="space-y-3">
              {/* Company picker */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-gray-600">Công ty</label>
                  <button type="button"
                    onClick={() => setCompanyPickMode(m => m === 'existing' ? 'new' : 'existing')}
                    className="text-[10px] font-semibold text-blue-600 hover:text-blue-800">
                    {companyPickMode === 'existing' ? '+ Gõ công ty mới' : '← Chọn có sẵn'}
                  </button>
                </div>
                {companyPickMode === 'existing' ? (
                  <select value={form.companyId}
                    onChange={e => setField('companyId', e.target.value)}
                    className="input">
                    <option value="">— Khách lẻ (mặc định) —</option>
                    {companies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                ) : (
                  <input type="text" value={form.newCompanyName}
                    onChange={e => setField('newCompanyName', e.target.value)}
                    placeholder="Tên công ty mới…" className="input" />
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Field label="Họ tên" span={2}>
                  <input type="text" value={form.fullName}
                    onChange={e => setField('fullName', e.target.value)}
                    placeholder="NGUYEN VAN A" className="input uppercase" />
                </Field>
                <Field label="Giới tính">
                  <select value={form.gender}
                    onChange={e => setField('gender', e.target.value)}
                    className="input">
                    <option value="MALE">Nam</option>
                    <option value="FEMALE">Nữ</option>
                    <option value="OTHER">Khác</option>
                  </select>
                </Field>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="Ngày sinh">
                  <input type="date" value={form.dob}
                    onChange={e => setField('dob', e.target.value)} className="input" />
                </Field>
                <Field label="Ngày hết hạn (giấy tờ)">
                  <input type="date" value={form.expiryDate}
                    onChange={e => setField('expiryDate', e.target.value)} className="input" />
                  <p className="text-[10px] text-gray-400 mt-0.5">
                    Cảnh báo màu vàng khi còn ≤ 6 tháng, đỏ khi hết hạn.
                  </p>
                </Field>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="Số CCCD">
                  <input type="text" value={form.cccdNo}
                    onChange={e => setField('cccdNo', e.target.value)}
                    placeholder="12 số" className="input font-mono" />
                </Field>
                <Field label="Số hộ chiếu">
                  <input type="text" value={form.passportNo}
                    onChange={e => setField('passportNo', e.target.value)}
                    placeholder="B1234567" className="input font-mono uppercase" />
                </Field>
              </div>
            </form>

            {/* Uploads — luôn hiện, cả create mode (buffer) lẫn edit (upload ngay) */}
            <div className="mt-5 pt-4 border-t border-gray-200">
              <div className="text-xs font-bold text-gray-700 uppercase tracking-wide mb-2">
                Ảnh / PDF giấy tờ
                {mode === 'create' && (cccdBuf || passportBuf) && (
                  <span className="ml-2 text-[10px] text-blue-600 font-semibold normal-case">
                    (sẽ tải lên khi bấm Tạo)
                  </span>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <FileSlot
                  label="CCCD"
                  file={cccdSlot}
                  onPick={() => cccdInputRef.current?.click()}
                  onPreview={() => setPreview({
                    url: cccdSlot.buffered ? cccdSlot.localUrl : fileUrl(cccdSlot.url),
                    name: cccdSlot.original,
                  })}
                  onRemove={() => setConfirmDelFile({ kind: 'cccd', name: cccdSlot.original, buffered: cccdSlot?.buffered })}
                />
                <FileSlot
                  label="Hộ chiếu"
                  file={passportSlot}
                  onPick={() => ppInputRef.current?.click()}
                  onPreview={() => setPreview({
                    url: passportSlot.buffered ? passportSlot.localUrl : fileUrl(passportSlot.url),
                    name: passportSlot.original,
                  })}
                  onRemove={() => setConfirmDelFile({ kind: 'passport', name: passportSlot.original, buffered: passportSlot?.buffered })}
                />
              </div>
              <input ref={cccdInputRef} type="file" hidden accept="image/*,application/pdf"
                onChange={e => { handlePickFile('cccd', e.target.files?.[0]); e.target.value = '' }} />
              <input ref={ppInputRef} type="file" hidden accept="image/*,application/pdf"
                onChange={e => { handlePickFile('passport', e.target.files?.[0]); e.target.value = '' }} />
            </div>

            <style>{`
              .input {
                width: 100%; padding: 0.5rem 0.75rem;
                border-radius: 0.5rem;
                border: 1px solid #d1d5db; background: #fff;
                font-size: 0.875rem; outline: none;
                transition: border-color .15s, box-shadow .15s;
              }
              .input:focus {
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
              }
            `}</style>
          </>
        )}
      </Modal>

      {preview && (
        <FilePreviewModal
          isOpen
          fileUrl={preview.url}
          fileName={preview.name}
          onClose={() => setPreview(null)}
        />
      )}

      {confirmDelFile && (
        <ConfirmModal
          isOpen
          title={`Gỡ file ${confirmDelFile.kind === 'cccd' ? 'CCCD' : 'hộ chiếu'}`}
          message={
            confirmDelFile.buffered
              ? `Bỏ chọn file "${confirmDelFile.name}" (chưa upload)?`
              : `Gỡ file "${confirmDelFile.name}" khỏi hành khách?`
          }
          confirmText={confirmDelFile.buffered ? 'Bỏ' : 'Gỡ'}
          type="danger"
          onConfirm={() => doRemoveFile(confirmDelFile.kind)}
          onClose={() => setConfirmDelFile(null)}
        />
      )}
    </>
  )
}

function FileSlot({ label, file, onPick, onPreview, onRemove }) {
  return (
    <div className="p-3 rounded-xl border border-gray-200 bg-gray-50">
      <div className="text-[10px] font-bold text-gray-500 uppercase mb-2">{label}</div>
      {file ? (
        <div className="flex items-center gap-2">
          <button type="button" onClick={onPreview}
            className="flex-1 min-w-0 text-left text-sm text-blue-700 hover:text-blue-900 truncate">
            📄 {file.original || 'file'}
          </button>
          <button type="button" onClick={onPick}
            className="text-[10px] font-semibold px-2 py-1 rounded-md bg-white border border-gray-300 hover:bg-gray-100">
            Thay
          </button>
          <button type="button" onClick={onRemove}
            className="text-[10px] font-semibold px-2 py-1 rounded-md bg-white border border-rose-200 text-rose-600 hover:bg-rose-50">
            Gỡ
          </button>
        </div>
      ) : (
        <button type="button" onClick={onPick}
          className="w-full py-3 rounded-lg border-2 border-dashed border-gray-300 text-xs text-gray-500 hover:border-blue-400 hover:text-blue-600">
          + Tải ảnh / PDF
        </button>
      )}
    </div>
  )
}

function Field({ label, span, children }) {
  const cls = span === 2 ? 'sm:col-span-2' : span === 3 ? 'sm:col-span-3' : ''
  return (
    <label className={`block ${cls}`}>
      <div className="text-[11px] font-semibold text-gray-600 mb-1">{label}</div>
      {children}
    </label>
  )
}

function fileUrl(u) {
  if (!u) return u
  if (u.startsWith('http')) return u
  return (import.meta.env.VITE_API_BASE || '') + u
}
