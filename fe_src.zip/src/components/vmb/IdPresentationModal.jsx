import { useState } from 'react'
import Modal from '../common/Modal'
import ZoomablePreview from './ZoomablePreview'

/**
 * Xuất trình giấy tờ hành khách — dùng cho quầy check-in / kiểm tra nhanh.
 *
 * Bước 1: Modal nhỏ hỏi "CCCD hay Hộ chiếu?" (nếu có cả 2)
 * Bước 2: Full-screen preview với zoom + rotate qua {@link ZoomablePreview}
 *
 * Nếu chỉ có 1 loại → tự chuyển sang preview không hỏi.
 * Nếu không có gì → thông báo.
 */
export default function IdPresentationModal({ passenger, onClose }) {
  const hasCccd = !!passenger?.cccdUrl
  const hasPp   = !!passenger?.passportUrl

  const [pick, setPick] = useState(() => {
    if (hasCccd && !hasPp) return 'cccd'
    if (hasPp && !hasCccd) return 'pp'
    return null
  })

  if (!hasCccd && !hasPp) {
    return (
      <Modal open onClose={onClose} title="Xuất trình giấy tờ" size="sm" closeOnBackdrop
        footer={
          <div className="flex justify-end">
            <button onClick={onClose}
              className="px-4 py-2 text-sm rounded-lg bg-gray-200 hover:bg-gray-300">Đóng</button>
          </div>
        }>
        <div className="text-center py-6">
          <div className="text-5xl mb-3">📭</div>
          <div className="text-sm text-gray-600">
            Khách <b>{passenger?.fullName}</b> chưa có ảnh CCCD hoặc Hộ chiếu.
          </div>
          <div className="text-xs text-gray-400 mt-1">
            Vào modal sửa hành khách để tải file lên.
          </div>
        </div>
      </Modal>
    )
  }

  if (!pick) {
    return (
      <Modal open onClose={onClose} title="Chọn giấy tờ" size="sm" closeOnBackdrop>
        <div className="text-center py-2">
          <div className="text-sm text-gray-700 mb-4">
            Xuất trình giấy tờ của <b>{passenger?.fullName}</b>:
          </div>
          <div className="grid grid-cols-2 gap-3">
            <IdChoiceButton
              label="CCCD" icon="🪪" disabled={!hasCccd}
              onClick={() => setPick('cccd')}
              hint={hasCccd ? 'Có sẵn' : 'Chưa upload'}
            />
            <IdChoiceButton
              label="Hộ chiếu" icon="📘" disabled={!hasPp}
              onClick={() => setPick('pp')}
              hint={hasPp ? 'Có sẵn' : 'Chưa upload'}
            />
          </div>
        </div>
      </Modal>
    )
  }

  const path = pick === 'cccd' ? passenger.cccdUrl      : passenger.passportUrl
  const name = pick === 'cccd' ? passenger.cccdOriginal : passenger.passportOriginal

  return (
    <ZoomablePreview
      title={`${pick === 'cccd' ? 'CCCD' : 'Hộ chiếu'} — ${passenger?.fullName || ''}`}
      filePath={path}
      fileName={name || ''}
      onClose={onClose}
      onBack={hasCccd && hasPp ? () => setPick(null) : null}
    />
  )
}

function IdChoiceButton({ label, icon, disabled, onClick, hint }) {
  return (
    <button type="button" onClick={onClick} disabled={disabled}
      className={`p-5 rounded-xl border-2 transition text-center
        ${disabled
          ? 'border-gray-100 bg-gray-50 text-gray-300 cursor-not-allowed'
          : 'border-blue-200 bg-blue-50 text-blue-800 hover:bg-blue-100 hover:border-blue-400'}`}>
      <div className="text-4xl mb-1">{icon}</div>
      <div className="font-bold text-sm">{label}</div>
      <div className="text-[10px] opacity-70 mt-0.5">{hint}</div>
    </button>
  )
}