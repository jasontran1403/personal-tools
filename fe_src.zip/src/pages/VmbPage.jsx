import { useSearchParams, Link } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import toast from 'react-hot-toast'
import Tabs from '../components/common/Tabs'
import UserMenu from '../components/auth/UserMenu'
import TicketsTab   from '../components/vmb/TicketsTab'
import PassengersTab from '../components/vmb/PassengersTab'
import CustomersTab  from '../components/vmb/Customerstab'
import LookupTab    from '../components/vmb/LookupTab'
import TodoTab      from '../components/vmb/TodoTab'
import PdfTab       from '../components/vmb/pdf/PdfTab'
import OfficeWorkspace from '../components/office/OfficeWorkspace'
import FilesBrowser    from '../components/files/FilesBrowser'
import InvoicesPage    from '../components/vmb/invoices/InvoicesPage'
import useTodayTaskStats from '../hooks/useTodayTaskStats'

/**
 * Trang /vmb — bắt buộc đăng nhập (Phase D). Route được bọc RequireToolsAuth
 * ở App.jsx nên vào được đây chắc chắn đã có user.
 *
 * ── Full-width layout ────────────────────────────────────────
 * Không cap max-width — nhân viên vé làm việc trên màn 27" cần tận dụng hết
 * chiều ngang cho bảng 16 cột.
 *
 * ── 2026-09-20: thêm tab Todo ─────────────────────────────
 * Tab thứ 4, layout calendar 7 ngày. Cùng lúc bơm badge "số task còn phải
 * hoàn thành trong ngày" + countdown deadline gần nhất vào tab Tra cứu qua
 * hook {@link useTodayTaskStats}. Badge tự cập nhật mỗi 30s (poll BE) + tick
 * countdown mỗi giây.
 *
 * ── 2026-11-15: Quản lý hóa đơn (swipe) ───────────────────
 * Tab "Vé máy bay" giờ bọc trong 1 slider ngang gồm 2 panel:
 *   [TicketsTab]  ⟷  [InvoicesPage]
 * Nút "🧾 Hóa đơn" ở toolbar TicketsTab mở panel hóa đơn (trượt sang trái);
 * nút "← Vé máy bay" trong InvoicesPage trượt về. Dùng transform translateX
 * + transition cho hiệu ứng swipe. InvoicesPage mount lazy (chỉ nạp dữ liệu
 * sau lần mở đầu tiên), và reset khi đổi tab.
 */
// ── 2026-11-07 ────────────────────────────────────────────
// Thêm tab "Khách hàng" (customers) chèn sau "Vé máy bay".
// Đổi tên "Thông tin khách" → "Thông tin".
const BASE_TABS = [
  { key: 'tickets',     label: 'Vé máy bay',  icon: '✈️' },
  { key: 'customers',   label: 'Khách hàng',  icon: '🏢' },
  { key: 'passengers',  label: 'Thông tin',   icon: '👥' },
  { key: 'lookup',      label: 'Tra cứu',     icon: '🔎' },
  { key: 'pdf',         label: 'Pdf',         icon: '📄' },
  { key: 'office',      label: 'Office',      icon: '📊' },
  { key: 'files',       label: 'Tệp',         icon: '📁' },
  { key: 'todo',        label: 'Todo',        icon: '📋' },
]

export default function VmbPage() {
  const [params, setParams] = useSearchParams()
  const tab = BASE_TABS.some(t => t.key === params.get('tab')) ? params.get('tab') : 'tickets'

  // ── 2026-11-15: state slider hóa đơn ──
  //   invoicesOpen   = đang hiển thị panel hóa đơn (trượt sang).
  //   invoicesMounted = đã từng mở (mount lazy, giữ mounted sau đó).
  const [invoicesOpen, setInvoicesOpen]       = useState(false)
  const [invoicesMounted, setInvoicesMounted] = useState(false)

  // 2026-11-15: tín hiệu nạp lại dữ liệu khi chuyển qua lại 2 trang — tránh
  //   phải refresh tay sau khi thao tác (thu tiền ở VMB / phát hành ở Hóa đơn).
  const [invReload, setInvReload]   = useState(0)   // mở Quản lý hóa đơn → reload nó
  const [tickReload, setTickReload] = useState(0)   // về Vé máy bay → reload nó

  const openInvoices = () => { setInvoicesMounted(true); setInvoicesOpen(true); setInvReload(x => x + 1) }
  const closeInvoices = () => { setInvoicesOpen(false); setTickReload(x => x + 1) }

  // ── Ẩn cụm FAB mobile (kính lúp / + / tổng / sổ) khi đang ở trang Quản lý
  //    hóa đơn: bật class trên <body>, CSS .vmb-fab sẽ ẩn (FAB portal ra body
  //    nên không thể ẩn bằng CSS của cha). Dọn class khi rời tab/unmount. ──
  useEffect(() => {
    const on = tab === 'tickets' && invoicesOpen
    document.body.classList.toggle('vmb-invoices-open', on)
    return () => document.body.classList.remove('vmb-invoices-open')
  }, [tab, invoicesOpen])

  const setTab = (k) => {
    const next = new URLSearchParams(params)
    next.set('tab', k)
    setParams(next, { replace: true })
    // Đổi tab → đóng panel hóa đơn để không "kẹt" ở trạng thái trượt.
    setInvoicesOpen(false)
  }

  // ── Stats today cho badge Todo ──────────────────────
  // refresh: expose ra để truyền xuống TodoTab, gọi ngay sau mỗi thao tác
  // (tạo/sửa/xóa/complete/extend/cancel) → badge sync tức thì, không chờ
  // 30s poll interval.
  const { pendingCount, countdownLabel, refresh: refreshTaskStats } = useTodayTaskStats()

  // Bơm badge động vào tab TODO — copy mảng để không mutate constants
  // ── 2026-09-20: badge chuyển từ tab "Tra cứu" → "Todo" cho đúng ngữ nghĩa ──
  const tabs = useMemo(() => BASE_TABS.map(t => {
    if (t.key !== 'todo') return t
    if (!pendingCount) return t
    // Badge: "4 · 1h23m" (số task còn lại + countdown deadline gần nhất)
    const parts = [String(pendingCount)]
    if (countdownLabel) parts.push(countdownLabel)
    return { ...t, badge: parts.join(' · ') }
  }), [pendingCount, countdownLabel])

  return (
    // 2026-10-10: Đổi min-h-screen → h-dvh + overflow-hidden + flex column
    // để các tab tự quản lý scroll (toolbar/filter fixed, chỉ bảng cuộn).
    <div className="h-dvh overflow-hidden flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Không mount Toaster ở đây — main.jsx đã có global Toaster */}
      {/* Ẩn cụm FAB khi đang xem trang Quản lý hóa đơn (xem useEffect trên). */}
      <style>{`body.vmb-invoices-open .vmb-fab{display:none !important}`}</style>


      {/* Header */}
      <header className="shrink-0 z-30 bg-white/80 backdrop-blur-xl border-b border-white/40 shadow-sm">
        <div className="w-full px-3 sm:px-4 py-2 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600
              text-white flex items-center justify-center shadow-lg shadow-blue-500/20">
              ✈️
            </span>
            <div>
              <div className="text-sm font-bold text-gray-900 leading-tight">Vé máy bay</div>
              <div className="text-[10px] text-gray-500 leading-tight">Nhật Nam Tools</div>
            </div>
          </div>
          <div className="flex-1" />
          <Link to="/"
            className="text-xs text-gray-500 hover:text-gray-800 font-medium px-3 py-1.5 rounded-lg
                       hover:bg-gray-100 transition hidden sm:inline-flex">
            ← Về Tools
          </Link>
          <UserMenu />
        </div>

        {/* Tabs */}
        <div className="w-full px-3 sm:px-4">
          <Tabs
            tabs={tabs}
            active={tab}
            onChange={setTab}
          />
        </div>
      </header>

      {/* Nội dung theo tab — flex-1 overflow-hidden để tab tự scroll.
          Tabs cần fixed toolbar sẽ dùng `h-full flex flex-col` + bên trong
          toolbar `shrink-0` và vùng cuộn `flex-1 overflow-auto`. */}
      <main className="flex-1 overflow-hidden w-full px-2 sm:px-3 py-3">
        {tab === 'tickets' && (
          // ── Slider ngang: [Vé máy bay] ⟷ [Quản lý hóa đơn] ──
          <div className="relative h-full overflow-hidden">
            <div
              className="flex h-full w-[200%] transition-transform duration-300 ease-out"
              style={{ transform: invoicesOpen ? 'translateX(-50%)' : 'translateX(0)' }}
            >
              <div className="w-1/2 h-full min-w-0 overflow-hidden">
                <TicketsTab onOpenInvoices={openInvoices} fabHidden={invoicesOpen} refreshSignal={tickReload} />
              </div>
              <div className="w-1/2 h-full min-w-0 overflow-hidden">
                {invoicesMounted && <InvoicesPage onBack={closeInvoices} refreshSignal={invReload} />}
              </div>
            </div>
          </div>
        )}
        {tab === 'customers'  && <CustomersTab />}
        {tab === 'passengers' && <PassengersTab />}
        {tab === 'lookup'     && <LookupTab />}
        {tab === 'pdf'        && <PdfTab />}
        {tab === 'office'     && <OfficeWorkspace onNotify={(msg, ok=true) => (ok ? toast.success(msg) : toast.error(msg))} />}
        {tab === 'files'      && <FilesBrowser    onNotify={(msg, ok=true) => (ok ? toast.success(msg) : toast.error(msg))} />}
        {tab === 'todo'       && <TodoTab onTasksChanged={refreshTaskStats} />}
      </main>
    </div>
  )
}
