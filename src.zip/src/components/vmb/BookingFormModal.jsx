import { useEffect, useMemo, useState } from 'react'
import toast from 'react-hot-toast'
import Modal from '../common/Modal'
import RouteInput from './RouteInput'
import PriceInput from './PriceInput'
import { getBooking, createBooking, updateBooking, listCompanies, listFeeTypes, listBookings, getPassenger } from '../../services/vmbApi'
import { parseAmount, formatMoney } from '../../lib/money'
import TicketFeesEditor from './TicketFeesEditor'
import CompanySearchSelect, { companyOptions } from '../common/CompanySearchSelect'
import PassengerSearchSelect from '../common/PassengerSearchSelect'
import PassengerIdPickerModal from './PassengerIdPickerModal'

/**
 * Form thêm/sửa BOOKING (kèm segments + N tickets).
 *
 * ── 2026-09-15 refactor ────────────────────────────────────
 * - Thêm cờ {@code sharedTicketFace}.
 * - Bỏ quản lý file mặt vé trong form này — chuyển sang {@code TicketFaceModal}.
 *
 * ── 2026-09-15 chiều ────────────────────────────────────────
 * - Cty là {@code CompanySearchSelect} (searchable dropdown thay vì {@code <select>}).
 * - Nút "+ Thêm vé" sao chép các field DÙNG CHUNG từ vé TRƯỚC ĐÓ.
 *
 * ── 2026-09-19 refactor ────────────────────────────────────
 * - BỎ trường serviceFee đơn. Thay bằng list {@code fees} chi tiết với 10
 *   loại phí. UI dùng {@link TicketFeesEditor}.
 * - "+ Thêm vé" KHÔNG copy fees (mỗi khách có phí phát sinh khác nhau).
 *
 * ── 2026-09-21 gross-tracking cho Giá gốc + Phí thu hộ ────
 * User workflow:
 *   1. Paste "tổng tiền vé từ vendor" (VD 4.124.362) vào Giá gốc.
 *   2. Paste liên tục các phí thu hộ (sumOnPaste) → cộng dồn.
 *   3. Giá gốc TỰ ĐỘNG = tổng - phí thu hộ, giữ invariant
 *      "gross = basePrice + collectionFee" constant.
 *   4. Xóa phí → giá gốc quay về gross ban đầu.
 *
 * Cách track: ticket có field ẨN {@code _originalTotal} (Number) = gross.
 * - {@link setBasePrice}: user commit basePrice → cập nhật _originalTotal =
 *   basePrice + collectionFee hiện tại (baseline mới).
 * - {@link setCollectionFee}: user commit collectionFee → nếu _originalTotal
 *   đã set → basePrice = _originalTotal - collectionFee mới.
 *
 * _originalTotal KHÔNG bao giờ được gửi lên BE (bị strip trong submit).
 */
export default function BookingFormModal({ mode = 'create', bookingId, onClose, onSaved }) {
  const isEdit = mode === 'edit'
  const [loading, setLoading] = useState(isEdit)
  const [busy, setBusy] = useState(false)
  const [companies, setCompanies] = useState([])
  const [feeTypes, setFeeTypes] = useState([])

  useEffect(() => {
    listCompanies()
      .then(res => setCompanies(res.data?.data || []))
      .catch(() => { })
    listFeeTypes()
      .then(res => setFeeTypes(res.data?.data || []))
      .catch(() => { })
  }, [])

  const [form, setForm] = useState(() => ({
    kind: 'NEW',
    airlineCode: '',
    bookingCode: '',
    routeStr: '',
    currency: 'VND',
    exchangeRate: '',
    note: '',
    sharedTicketFace: false,
    segments: [],
    tickets: [newTicket()],
    // ── 2026-10-16: invoice group link ──
    //   linkedBookingCode: mã booking để gộp hóa đơn (user nhập).
    //   invoiceGroupId: id group hiện tại (chỉ hiển thị khi edit).
    //   linkedBookings: list [{id, bookingCode}] các booking cùng group khác.
    //   clearInvoiceGroup: toggle bỏ link.
    linkedBookingCode: '',
    invoiceGroupId: null,
    isInvoiceGroupOwner: false,
    ownerBookingCode: null,
    linkedBookings: [],
    clearInvoiceGroup: false,
  }))

  useEffect(() => {
    if (!isEdit) return
    ;(async () => {
      try {
        const res = await getBooking(bookingId)
        const b = res.data?.data
        if (!b) throw new Error('Không tìm thấy')
        setForm({
          kind: b.kind || 'NEW',
          airlineCode: b.airlineCode || '',
          bookingCode: b.bookingCode || '',
          routeStr: b.routeStr || '',
          currency: b.currency || 'VND',
          exchangeRate: b.exchangeRate || '',
          note: b.note || '',
          sharedTicketFace: !!b.sharedTicketFace,
          linkedBookingCode: '',
          invoiceGroupId: b.invoiceGroupId || null,
          isInvoiceGroupOwner: !!b.isInvoiceGroupOwner,
          ownerBookingCode: b.ownerBookingCode || null,
          linkedBookings: b.linkedBookings || [],
          clearInvoiceGroup: false,
          segments: (b.segments || []).map(s => ({
            fromCode: s.fromCode, toCode: s.toCode,
            departLocalMs: s.departLocalMs, segOrder: s.segOrder,
          })),
          tickets: (b.tickets || []).map(t => ({
            id: t.id,
            passengerName: t.passengerName || '',
            companyId: t.companyId || null,
            passengerId: t.passengerId || null,
            passengerDocumentType: t.passengerDocumentType || null,
            ticketNumber: t.ticketNumber || '',
            basePrice: t.basePrice || '',
            collectionFee: t.collectionFee || '',
            issuanceFee: t.issuanceFee || '',
            paidStatus: t.paidStatus || 'PENDING',
            note: t.note || '',
            fees: (t.fees || []).map(f => ({
              id: f.id,
              feeType: f.feeType,
              feeTypeLabel: f.feeTypeLabel,
              amount: f.amount || '',
              // 2026-10-12: Giữ currency riêng của mỗi dòng phí. BE trả null
              // khi là data cũ → fallback booking.currency ở TicketFeesEditor.
              currency: f.currency || b.currency || 'VND',
              note: f.note || '',
              orderIdx: f.orderIdx ?? 0,
            })),
            // Load lên với _originalTotal = null → chưa track. User paste
            // basePrice mới thì mới bắt đầu track (baseline mới).
            _originalTotal: null,
          })),
        })
      } catch (e) {
        toast.error(e?.response?.data?.message || 'Không tải được booking')
        onClose()
      } finally {
        setLoading(false)
      }
    })()
    // KHÔNG đưa onClose vào deps: parent (TicketsTab) re-render mỗi giây do
    // VmbPage tick countdown → onClose là arrow inline nên đổi ref mỗi giây,
    // sẽ khiến effect này chạy lại và ghi đè state form (mất phần user đang gõ).
    // onClose ở đây chỉ dùng trong nhánh lỗi fallback → dùng ref hơi cũ vẫn OK.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEdit, bookingId])

  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const setTicket = (i, patch) => setForm(f => ({
    ...f, tickets: f.tickets.map((t, idx) => idx === i ? { ...t, ...patch } : t),
  }))

  // ── 2026-10-16: ID presentation picker ──
  // Khi user chọn 1 passenger qua PassengerSearchSelect → mở modal với mode
  // "picker". Lưu { ticketIdx, passenger } vào state. Confirm → cập nhật ticket.
  const [idPicker, setIdPicker] = useState(null)  // { ticketIdx, passenger } | null

  // earliestDepartMs: epoch chặng đi đầu tiên (dùng để check expiry 6 tháng)
  const earliestDepartMs = useMemo(() => {
    const ms = (form.segments || [])
      .map(s => s.departLocalMs)
      .filter(x => x != null && x > 0)
    return ms.length ? Math.min(...ms) : null
  }, [form.segments])

  // isInternational: có bất kỳ chặng nào tiếp xúc sân bay không phải VN
  const isInternational = useMemo(() => {
    const VN_AIRPORTS = new Set([
      'SGN','HAN','DAD','CXR','HPH','VII','UIH','HUI','PQC','VCA',
      'VCL','VCS','VKG','DIN','THD','TBB','VDH','BMV','DLI','VDO',
      'DAD','VVU','VKG',
    ])
    for (const s of form.segments || []) {
      if (s.fromCode && !VN_AIRPORTS.has(s.fromCode)) return true
      if (s.toCode && !VN_AIRPORTS.has(s.toCode)) return true
    }
    return false
  }, [form.segments])

  const openPickerForTicket = async (ticketIdx, passenger) => {
    try {
      // Fetch full passenger để lấy documents + URL ảnh
      const res = await getPassenger(passenger.id)
      const full = res.data?.data || passenger
      setIdPicker({ ticketIdx, passenger: full })
    } catch {
      setIdPicker({ ticketIdx, passenger })
    }
  }

  const confirmIdPick = ({ type, doc }) => {
    if (!idPicker) return
    const { ticketIdx, passenger } = idPicker
    setTicket(ticketIdx, {
      passengerName: passenger.fullName || '',
      passengerId: passenger.id,
      passengerDocumentType: type,
      // Nếu passenger thuộc 1 company cụ thể và vé chưa có companyId → gán luôn
      companyId: form.tickets[ticketIdx].companyId ?? passenger.companyId ?? null,
    })
    setIdPicker(null)
  }

  const cancelIdPick = () => {
    if (!idPicker) return
    const { ticketIdx } = idPicker
    // Xóa khách khỏi ô input vé đã chọn
    setTicket(ticketIdx, {
      passengerName: '',
      passengerId: null,
      passengerDocumentType: null,
    })
    setIdPicker(null)
  }

  // ── 2026-09-21: Auto lookup mã booking cũ khi kind là EXCHANGE/REFUND/SERVICE ──
  // Chỉ áp dụng ở CREATE mode (không lookup khi sửa vé đã tồn tại).
  // Debounce 500ms để tránh gọi mỗi phím user gõ.
  // Nếu tìm được booking cùng mã → tự fill routeStr + segments + airlineCode
  //   NHƯNG chỉ khi các field đó còn TRỐNG (không đè lên input user đã sửa).
  // Toast báo cho user biết đã tự điền.
  const [lookedUpCode, setLookedUpCode] = useState('') // để không lookup lặp lại cùng mã

  useEffect(() => {
    if (isEdit) return
    if (form.kind === 'NEW') return
    const code = (form.bookingCode || '').trim()
    if (!code || code.length < 3) return
    if (code === lookedUpCode) return

    const timer = setTimeout(async () => {
      try {
        const res = await listBookings({ q: code, size: 10 })
        const found = (res.data?.data?.content || []).find(b => (b.bookingCode || '').toUpperCase() === code.toUpperCase())
        if (!found) return

        setLookedUpCode(code)

        // Fill route + segments nếu chưa có
        // Fill airlineCode + currency + exchangeRate nếu chưa có
        setForm(f => {
          const nextRouteStr = f.routeStr ? f.routeStr : (found.routeStr || '')
          const nextSegments = (f.segments && f.segments.length > 0)
            ? f.segments
            : (found.segments || []).map(s => ({
                fromCode: s.fromCode, toCode: s.toCode,
                departLocalMs: s.departLocalMs, segOrder: s.segOrder,
              }))
          const nextAirline = f.airlineCode ? f.airlineCode : (found.airlineCode || '')
          const nextCurrency = f.currency
          const nextRate = f.exchangeRate ? f.exchangeRate : (found.exchangeRate || '')
          return {
            ...f,
            routeStr: nextRouteStr,
            segments: nextSegments,
            airlineCode: nextAirline,
            currency: nextCurrency,
            exchangeRate: nextRate,
          }
        })

        const kindLabel = { EXCHANGE: 'đổi vé', REFUND: 'hoàn vé', SERVICE: 'dịch vụ' }[form.kind] || 'giao dịch'
        toast.success(
          `Tìm thấy booking cũ ${code}. Đã điền hành trình / hãng.` +
          (form.kind === 'EXCHANGE' ? ' Nhớ sửa giờ bay mới nếu có.' : ''),
          { duration: 4000 }
        )
      } catch { /* silent — user không cần biết lỗi API */ }
    }, 500)

    return () => clearTimeout(timer)
  }, [form.bookingCode, form.kind, isEdit, lookedUpCode])

  // Nếu user đổi kind về NEW hoặc clear code → reset lookup state
  useEffect(() => {
    if (form.kind === 'NEW' || !form.bookingCode) {
      setLookedUpCode('')
    }
  }, [form.kind, form.bookingCode])

  /**
   * Set basePrice + đồng thời reset gross baseline.
   * Sau mỗi lần user commit basePrice (paste hoặc blur):
   *   _originalTotal = basePrice + collectionFee (current)
   * → gross invariant reset về mốc mới. Fee thay đổi tiếp theo sẽ shift base.
   */
  const setBasePrice = (i, val) => setForm(f => ({
    ...f,
    tickets: f.tickets.map((t, idx) => {
      if (idx !== i) return t
      const newBaseNum = parseAmount(val)
      const currFeeNum = parseAmount(t.collectionFee)
      const gross = (Number.isFinite(newBaseNum) ? newBaseNum : 0)
                  + (Number.isFinite(currFeeNum) ? currFeeNum : 0)
      return { ...t, basePrice: val, _originalTotal: gross }
    }),
  }))

  /**
   * Set collectionFee + đồng thời recompute basePrice từ gross.
   *   Nếu _originalTotal chưa set → chỉ set collectionFee bình thường.
   *   Nếu set rồi → basePrice = _originalTotal - collectionFee (clamp ≥ 0).
   */
  const setCollectionFee = (i, val) => setForm(f => ({
    ...f,
    tickets: f.tickets.map((t, idx) => {
      if (idx !== i) return t
      const patched = { ...t, collectionFee: val }
      if (t._originalTotal != null) {
        const newFeeNum = parseAmount(val)
        const newBase = Math.max(0, t._originalTotal - (Number.isFinite(newFeeNum) ? newFeeNum : 0))
        patched.basePrice = formatMoney(newBase, f.currency, { withUnit: false })
      }
      return patched
    }),
  }))

  const MAX_TICKETS = 9

  const addTicket = () => setForm(f => {
    if (f.tickets.length >= MAX_TICKETS) {
      toast.error(`Mỗi booking tối đa ${MAX_TICKETS} vé`)
      return f
    }
    const first = f.tickets[0] || newTicket()
    return {
      ...f,
      tickets: [{
        ...newTicket(),
        companyId: first.companyId ?? null,
        basePrice: first.basePrice || '',
        collectionFee: first.collectionFee || '',
        issuanceFee: first.issuanceFee || '',
        // Copy gross tracking từ vé đầu tiên — vé mới cũng ăn theo cùng gross.
        // Nếu user muốn khác, họ tự paste giá gốc mới → baseline reset.
        _originalTotal: first._originalTotal ?? null,
      }, ...f.tickets],
    }
  })

  const removeTicket = (i) => setForm(f => ({
    ...f,
    tickets: f.tickets.length <= 1 ? f.tickets : f.tickets.filter((_, idx) => idx !== i),
  }))

  const submit = async (e) => {
    e.preventDefault()
    if (!form.tickets[0]?.passengerName?.trim()) {
      return toast.error('Vé đầu tiên cần có tên khách hàng')
    }
    if (form.currency === 'USD' && !form.exchangeRate) {
      return toast.error('Vé USD cần nhập tỷ giá')
    }
    if (form.tickets.length > 9) {
      return toast.error('Mỗi booking tối đa 9 vé')
    }

    setBusy(true)
    try {
      // ── Strip _originalTotal (chỉ dùng ở client) trước khi gửi BE ──
      // ── Strip các field hiển thị thuần (BE tự tính lại) ──
      const { invoiceGroupId, linkedBookings, isInvoiceGroupOwner, ownerBookingCode, ...rest } = form
      const body = {
        ...rest,
        segments: (form.segments || []).map((s, i) => ({ ...s, segOrder: i })),
        tickets: form.tickets.map(t => {
          const { _originalTotal, ...cleanT } = t
          return cleanT
        }),
      }
      // linkedBookingCode: chỉ gửi khi user nhập mã mới (trim).
      if (body.linkedBookingCode) body.linkedBookingCode = body.linkedBookingCode.trim().toUpperCase()
      else delete body.linkedBookingCode
      // clearInvoiceGroup: chỉ gửi khi user tick bỏ link.
      if (!body.clearInvoiceGroup) delete body.clearInvoiceGroup
      if (isEdit) {
        await updateBooking(bookingId, body)
        toast.success('Đã cập nhật')
      } else {
        await createBooking(body)
        toast.success('Đã tạo booking')
      }
      onSaved()
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Lưu thất bại')
    } finally {
      setBusy(false)
    }
  }

  const flatCompanies = useMemo(() => companyOptions(companies), [companies])

  return (
    <Modal
      open
      onClose={busy ? undefined : onClose}
      title={isEdit ? 'Sửa booking' : 'Thêm booking mới'}
      size="xl"
      closeOnBackdrop={!busy}
      footer={
        <div className="flex justify-end gap-2">
          <button type="button" onClick={onClose} disabled={busy}
            className="px-4 py-2 text-sm rounded-lg text-gray-600 hover:bg-gray-200 disabled:opacity-50">
            Hủy
          </button>
          <button type="submit" form="bf-form" disabled={busy || loading}
            className="px-4 py-2 text-sm font-semibold rounded-lg bg-blue-600 text-white
                       hover:bg-blue-700 disabled:opacity-50">
            {busy ? 'Đang lưu…' : (isEdit ? 'Lưu thay đổi' : 'Tạo booking')}
          </button>
        </div>
      }
    >
      {loading ? (
        <div className="py-10 text-center text-gray-400 text-sm">Đang tải…</div>
      ) : (
        <form id="bf-form" onSubmit={submit} className="space-y-4">
          <Section title="Thông tin chung">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Field label="Loại giao dịch" span={2}>
                <select value={form.kind} onChange={e => setField('kind', e.target.value)}
                  className="input">
                  <option value="NEW">Mua mới</option>
                  <option value="EXCHANGE">Đổi vé</option>
                  <option value="REFUND">Hoàn vé</option>
                  <option value="SERVICE">Dịch vụ</option>
                </select>
              </Field>
              <Field label="Hãng bay">
                <input type="text" value={form.airlineCode}
                  onChange={e => setField('airlineCode', e.target.value.toUpperCase().slice(0, 3))}
                  placeholder="VJ, VN…" className="input font-mono uppercase" />
              </Field>
              <Field label="Mã booking">
                <input type="text" value={form.bookingCode}
                  onChange={e => setField('bookingCode', e.target.value.toUpperCase())}
                  placeholder="ABC123" className="input font-mono uppercase" />
              </Field>
            </div>

            <div className="mt-3">
              <RouteInput
                routeStr={form.routeStr}
                segments={form.segments}
                onChange={({ routeStr, segments }) => setForm(f => ({ ...f, routeStr, segments }))}
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
              <Field label="Đồng tiền">
                <select value={form.currency}
                  onChange={e => setField('currency', e.target.value)}
                  className="input">
                  <option value="VND">VND</option>
                  <option value="USD">USD</option>
                </select>
              </Field>
              {form.currency === 'USD' && (
                <Field label="Tỷ giá (1 USD = ? VND)" span={3}>
                  <PriceInput value={form.exchangeRate} currency="VND"
                    onChange={v => setField('exchangeRate', v)} />
                </Field>
              )}
            </div>

            <div className="mt-3 p-3 rounded-xl bg-amber-50/50 border border-amber-200">
              <label className="flex items-start gap-2 cursor-pointer">
                <input type="checkbox" checked={!!form.sharedTicketFace}
                  onChange={e => setField('sharedTicketFace', e.target.checked)}
                  className="mt-1 rounded" />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900">
                    Mặt vé CHUNG cho cả booking
                  </div>
                  <div className="text-[11px] text-gray-600 mt-0.5">
                    {form.sharedTicketFace
                      ? '✓ Cả booking dùng chung 1 file mặt vé (VD Vietjet, VNA nội địa).'
                      : 'Mỗi hành khách trong booking có mặt vé riêng (VD VNA quốc tế). Đây là mặc định.'}
                  </div>
                  {isEdit && (
                    <div className="text-[10px] text-amber-700 mt-1">
                      ⚠ Đổi cờ này khi sửa sẽ XÓA các file mặt vé thuộc scope cũ.
                      Upload lại sau khi lưu.
                    </div>
                  )}
                </div>
              </label>
            </div>

            {/* ── 2026-10-16: Gộp hóa đơn với booking khác (invoice group) ── */}
            {/* Style match với section "Mặt vé CHUNG" phía trên (dark-friendly) */}
            <div className="mt-3 p-3 rounded-xl bg-indigo-500/10 border border-indigo-400/40">
              <div className="text-sm font-semibold text-indigo-200 mb-1">
                🔗 Gộp hóa đơn với booking khác
              </div>
              <div className="text-[11px] text-indigo-300/80 mb-2 leading-relaxed">
                Nhập mã booking <b>chủ</b> vào đây — hóa đơn upload ở booking chủ sẽ
                tự động chia sẻ cho tất cả booking link đến nó. Bỏ link bất cứ lúc nào.
              </div>

              {/* Khi edit: hiển thị trạng thái group */}
              {isEdit && form.invoiceGroupId != null && (
                <div className="mb-2 flex flex-wrap items-center gap-1.5">
                  {form.isInvoiceGroupOwner ? (
                    <>
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold
                          bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40">
                        ⭐ Booking chủ
                      </span>
                      {form.linkedBookings && form.linkedBookings.length > 0 && (
                        <>
                          <span className="text-[10px] text-indigo-300/60">— có {form.linkedBookings.length} booking link tới:</span>
                          {form.linkedBookings.map(lb => (
                            <span key={lb.id} className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-mono font-semibold
                              bg-indigo-500/20 text-indigo-200 ring-1 ring-indigo-400/40">
                              {lb.bookingCode || `#${lb.id}`}
                            </span>
                          ))}
                        </>
                      )}
                    </>
                  ) : form.ownerBookingCode ? (
                    <>
                      <span className="text-[10px] text-indigo-300/80">Đang link đến booking chủ:</span>
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-mono font-bold
                          bg-amber-500/20 text-amber-200 ring-1 ring-amber-400/40">
                        {form.ownerBookingCode}
                      </span>
                    </>
                  ) : null}
                  <label className="inline-flex items-center gap-1 ml-auto text-[11px] text-rose-300 cursor-pointer">
                    <input type="checkbox" checked={!!form.clearInvoiceGroup}
                      onChange={e => setField('clearInvoiceGroup', e.target.checked)}
                      className="accent-rose-500" />
                    Bỏ link (sau khi lưu)
                  </label>
                </div>
              )}

              {/* ── Cảnh báo rõ hậu quả khi tick "Bỏ link" ── */}
              {isEdit && form.clearInvoiceGroup && form.invoiceGroupId != null && (
                <div className="mb-2 p-2 rounded-md bg-rose-500/15 border border-rose-400/50 text-[11px] text-rose-200">
                  ⚠ <b>Sau khi lưu:</b>{' '}
                  {form.isInvoiceGroupOwner ? (
                    <>
                      Booking này đang là <b>chủ</b> — mọi hóa đơn mà các booking link
                      đến đang hiển thị ké sẽ bị xóa khỏi các booking đó. Hóa đơn gốc
                      ở đây <b>vẫn giữ nguyên</b>.
                    </>
                  ) : (
                    <>
                      Hóa đơn ké từ <b>{form.ownerBookingCode}</b> sẽ bị xóa khỏi
                      booking này. File gốc ở booking chủ <b>vẫn còn</b>.
                    </>
                  )}
                </div>
              )}

              <input
                type="text"
                value={form.linkedBookingCode}
                onChange={e => setField('linkedBookingCode', e.target.value.toUpperCase())}
                disabled={!!form.clearInvoiceGroup}
                placeholder="VD: P34F5W — bỏ trống nếu không muốn link"
                className="w-full px-3 py-2 rounded-lg bg-slate-900/40 border border-indigo-400/30
                  text-slate-100 placeholder:text-slate-500 text-sm font-mono uppercase
                  focus:border-indigo-400 focus:ring-2 focus:ring-indigo-400/20 outline-none
                  disabled:opacity-40 disabled:cursor-not-allowed"
              />
            </div>

            <Field label="Ghi chú chung (booking)">
              <textarea rows={2} value={form.note}
                onChange={e => setField('note', e.target.value)}
                className="input resize-none" placeholder="Ghi chú tùy chọn cho cả booking" />
            </Field>
          </Section>

          <Section title={`Vé (${form.tickets.length})`}
            action={<button type="button" onClick={addTicket}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800">
              + Thêm vé (copy từ vé cuối)
            </button>}
          >
            <div className="text-[11px] text-gray-500 mb-2">
              💡 Sau khi lưu, click mã booking / số vé ở bảng để tải mặt vé lên.
              Vé thêm mới tự copy công ty + các giá / phí từ vé cuối để nhập nhanh.
            </div>
            <div className="text-[11px] text-blue-700 mb-2 bg-blue-50 border border-blue-200 rounded-md p-2">
              💰 <b>Mẹo nhập nhanh</b>: paste tổng tiền vé vào <b>Giá gốc</b> trước, sau đó paste
              các phí thu hộ (chuỗi kiểu <code>"79000AX"</code>, <code>"36362C4"</code>…) → hệ
              thống tự cộng dồn Phí thu hộ và giảm Giá gốc tương ứng. Xóa phí → Giá gốc quay lại.
            </div>
            <div className="space-y-3">
              {form.tickets.map((t, i) => {
                return (
                  <div key={i} className="p-3 rounded-xl bg-gray-50 border border-gray-200">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-xs font-bold text-gray-700">Vé #{i + 1}</div>
                      {form.tickets.length > 1 && (
                        <button type="button" onClick={() => removeTicket(i)}
                          className="text-xs text-rose-600 hover:text-rose-800 font-semibold">
                          × Bỏ vé này
                        </button>
                      )}
                    </div>

                    <Field label="Công ty">
                      <CompanySearchSelect
                        value={t.companyId}
                        options={flatCompanies}
                        onChange={(id) => setTicket(i, { companyId: id })}
                        placeholder="— Khách lẻ —"
                      />
                    </Field>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                      <Field label={<>Tên khách hàng {t.passengerDocumentType && (
                        <span className="ml-1 text-[10px] font-bold text-indigo-700">
                          · {t.passengerDocumentType === 'CCCD' ? '🪪 CCCD' : '📘 HC'}
                        </span>
                      )}</>}>
                        {/* 2026-10-16: Dropdown search thay vì input thuần.
                            Lọc theo t.companyId. Chọn → mở IdPresentationModal. */}
                        <PassengerSearchSelect
                          value={t.passengerName}
                          companyId={t.companyId}
                          onChangeText={text => setTicket(i, {
                            passengerName: formatPaxName(text),
                            // User gõ tay sửa name → clear link cũ
                            passengerId: null, passengerDocumentType: null,
                          })}
                          onPick={(p) => {
                            if (!p) {
                              // Clear
                              setTicket(i, { passengerName: '', passengerId: null, passengerDocumentType: null })
                            } else {
                              openPickerForTicket(i, p)
                            }
                          }}
                        />
                      </Field>
                      <Field label="Số vé">
                        <input type="text" value={t.ticketNumber}
                          onChange={e => {
                            const raw = e.target.value || ''
                            const normalized = raw.replace(/[\s-]/g, '')
                            setTicket(i, { ticketNumber: normalized })
                          }}
                          className="input font-mono" placeholder="738-1234567890 (có thể để trống)" />
                      </Field>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                      <Field label="Giá gốc (chưa thu hộ)">
                        <PriceInput value={t.basePrice} currency={form.currency}
                          onChange={v => setBasePrice(i, v)} />
                      </Field>
                      <Field label="Phí thu hộ">
                        <PriceInput value={t.collectionFee} currency={form.currency}
                          onChange={v => setCollectionFee(i, v)}
                          sumOnPaste />
                      </Field>
                      <Field label="Phí xuất vé">
                        <PriceInput value={t.issuanceFee} currency={form.currency}
                          onChange={v => setTicket(i, { issuanceFee: v })} />
                      </Field>
                    </div>

                    <div className="mt-2">
                      <div className="text-[10px] font-semibold text-gray-600 mb-1">Các loại phí phát sinh</div>
                      <TicketFeesEditor
                        value={t.fees || []}
                        onChange={fees => setTicket(i, { fees })}
                        currency={form.currency}
                        feeTypes={feeTypes}
                      />
                    </div>

                    <Field label="Ghi chú vé">
                      <input type="text" value={t.note}
                        onChange={e => setTicket(i, { note: e.target.value })}
                        className="input" placeholder="Ghi chú tùy chọn" />
                    </Field>
                  </div>
                )
              })}
            </div>
          </Section>

          <style>{`
            .input {
              width: 100%;
              padding: 0.5rem 0.75rem;
              border-radius: 0.5rem;
              border: 1px solid #d1d5db;
              background: #fff;
              font-size: 0.875rem;
              outline: none;
              transition: border-color .15s, box-shadow .15s;
            }
            .input:focus {
              border-color: #3b82f6;
              box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
            }
          `}</style>
        </form>
      )}

      {/* 2026-10-16: Compact ID picker (modal nhỏ, không preview ảnh) */}
      {idPicker && (
        <PassengerIdPickerModal
          passenger={idPicker.passenger}
          isInternational={isInternational}
          earliestDepartMs={earliestDepartMs}
          onConfirm={confirmIdPick}
          onCancel={cancelIdPick}
        />
      )}
    </Modal>
  )
}

// ═══════════════════════════════════════════════════════════════
//  Helpers
// ═══════════════════════════════════════════════════════════════

function newTicket() {
  return {
    passengerName: '', companyId: null, ticketNumber: '',
    basePrice: '', collectionFee: '', issuanceFee: '',
    paidStatus: 'PENDING', note: '',
    fees: [],
    // 2026-10-16: Link tới Passenger khi chọn qua dropdown.
    passengerId: null,
    passengerDocumentType: null,
    // Client-only: theo dõi "tổng tiền gốc từ vendor" để đồng bộ basePrice
    // với collectionFee. Bị strip trong submit.
    _originalTotal: null,
  }
}

function Section({ title, action, children }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide">{title}</h3>
        {action}
      </div>
      {children}
    </div>
  )
}

function Field({ label, span, children }) {
  const spanClass = span === 2 ? 'sm:col-span-2' : span === 3 ? 'sm:col-span-3' : span === 4 ? 'sm:col-span-4' : ''
  return (
    <label className={`block ${spanClass}`}>
      <div className="text-[11px] font-semibold text-gray-600 mb-1">{label}</div>
      {children}
    </label>
  )
}

// companyOptions đã được tách sang ../common/CompanySearchSelect (export cùng
// file với component), import ở trên.

/**
 * ── 2026-10-10 ─────────────────────────────────────────
 * Chuẩn hóa tên khách: đổi "/" thành khoảng trắng, gộp nhiều space thành 1,
 * trim 2 đầu. Dùng cho cả onChange (gõ) và onPaste (dán).
 * Ví dụ: "KUWABATA/YOSHIRO" → "KUWABATA YOSHIRO"
 *       "NGUYEN  VAN /  A" → "NGUYEN VAN A"
 */
function formatPaxName(raw) {
  if (!raw) return ''
  return String(raw)
    .replace(/\//g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^\s+/, '')
}