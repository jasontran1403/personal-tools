import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import toast from 'react-hot-toast'
import ConfirmModal from '../common/ConfirmModal'
import BookingFormModal from './BookingFormModal'
import TicketFaceModal from './TicketFaceModal'
import InvoiceManagerModal from './InvoiceManagerModal'
import TicketNoteModal from './TicketNoteModal'
import BookingTotalsCard from './BookingTotalsCard'
import PaymentModal from './PaymentModal'
import BatchPaymentModal from './BatchPaymentModal'
import DatePicker from '../common/DatePicker'
import { listBookings, deleteBooking, totalsBookings } from '../../services/vmbApi'
import { parseAmount, formatMoney, sumAmounts, toVnd } from '../../lib/money'
import { primaryDeparture } from '../../lib/countdown'
import { formatDepart } from '../../lib/airportTz'

/**
 * ── 2026-09-15 ──────────────────────────────────────────────
 * - Click MÃ BOOKING → mở mặt vé chung (shared) hoặc chọn khách (per-ticket).
 * - Click SỐ VÉ → mở mặt vé riêng (per-ticket) hoặc face chung (shared).
 * - Nút action 📄 = "Xem chi tiết mặt vé".
 *
 * ── Cải tiến hiển thị (2026-09-15 chiều) ────────────────────
 * 1. Group tickets THEO CÔNG TY trong 1 booking. Vé cùng công ty đứng liền
 *    nhau; ô công ty MERGE (rowspan) qua các vé cùng công ty.
 *    Ví dụ booking có 4 vé Cty A/B/A/A → sắp lại A-A-A-B, ô Cty A rowspan=3.
 *    Thứ tự công ty giữ theo thứ tự xuất hiện đầu tiên trong booking gốc
 *    (không sort alphabet — để user thấy "cty đầu tiên đặt" ở trên).
 *
 * 2. Cột "Booking / số vé" → chỉ còn "Booking" (mã booking, rowspan cả booking).
 *    Số vé chuyển sang cột "Khách hàng":
 *        Dòng trên: tên khách
 *        Dòng dưới: số vé (font mono, click được để mở face)
 */
export default function TicketsTab() {
  const [rows, setRows]           = useState([])
  const [totals, setTotals]       = useState([])
  const [loading, setLoading]     = useState(true)
  const [totalsLoading, setTotalsLoading] = useState(false)

  const [q, setQ]                 = useState('')
  const [fromSale, setFromSale]   = useState('')
  const [toSale, setToSale]       = useState('')
  const [page, setPage]           = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal]         = useState(0)

  const [selectedIds, setSelectedIds] = useState(() => new Set())

  const [form, setForm]           = useState(null)
  const [face, setFace]           = useState(null)   // { booking, ticketId }
  const [invMgr, setInvMgr]       = useState(null)
  const [payFor, setPayFor]       = useState(null)
  const [batchPay, setBatchPay]   = useState(null)
  const [noteView, setNoteView]   = useState(null)
  const [confirmDel, setConfirmDel] = useState(null)

  const [nowTick, setNowTick] = useState(Date.now())
  useEffect(() => {
    const id = setInterval(() => setNowTick(Date.now()), 30_000)
    return () => clearInterval(id)
  }, [])

  const filterParams = useMemo(() => {
    const p = {}
    if (q)        p.q = q
    if (fromSale) p.fromSale = new Date(fromSale + 'T00:00:00').getTime()
    if (toSale)   p.toSale   = new Date(toSale + 'T23:59:59').getTime()
    return p
  }, [q, fromSale, toSale])

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await listBookings({ ...filterParams, page, size: 50 })
      const d = res.data?.data
      setRows(d?.content || [])
      setTotalPages(d?.totalPages || 1)
      setTotal(d?.totalElements || 0)
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Không tải được danh sách vé')
    } finally {
      setLoading(false)
    }
  }, [filterParams, page])

  const loadTotals = useCallback(async () => {
    setTotalsLoading(true)
    try {
      const res = await totalsBookings(filterParams)
      setTotals(res.data?.data || [])
    } catch { /* silent */ }
    finally { setTotalsLoading(false) }
  }, [filterParams])

  useEffect(() => { load() }, [load])
  useEffect(() => { loadTotals() }, [loadTotals])

  useEffect(() => {
    setSelectedIds(prev => {
      const valid = new Set(rows.map(r => r.id))
      const next = new Set()
      for (const id of prev) if (valid.has(id)) next.add(id)
      return next
    })
  }, [rows])

  const qTimer = useRef(null)
  const onSearch = (v) => {
    if (qTimer.current) clearTimeout(qTimer.current)
    qTimer.current = setTimeout(() => { setPage(0); setQ(v) }, 300)
  }

  const toggleSelect = (id) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }
  const toggleAllOnPage = () => {
    setSelectedIds(prev => {
      const allSelected = rows.length > 0 && rows.every(r => prev.has(r.id))
      const next = new Set(prev)
      if (allSelected) rows.forEach(r => next.delete(r.id))
      else            rows.forEach(r => next.add(r.id))
      return next
    })
  }
  const clearSelection = () => setSelectedIds(new Set())

  const selectedBookings = useMemo(
    () => rows.filter(r => selectedIds.has(r.id)),
    [rows, selectedIds]
  )

  const onBatchPay = () => {
    if (selectedBookings.length < 2) return toast.error('Chọn ít nhất 2 booking để thu batch.')
    setBatchPay(selectedBookings)
  }

  const onSavedRefresh = () => { load(); loadTotals() }

  const openBookingFace = (b) => setFace({ booking: b, ticketId: null })
  const openTicketFace  = (b, ticketId) => setFace({ booking: b, ticketId })

  return (
    <div className="w-full">
      <div className="flex flex-col lg:flex-row gap-2 mb-3">
        <input
          defaultValue={q}
          onChange={e => onSearch(e.target.value)}
          placeholder="Tìm theo mã booking, số vé, tên khách, hành trình…"
          className="flex-1 min-w-0 px-3.5 py-2 rounded-lg border border-gray-300 bg-white text-sm
            focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none" />

        <div className="flex gap-2 items-center shrink-0">
          <span className="text-xs text-gray-500 font-semibold hidden lg:inline">Ngày bán:</span>
          <div className="w-36"><DatePicker value={fromSale}
            onChange={v => { setPage(0); setFromSale(v) }}
            placeholder="Từ ngày" size="sm" /></div>
          <span className="text-gray-400 text-xs">→</span>
          <div className="w-36"><DatePicker value={toSale}
            onChange={v => { setPage(0); setToSale(v) }}
            placeholder="Đến ngày" size="sm" /></div>
        </div>

        <button type="button" onClick={() => setForm({ mode: 'create' })}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white
            text-sm font-semibold shadow-md shadow-blue-500/20 hover:from-blue-700 hover:to-indigo-700 shrink-0">
          + Thêm booking
        </button>
      </div>

      {selectedIds.size > 0 && (
        <div className="mb-3 p-3 rounded-xl bg-amber-50 border border-amber-300 flex items-center gap-3 flex-wrap">
          <span className="text-sm font-semibold text-amber-900">
            Đã chọn {selectedIds.size} booking
          </span>
          <div className="flex-1" />
          <button onClick={onBatchPay}
            className="px-3 py-1.5 rounded-md bg-blue-600 text-white text-xs font-bold hover:bg-blue-700">
            💰 Thu tiền hàng loạt
          </button>
          <button onClick={clearSelection}
            className="px-2 py-1.5 rounded-md text-xs text-gray-600 hover:bg-white/60">
            Bỏ chọn
          </button>
        </div>
      )}

      <BookingTotalsCard totals={totals} loading={totalsLoading} />

      {/* Desktop table */}
      <div className="hidden lg:block bg-white rounded-2xl shadow border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs border-collapse table-fixed">
            <colgroup>
              <col style={{ width: 32 }} />
              <col style={{ width: 30 }} />
              <col style={{ width: 130 }} />
              <col style={{ width: 80 }} />   {/* Công ty */}
              <col style={{ width: 210 }} />  {/* Khách hàng (name + số vé) */}
              <col style={{ width: 100 }} />  {/* Booking */}
              <col style={{ width: 130 }} />  {/* Hành trình */}
              <col style={{ width: 110 }} />
              <col style={{ width: 110 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 90 }} />
              <col style={{ width: 100 }} />
              <col style={{ width: 120 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
              <col style={{ width: 140 }} />
            </colgroup>
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px]">
              <tr>
                <Th center>
                  <input type="checkbox"
                    checked={rows.length > 0 && rows.every(r => selectedIds.has(r.id))}
                    onChange={toggleAllOnPage}
                    className="rounded" />
                </Th>
                <Th>#</Th>
                <Th>Loại / hãng</Th>
                <Th>Công ty</Th>
                <Th>Khách hàng</Th>
                <Th>Booking</Th>
                <Th>Hành trình / giờ đi</Th>
                <ThR>Giá gốc</ThR>
                <ThR>Giá trên vé</ThR>
                <ThR>Thành tiền</ThR>
                <ThR>Phí xuất vé</ThR>
                <ThR>Giá bán</ThR>
                <ThR>Tổng booking</ThR>
                <ThR>Quy đổi VND</ThR>
                <Th center>Thanh toán</Th>
                <Th>Thao tác</Th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={16} className="text-center py-10 text-gray-400">Đang tải…</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={16} className="text-center py-14 text-gray-400">
                  {q || fromSale || toSale ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào. Bấm "Thêm booking" để tạo.'}
                </td></tr>
              ) : (
                rows.map((b, bIdx) => renderBookingRows(b, bIdx, {
                  page, nowTick,
                  isSelected: selectedIds.has(b.id),
                  onToggleSelect: toggleSelect,
                  onOpenBookingFace: openBookingFace,
                  onOpenTicketFace: openTicketFace,
                  onInvoice: (bookingId) => setInvMgr(bookingId),
                  onNote: setNoteView,
                  onPay: setPayFor,
                  onEdit: () => setForm({ mode: 'edit', bookingId: b.id }),
                  onDelete: () => setConfirmDel(b),
                }))
              )}
            </tbody>
          </table>
        </div>
        <Pagination page={page} totalPages={totalPages} total={total} onPage={setPage} />
      </div>

      {/* Mobile cards */}
      <div className="lg:hidden space-y-2">
        {loading ? (
          <div className="text-center py-10 text-gray-400 text-sm">Đang tải…</div>
        ) : rows.length === 0 ? (
          <div className="text-center py-14 text-gray-400 text-sm">
            {q || fromSale || toSale ? 'Không tìm thấy vé phù hợp' : 'Chưa có booking nào.'}
          </div>
        ) : (
          rows.map(b => (
            <MobileBookingCard key={b.id} booking={b} nowTick={nowTick}
              isSelected={selectedIds.has(b.id)}
              onToggleSelect={toggleSelect}
              onOpenBookingFace={openBookingFace}
              onOpenTicketFace={openTicketFace}
              onInvoice={(id) => setInvMgr(id)}
              onNote={setNoteView}
              onPay={setPayFor}
              onEdit={() => setForm({ mode: 'edit', bookingId: b.id })}
              onDelete={() => setConfirmDel(b)} />
          ))
        )}
        <Pagination page={page} totalPages={totalPages} total={total} onPage={setPage} />
      </div>

      {/* Modals */}
      {form && (
        <BookingFormModal
          mode={form.mode} bookingId={form.bookingId}
          onClose={() => setForm(null)}
          onSaved={() => { setForm(null); onSavedRefresh() }}
        />
      )}
      {face && (
        <TicketFaceModal
          booking={{
            ...face.booking,
            _onPickTicket: (tid) => setFace({ booking: face.booking, ticketId: tid })
          }}
          ticketId={face.ticketId}
          onClose={() => setFace(null)}
          onDirty={onSavedRefresh}
        />
      )}
      {invMgr && (
        <InvoiceManagerModal bookingId={invMgr} onClose={() => setInvMgr(null)} onDirty={load} />
      )}
      {payFor && (
        <PaymentModal booking={payFor}
          onClose={() => setPayFor(null)}
          onSaved={() => { setPayFor(null); onSavedRefresh() }} />
      )}
      {batchPay && (
        <BatchPaymentModal bookings={batchPay}
          onClose={() => setBatchPay(null)}
          onSaved={() => { setBatchPay(null); clearSelection(); onSavedRefresh() }} />
      )}
      {noteView && (
        <TicketNoteModal passengerName={noteView.passengerName} note={noteView.note}
          onClose={() => setNoteView(null)} />
      )}
      {confirmDel && (
        <ConfirmModal
          open title="Xóa booking"
          message={`Xóa booking "${confirmDel.bookingCode || '(chưa có mã)'}" cùng ${confirmDel.tickets?.length || 0} vé, tất cả mặt vé và hóa đơn đính kèm?`}
          confirmLabel="Xóa" danger
          onConfirm={async () => {
            try {
              await deleteBooking(confirmDel.id)
              toast.success('Đã xóa'); setConfirmDel(null); onSavedRefresh()
            } catch (e) {
              toast.error(e?.response?.data?.message || 'Xóa thất bại')
            }
          }}
          onCancel={() => setConfirmDel(null)}
        />
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
//  HEADER CELLS
// ═══════════════════════════════════════════════════════════════

function Th({ children, center }) {
  return (
    <th className={`px-2 py-2 font-semibold align-middle ${center ? 'text-center' : 'text-left'}`}>
      {children}
    </th>
  )
}
function ThR({ children }) {
  return (
    <th className="px-2 py-2 font-semibold text-right align-middle">
      {children}
    </th>
  )
}

// ═══════════════════════════════════════════════════════════════
//  GROUP TICKETS THEO CÔNG TY
// ═══════════════════════════════════════════════════════════════

/**
 * Sắp xếp lại tickets: gom các vé cùng công ty lại với nhau. Thứ tự công ty
 * giữ theo thứ tự xuất hiện đầu tiên trong booking gốc (stable — không sort
 * alphabet, để user vẫn thấy công ty họ nhập đầu tiên ở trên đầu).
 *
 * Ví dụ input:  [Cty A khách1, Cty B khách2, Cty A khách3, Cty A khách4]
 * Output tickets: [khách1, khách3, khách4, khách2]
 * Output groups: [{key:A, size:3, tickets:[k1,k3,k4]}, {key:B, size:1, tickets:[k2]}]
 *
 * Key dùng cho công ty = companyId (null nếu khách lẻ) → 2 vé cùng "khách lẻ"
 * (null companyId) cũng merge.
 */
function groupTicketsByCompany(tickets) {
  const buckets = new Map()   // key → { key, keyLabel, tickets: [] }
  for (const t of tickets || []) {
    const key = t.companyId == null ? 'none' : `c${t.companyId}`
    if (!buckets.has(key)) buckets.set(key, { key, tickets: [] })
    buckets.get(key).tickets.push(t)
  }
  const groups = []
  const sortedTickets = []
  for (const b of buckets.values()) {
    groups.push({ key: b.key, size: b.tickets.length, firstIdxInSorted: sortedTickets.length })
    for (const t of b.tickets) sortedTickets.push(t)
  }
  return { sortedTickets, groups }
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — DESKTOP TABLE
// ═══════════════════════════════════════════════════════════════

function renderBookingRows(b, bIdx, {
  page, nowTick, isSelected, onToggleSelect,
  onOpenBookingFace, onOpenTicketFace, onInvoice, onNote, onPay, onEdit, onDelete,
}) {
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee, t.serviceFee, t.issuanceFee)))
  const totalVnd = toVnd(bookingTotal, b.currency, b.exchangeRate)
  const N = b.tickets?.length || 1
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
      primary?.band === 'warn' ? 'bg-amber-500 text-white'
    : primary?.band === 'future' ? 'bg-blue-600 text-white'
    : ''

  // Sắp xếp tickets theo company (giữ order xuất hiện đầu tiên)
  const { sortedTickets, groups } = groupTicketsByCompany(b.tickets || [])
  // Map: sortedIdx → group info (chỉ render company cell ở dòng đầu của group)
  const groupStartAt = new Map()
  for (const g of groups) groupStartAt.set(g.firstIdxInSorted, g)

  return sortedTickets.map((t, tIdx) => {
    const rowBg = isSelected ? 'bg-amber-50/50' : 'bg-white'
    const firstRow = tIdx === 0
    const lastRow  = tIdx === N - 1
    const cardBorder = `${firstRow ? 'border-t-2 border-t-gray-100' : ''} ${lastRow ? 'border-b-4 border-b-gray-100' : ''}`
    const withCollection = sumAmounts(t.basePrice, t.collectionFee)
    const subTotal       = sumAmounts(withCollection, t.serviceFee)
    const sellPrice      = sumAmounts(subTotal, t.issuanceFee)
    const invBadge = invoiceBadge(t.invoices, b.invoices)
    const hasFace = faceStatus(b, t.id)
    const groupInfo = groupStartAt.get(tIdx)

    return (
      <tr key={t.id}
          className={`${rowBg} ${cardBorder} hover:bg-blue-50/40 transition-colors align-middle`}>
        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            <input type="checkbox"
              checked={isSelected}
              onChange={() => onToggleSelect(b.id)}
              className="rounded cursor-pointer" />
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-gray-500 tabular-nums text-center align-middle font-semibold"
              rowSpan={N}>
            {page * 50 + bIdx + 1}
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle relative" rowSpan={N}>
            {primary && badgeCls && (
              <span className={`inline-block mb-1 px-1.5 py-0.5 rounded font-mono text-[10px] font-bold ${badgeCls}`}
                title={`Còn ${primary.text} đến chuyến bay`}>
                ⏱ {primary.text}
              </span>
            )}
            <div className="text-xs font-semibold text-gray-900 leading-tight">
              {kindLabel(b.kind)} · <span className="text-gray-600">{b.airlineCode || '—'}</span>
            </div>
            <div className="text-[10px] text-gray-500 tabular-nums mt-0.5">
              {formatDateTimeShort(b.saleDate)}
            </div>
          </td>
        )}

        {/* Công ty — chỉ render ở dòng đầu group, rowspan = group size */}
        {groupInfo && (
          <td className="px-2 py-2 align-middle truncate border-l border-gray-100"
              rowSpan={groupInfo.size}>
            <CompanyLabel short={t.companyShortName} full={t.companyName} />
          </td>
        )}

        {/* Khách hàng — 2 dòng: tên + số vé */}
        <td className="px-2 py-2 align-middle">
          <div className="font-medium text-gray-900 truncate leading-tight">
            {t.passengerName || '—'}
          </div>
          <button type="button" onClick={() => onOpenTicketFace(b, t.id)}
            title={b.sharedTicketFace
              ? 'Xem mặt vé chung của booking'
              : 'Xem mặt vé riêng của vé này'}
            className="block w-full text-left font-mono text-[10px] text-gray-500 hover:text-blue-700 hover:underline truncate leading-tight mt-0.5">
            {t.ticketNumber || 'chưa có số vé'}
            {hasFace && <span className="ml-1 text-emerald-600">📎</span>}
          </button>
        </td>

        {/* Booking — chỉ mã booking, rowspan cả booking */}
        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            <button type="button" onClick={() => onOpenBookingFace(b)}
              title={b.sharedTicketFace
                ? 'Xem mặt vé chung cả booking'
                : 'Chọn hành khách để xem mặt vé'}
              className="block w-full text-left font-mono text-[11px] font-bold text-gray-900 hover:text-blue-700 hover:underline truncate">
              {b.bookingCode || '—'}
              {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
            </button>
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 align-middle" rowSpan={N}>
            {(b.segments || []).length === 0 ? <span className="text-gray-400">—</span> :
              (b.segments || []).map((s, i) => (
                <div key={i} className={`${i > 0 ? 'mt-1.5 pt-1.5 border-t border-dashed border-gray-200' : ''}`}>
                  <div className="text-xs font-bold text-gray-900 leading-tight">
                    {s.fromCode} <span className="text-gray-400">→</span> {s.toCode}
                  </div>
                  <div className="text-[11px] tabular-nums text-gray-500 leading-tight">
                    {formatDepart(s.departLocalMs, s.fromCode) || '—'}
                  </div>
                </div>
              ))
            }
          </td>
        )}

        <TdMoneyPair value1={t.basePrice} value2={t.collectionFee} currency={b.currency} bold1 />
        <TdMoneyPair value1={withCollection} value2={t.serviceFee} currency={b.currency} bold1 />
        <TdMoney value={subTotal} currency={b.currency} bold />
        <TdMoney value={t.issuanceFee} currency={b.currency} muted />
        <TdMoney value={sellPrice} currency={b.currency} bold />

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle border-l border-r border-gray-200"
              rowSpan={N}>
            <div className="font-mono tabular-nums text-sm font-bold text-blue-700">
              {formatMoney(bookingTotal, b.currency)}
            </div>
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-right align-middle" rowSpan={N}>
            {b.currency === 'VND' ? (
              <span className="text-gray-400 text-[11px]">—</span>
            ) : (
              <>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900">
                  {formatMoney(totalVnd, 'VND')}
                </div>
                <div className="text-[10px] text-gray-500 tabular-nums">
                  1 USD = {b.exchangeRate || '—'}
                </div>
              </>
            )}
          </td>
        )}

        {firstRow && (
          <td className="px-2 py-2 text-center align-middle" rowSpan={N}>
            <PaymentCell booking={b} bookingTotal={bookingTotal} onPay={onPay} />
          </td>
        )}

        {/* Thao tác */}
        <td className="px-2 py-2 align-middle">
          <div className="flex flex-wrap items-center gap-1">
            {t.note && (
              <button type="button"
                onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                title={'Ghi chú: ' + (t.note.length > 60 ? t.note.slice(0, 60) + '…' : t.note)}
                className="w-7 h-7 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-700 inline-flex items-center justify-center">
                📝
              </button>
            )}
            <button type="button" onClick={() => onOpenTicketFace(b, t.id)}
              title="Xem chi tiết mặt vé"
              className={`w-7 h-7 rounded-md flex items-center justify-center ${
                hasFace
                  ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                  : 'text-gray-500 hover:bg-blue-100 hover:text-blue-700'
              }`}>
              📄
            </button>
            {firstRow && (
              <>
                <button type="button" onClick={() => onInvoice(b.id)}
                  title={invBadge.title}
                  className={`w-7 h-7 rounded-md flex items-center justify-center ${invBadge.color}`}>
                  {invBadge.icon}
                </button>
                <button type="button" onClick={onEdit}
                  title="Sửa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-gray-200 flex items-center justify-center">✎</button>
                <button type="button" onClick={onDelete}
                  title="Xóa booking"
                  className="w-7 h-7 rounded-md text-gray-600 hover:bg-rose-100 hover:text-rose-700 flex items-center justify-center">🗑</button>
              </>
            )}
          </div>
        </td>
      </tr>
    )
  })
}

// ── Sub-components ─────────────────────────────────────

function CompanyLabel({ short, full }) {
  if (!full && !short) {
    return <span className="text-[10px] text-gray-400 italic">Khách lẻ</span>
  }
  const label = short || autoShort(full)
  return (
    <span className="text-[11px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800"
      title={full}>
      {label}
    </span>
  )
}

function autoShort(name) {
  if (!name) return '—'
  const parts = name.split(/\s+/).filter(x => x && !/^(và|-|của)$/i.test(x))
  if (parts.length === 1) return parts[0].slice(0, 6).toUpperCase()
  return parts.slice(0, 3).map(p => p[0]?.toUpperCase() || '').join('')
}

function PaymentCell({ booking, bookingTotal, onPay }) {
  const st = booking.paymentStatus || 'UNPAID'
  const paid = parseAmount(booking.paidAmount) || 0
  const remain = Math.max(0, bookingTotal - paid)

  const badge =
      st === 'PAID'    ? { cls: 'bg-green-100 text-green-700', label: 'Đã thu' }
    : st === 'PARTIAL' ? { cls: 'bg-amber-100 text-amber-700', label: 'Thu 1 phần' }
    :                    { cls: 'bg-rose-100 text-rose-700',   label: 'Chưa thu' }

  return (
    <button type="button" onClick={() => onPay(booking)}
      className={`px-2 py-1 rounded-md ${badge.cls} hover:brightness-95 transition text-left w-full`}>
      <div className="text-[10px] font-bold">{badge.label}</div>
      {st !== 'UNPAID' && (
        <div className="text-[10px] font-mono tabular-nums mt-0.5 opacity-80">
          {formatMoney(remain, booking.currency, { withUnit: false })}
        </div>
      )}
    </button>
  )
}

function TdMoney({ value, currency, bold, muted }) {
  const n = typeof value === 'number' ? value : parseAmount(value)
  const cls =
      !Number.isFinite(n) ? 'text-gray-300'
    : muted ? 'text-gray-500'
    : bold  ? 'text-gray-900 font-semibold'
    : 'text-gray-700'
  return (
    <td className="px-2 py-2 text-right font-mono tabular-nums align-middle">
      <span className={cls}>{formatMoney(n, currency, { withUnit: false })}</span>
    </td>
  )
}

function TdMoneyPair({ value1, value2, currency, bold1 }) {
  const n1 = typeof value1 === 'number' ? value1 : parseAmount(value1)
  const n2 = typeof value2 === 'number' ? value2 : parseAmount(value2)
  const cls1 =
      !Number.isFinite(n1) ? 'text-gray-300'
    : bold1 ? 'text-gray-900 font-semibold'
    : 'text-gray-700'
  return (
    <td className="px-2 py-2 text-right font-mono tabular-nums align-middle">
      <div className={cls1}>{formatMoney(n1, currency, { withUnit: false })}</div>
      <div className="text-[10px] text-gray-400">
        {Number.isFinite(n2) && n2 !== 0 ? formatMoney(n2, currency, { withUnit: false }) : '—'}
      </div>
    </td>
  )
}

// ═══════════════════════════════════════════════════════════════
//  RENDER — MOBILE CARD
// ═══════════════════════════════════════════════════════════════

function MobileBookingCard({ booking: b, nowTick, isSelected, onToggleSelect,
                             onOpenBookingFace, onOpenTicketFace, onInvoice, onNote, onPay, onEdit, onDelete }) {
  const bookingTotal = sumAmounts(...(b.tickets || []).map(t =>
    sumAmounts(t.basePrice, t.collectionFee, t.serviceFee, t.issuanceFee)))
  const primary = primaryDeparture(b.segments, nowTick)
  const badgeCls =
      primary?.band === 'warn' ? 'bg-amber-500 text-white'
    : primary?.band === 'future' ? 'bg-blue-600 text-white'
    : ''
  const st = b.paymentStatus || 'UNPAID'
  const stCls =
      st === 'PAID'    ? 'bg-green-100 text-green-700'
    : st === 'PARTIAL' ? 'bg-amber-100 text-amber-700'
    :                    'bg-rose-100 text-rose-700'
  const stLabel =
      st === 'PAID'    ? 'Đã thu'
    : st === 'PARTIAL' ? 'Thu 1 phần'
    :                    'Chưa thu'

  // Mobile cũng group theo company cho nhất quán
  const { sortedTickets } = groupTicketsByCompany(b.tickets || [])

  return (
    <div className={`rounded-xl border shadow-sm p-3 relative ${isSelected ? 'bg-amber-50 border-amber-300' : 'bg-white border-gray-200'}`}>
      <div className="flex items-start gap-2 mb-2">
        <input type="checkbox" checked={isSelected}
          onChange={() => onToggleSelect(b.id)}
          className="mt-1.5 rounded cursor-pointer" />
        <div className="flex-1">
          {primary && badgeCls && (
            <span className={`inline-block px-2 py-0.5 mb-1 rounded-md font-mono text-[10px] font-bold ${badgeCls}`}>
              ⏱ {primary.text}
            </span>
          )}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 font-bold">
              {kindLabel(b.kind)} · {b.airlineCode || '?'}
            </span>
            <button type="button" onClick={() => onOpenBookingFace(b)}
              className="font-mono text-xs font-bold text-gray-900 hover:text-blue-700 hover:underline">
              {b.bookingCode || '—'}
              {b.sharedTicketFace && b.bookingFace && <span className="ml-1 text-emerald-600">📎</span>}
            </button>
          </div>
        </div>
        <button onClick={onEdit} className="text-gray-500 hover:text-gray-800 w-7 h-7 rounded-md hover:bg-gray-100">✎</button>
        <button onClick={onDelete} className="text-gray-500 hover:text-rose-600 w-7 h-7 rounded-md hover:bg-rose-50">🗑</button>
      </div>

      <div className="text-[10px] text-gray-400 tabular-nums mb-2">
        Bán: {formatDateTimeShort(b.saleDate)}
      </div>

      <div className="text-[11px] text-gray-700 mb-2 space-y-0.5">
        {(b.segments || []).map((s, i) => (
          <div key={i} className="px-1.5 py-0.5">
            <span className="font-bold">{s.fromCode} → {s.toCode}</span>
            <span className="text-gray-500 mx-1">·</span>
            <span className="tabular-nums">{formatDepart(s.departLocalMs, s.fromCode)}</span>
          </div>
        ))}
      </div>

      <div className="divide-y divide-gray-100 -mx-3">
        {sortedTickets.map(t => {
          const hasFace = faceStatus(b, t.id)
          return (
            <div key={t.id} className="px-3 py-2">
              <div className="flex items-center gap-2 mb-1">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <CompanyLabel short={t.companyShortName} full={t.companyName} />
                    <span className="text-sm font-semibold text-gray-900 truncate">{t.passengerName || '—'}</span>
                  </div>
                  <button type="button" onClick={() => onOpenTicketFace(b, t.id)}
                    className="font-mono text-[10px] text-gray-500 hover:text-blue-700 hover:underline truncate">
                    {t.ticketNumber || 'chưa có số vé'}
                    {hasFace && <span className="ml-1 text-emerald-600">📎</span>}
                  </button>
                </div>
                <div className="font-mono tabular-nums text-sm font-bold text-gray-900">
                  {formatMoney(sumAmounts(t.basePrice, t.collectionFee, t.serviceFee, t.issuanceFee), b.currency)}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-1">
                <button type="button" onClick={() => onOpenTicketFace(b, t.id)}
                  className="h-7 px-2 rounded-md text-[11px] font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200">
                  📄 Mặt vé
                </button>
                {t.note && (
                  <button type="button"
                    onClick={() => onNote({ passengerName: t.passengerName || '(vé)', note: t.note })}
                    className="h-7 w-7 rounded-md text-[11px] font-semibold bg-amber-100 text-amber-700 flex items-center justify-center">
                    📝
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-2 pt-2 border-t border-gray-100 flex items-center justify-between gap-2">
        <button type="button" onClick={() => onPay(b)}
          className={`px-2 py-1 rounded-md ${stCls} text-[11px] font-bold`}>
          {stLabel}
        </button>
        <button type="button" onClick={() => onInvoice(b.id)}
          className="text-[11px] px-2 py-1 rounded-md bg-blue-100 text-blue-700 font-semibold">
          📄 Hóa đơn
        </button>
        <div className="flex-1" />
        <span className="font-mono tabular-nums font-bold text-blue-700 text-sm">
          {formatMoney(bookingTotal, b.currency)}
        </span>
      </div>
    </div>
  )
}

function Pagination({ page, totalPages, total, onPage }) {
  if (totalPages <= 1) return null
  return (
    <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-t border-gray-100 text-xs">
      <span className="text-gray-500">{total} vé · trang {page + 1}/{totalPages}</span>
      <div className="flex gap-1">
        <button onClick={() => onPage(Math.max(0, page - 1))} disabled={page === 0}
          className="px-2.5 py-1 rounded-md bg-white border border-gray-200 disabled:opacity-40 hover:bg-gray-100">←</button>
        <button onClick={() => onPage(Math.min(totalPages - 1, page + 1))} disabled={page >= totalPages - 1}
          className="px-2.5 py-1 rounded-md bg-white border border-gray-200 disabled:opacity-40 hover:bg-gray-100">→</button>
      </div>
    </div>
  )
}

// ── Utility ─────────────────────────────────────────────

function faceStatus(b, ticketId) {
  if (b.sharedTicketFace) return !!b.bookingFace
  const t = (b.tickets || []).find(x => x.id === ticketId)
  return !!t?.ticketFace
}

function kindLabel(k) {
  return { NEW: 'Mua mới', EXCHANGE: 'Đổi', REFUND: 'Hoàn', SERVICE: 'Dịch vụ' }[k] || k
}

function invoiceBadge(ticketInvoices, bookingInvoices) {
  const all = [...(ticketInvoices || []), ...(bookingInvoices || [])]
  if (all.length === 0) {
    return { label: 'Chưa HĐ', icon: '🧾', color: 'bg-red-50 text-red-600 hover:bg-red-100', title: 'Chưa có hóa đơn' }
  }
  if (all.some(i => i.status === 'ADJUSTED'))
    return { label: 'Điều chỉnh', icon: '🧾', color: 'bg-purple-50 text-purple-600 hover:bg-purple-100', title: 'Hóa đơn điều chỉnh' }
  if (all.some(i => i.status === 'ISSUED'))
    return { label: 'Đã PH', icon: '🧾', color: 'bg-green-50 text-green-600 hover:bg-green-100', title: 'Hóa đơn đã phát hành' }
  return { label: 'Nháp', icon: '🧾', color: 'bg-orange-50 text-orange-500 hover:bg-orange-100', title: 'Hóa đơn nháp' }
}

function formatDateTimeShort(ms) {
  if (!ms) return '—'
  try {
    const parts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Ho_Chi_Minh',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false,
    }).formatToParts(new Date(ms))
    const p = (t) => parts.find(x => x.type === t)?.value || ''
    return `${p('hour')}:${p('minute')} ${p('day')}/${p('month')}/${p('year')}`
  } catch { return '' }
}