import { useState, useEffect } from 'react'
import { parseAmount, formatMoney } from '../../lib/money'

/**
 * Ô nhập số tiền có format khi blur.
 *
 * - Trong lúc gõ (focus): giữ NGUYÊN chuỗi người dùng đánh — không tự format
 *   để con trỏ không nhảy loạn xạ.
 * - Khi rời ô (blur): parse rồi format lại theo currency (USD 2 số lẻ, VND
 *   nguyên; dấu chấm phân cách hàng nghìn) → chuỗi format hiển thị đẹp và cũng
 *   là chuỗi gửi lên BE (BE lưu String, giữ nguyên format).
 *
 * value / onChange dùng chuỗi — parent tự bảo quản.
 */
export default function PriceInput({
  value = '',
  currency = 'VND',
  onChange,
  placeholder,
  className = '',
  disabled = false,
  autoFocus = false,
}) {
  // Buffer nội bộ trong lúc focus — sync ngược từ prop khi không focus
  const [buf, setBuf] = useState(value ?? '')
  const [focused, setFocused] = useState(false)

  useEffect(() => {
    if (!focused) setBuf(value ?? '')
  }, [value, focused])

  const handleBlur = () => {
    setFocused(false)
    const n = parseAmount(buf)
    if (!Number.isFinite(n)) {
      // Không parse được → giữ nguyên chuỗi rỗng để BE lưu ""
      onChange?.('')
      setBuf('')
      return
    }
    const formatted = formatMoney(n, currency, { withUnit: false })
    setBuf(formatted)
    onChange?.(formatted)
  }

  return (
    <div className="relative">
      <input
        type="text"
        inputMode="decimal"
        value={buf}
        onChange={e => setBuf(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={handleBlur}
        placeholder={placeholder ?? (currency === 'USD' ? '0,00' : '0')}
        disabled={disabled}
        autoFocus={autoFocus}
        className={`w-full pl-3 pr-14 py-2 rounded-lg border border-gray-300 bg-white text-sm
          text-right font-mono tabular-nums
          focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none
          disabled:bg-gray-50 disabled:text-gray-500
          ${className}`}
      />
      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[11px] font-semibold text-gray-400 pointer-events-none">
        {currency}
      </span>
    </div>
  )
}
